package com.ridmikstudio.keyboard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.lang.ref.WeakReference

class RidmikScreenReaderService : AccessibilityService() {

    private data class VisibleTextEntry(
        val top: Int,
        val left: Int,
        val text: String
    )

    companion object {
        @Volatile
        private var instanceRef: WeakReference<RidmikScreenReaderService>? = null

        @Volatile
        private var lastSnapshotText: String = ""

        fun isServiceEnabled(context: Context): Boolean {
            if (instanceRef?.get() != null) return true
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val pkg = context.packageName
            return enabled.contains("$pkg/.RidmikScreenReaderService") ||
                enabled.contains("$pkg/com.ridmikstudio.keyboard.RidmikScreenReaderService")
        }

        fun captureVisibleText(context: Context): String {
            val svc = instanceRef?.get() ?: return ""
            val live = svc.extractVisibleScreenText(context)
            if (live.isNotBlank()) {
                lastSnapshotText = live
                return live
            }
            return lastSnapshotText
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        instanceRef = WeakReference(this)
    }

    override fun onInterrupt() {
        // no-op
    }

    override fun onDestroy() {
        instanceRef = null
        super.onDestroy()
    }

    private fun extractVisibleScreenText(context: Context): String {
        val dm = context.resources.displayMetrics
        val screenRect = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val entries = ArrayList<VisibleTextEntry>()

        try {
            val winList = windows
            if (!winList.isNullOrEmpty()) {
                for (w in winList) {
                    val wType = w.type
                    if (wType == AccessibilityWindowInfo.TYPE_INPUT_METHOD ||
                        wType == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY
                    ) {
                        continue
                    }
                    val root = w.root ?: continue
                    val pkgName = root.packageName?.toString().orEmpty()
                    if (wType == AccessibilityWindowInfo.TYPE_SYSTEM && pkgName == "com.android.systemui") {
                        continue
                    }
                    collectVisibleNodes(root, screenRect, entries, 0)
                }
            }
        } catch (_: Exception) {
        }

        if (entries.isEmpty()) {
            try {
                val root = rootInActiveWindow
                if (root != null) {
                    collectVisibleNodes(root, screenRect, entries, 0)
                }
            } catch (_: Exception) {
            }
        }

        if (entries.isEmpty()) return ""

        val sorted = entries.sortedWith(compareBy<VisibleTextEntry>({ it.top / 16 }, { it.left }))
        val unique = LinkedHashSet<String>()
        for (e in sorted) {
            val clean = e.text.replace(Regex("\\s+"), " ").trim()
            if (clean.isNotEmpty()) {
                unique.add(clean)
            }
        }
        return unique.joinToString("\n")
    }

    private fun collectVisibleNodes(
        node: AccessibilityNodeInfo?,
        screenRect: Rect,
        out: MutableList<VisibleTextEntry>,
        depth: Int
    ) {
        if (node == null || depth > 60) return
        if (!node.isVisibleToUser) return

        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0 || !Rect.intersects(bounds, screenRect)) {
            return
        }

        val nodeText = node.text?.toString()?.trim().orEmpty()
        val contentDesc = if (nodeText.isEmpty() && node.childCount == 0) {
            node.contentDescription?.toString()?.trim().orEmpty()
        } else {
            ""
        }
        val raw = if (nodeText.isNotEmpty()) nodeText else contentDesc
        if (raw.isNotEmpty()) {
            out.add(VisibleTextEntry(bounds.top, bounds.left, raw))
        }

        val count = node.childCount
        for (i in 0 until count) {
            val child = try { node.getChild(i) } catch (_: Exception) { null }
            if (child != null) {
                collectVisibleNodes(child, screenRect, out, depth + 1)
            }
        }
    }
}
