package com.ridmikstudio.keyboard

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object ScreenTranslator {
    private val mainHandler = Handler(Looper.getMainLooper())

    fun translate(
        sourceText: String,
        targetMode: String,
        geminiApiKey: String,
        onSuccess: (translated: String, targetLang: String) -> Unit,
        onError: (message: String) -> Unit
    ) {
        val clean = sourceText.trim()
        if (clean.isEmpty()) {
            mainHandler.post { onError("অনুবাদের জন্য আগে লেখা কপি করুন") }
            return
        }
        val clipped = if (clean.length > 2600) clean.substring(0, 2600) else clean
        val hasBangla = clipped.any { it in '\u0980'..'\u09FF' }
        val allowed = setOf("bn", "en", "ar", "hi", "ur", "ms", "es", "fr")
        val tl = if (targetMode in allowed) targetMode else if (hasBangla) "en" else "bn"

        Thread {
            val gtxResult = tryGoogleGtx(clipped, tl)
            if (!gtxResult.isNullOrBlank()) {
                mainHandler.post { onSuccess(gtxResult, tl) }
                return@Thread
            }

            val mmResult = tryMyMemory(clipped.take(480), tl, hasBangla)
            if (!mmResult.isNullOrBlank()) {
                mainHandler.post { onSuccess(mmResult, tl) }
                return@Thread
            }

            if (geminiApiKey.isNotBlank()) {
                val aiResult = tryGemini(geminiApiKey, clipped, tl)
                if (!aiResult.isNullOrBlank()) {
                    mainHandler.post { onSuccess(aiResult, tl) }
                    return@Thread
                }
            }

            mainHandler.post { onError("অনুবাদ করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।") }
        }.start()
    }

    private fun tryGoogleGtx(text: String, tl: String): String? {
        return try {
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$tl&dt=t&q=$q")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().readText()
            val root = JSONArray(body)
            val segments = root.optJSONArray(0) ?: return null
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i) ?: continue
                val piece = seg.optString(0, "")
                if (piece.isNotEmpty()) sb.append(piece)
            }
            sb.toString().trim().ifEmpty { null }
        } catch (_: Exception) {
            null
        }
    }

    private fun tryMyMemory(text: String, tl: String, hasBangla: Boolean): String? {
        return try {
            val src = if (hasBangla) "bn" else "en"
            val pair = if (src == tl) {
                if (src == "bn") "en|bn" else "bn|en"
            } else {
                "$src|$tl"
            }
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=$pair")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 6000
            }
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().readText()
            val out = JSONObject(body).optJSONObject("responseData")?.optString("translatedText")?.trim()
            if (out.isNullOrBlank()) null else out
        } catch (_: Exception) {
            null
        }
    }

    private fun tryGemini(apiKey: String, text: String, tl: String): String? {
        return try {
            val dest = when (tl) {
                "bn" -> "natural Bengali (বাংলা)"
                "en" -> "natural English"
                "ar" -> "natural Arabic (العربية)"
                "hi" -> "natural Hindi (हिन्दी)"
                "ur" -> "natural Urdu (اردو)"
                "ms" -> "natural Malay (Bahasa Melayu)"
                "es" -> "natural Spanish (Español)"
                "fr" -> "natural French (Français)"
                else -> "natural Bengali (বাংলা)"
            }
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=$apiKey")
            val payload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "Translate the following text into $dest. Output ONLY the translated text:\n\n$text")
                            })
                        })
                    })
                })
            }
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = 8000
                setRequestProperty("Content-Type", "application/json")
            }
            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            if (conn.responseCode !in 200..299) return null
            val resp = conn.inputStream.bufferedReader().readText()
            JSONObject(resp)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
                .trim()
                .ifEmpty { null }
        } catch (_: Exception) {
            null
        }
    }
}
