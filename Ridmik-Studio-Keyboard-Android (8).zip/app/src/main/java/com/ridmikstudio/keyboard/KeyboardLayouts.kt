package com.ridmikstudio.keyboard

enum class KeyboardLanguage { ENGLISH, PROVAT }
enum class KeyLayer { ALPHA, SYMBOLS1, SYMBOLS2 }
enum class KeyKind { CHAR, SHIFT, BACKSPACE, LAYER }

data class AltKeyOption(
    val label: String,
    val value: String,
    val hint: String? = null
)

data class KeyDef(
    val id: String,
    val label: String,
    val shiftLabel: String? = null,
    val subLabel: String? = null,
    val value: String? = null,
    val shiftValue: String? = null,
    val kind: KeyKind = KeyKind.CHAR,
    val flex: Float = 1f,
    val altOptions: List<AltKeyOption> = emptyList()
)

object KeyboardLayouts {
    val NUMBER_ROW_EN = listOf(
        KeyDef("n1", "1", value = "1"), KeyDef("n2", "2", value = "2"),
        KeyDef("n3", "3", value = "3"), KeyDef("n4", "4", value = "4"),
        KeyDef("n5", "5", value = "5"), KeyDef("n6", "6", value = "6"),
        KeyDef("n7", "7", value = "7"), KeyDef("n8", "8", value = "8"),
        KeyDef("n9", "9", value = "9"), KeyDef("n0", "0", value = "0")
    )

    val NUMBER_ROW_BN = listOf(
        KeyDef("bn1", "১", value = "১"), KeyDef("bn2", "২", value = "২"),
        KeyDef("bn3", "৩", value = "৩"), KeyDef("bn4", "৪", value = "৪"),
        KeyDef("bn5", "৫", value = "৫"), KeyDef("bn6", "৬", value = "৬"),
        KeyDef("bn7", "৭", value = "৭"), KeyDef("bn8", "৮", value = "৮"),
        KeyDef("bn9", "৯", value = "৯"), KeyDef("bn0", "০", value = "০")
    )

    val QWERTY_ROWS: List<List<KeyDef>> = listOf(
        listOf(
            KeyDef("q", "Q", subLabel = "1", value = "q", shiftValue = "Q"),
            KeyDef("w", "W", subLabel = "2", value = "w", shiftValue = "W"),
            KeyDef("e", "E", subLabel = "3", value = "e", shiftValue = "E"),
            KeyDef("r", "R", subLabel = "4", value = "r", shiftValue = "R"),
            KeyDef("t", "T", subLabel = "5", value = "t", shiftValue = "T"),
            KeyDef("y", "Y", subLabel = "6", value = "y", shiftValue = "Y"),
            KeyDef("u", "U", subLabel = "7", value = "u", shiftValue = "U"),
            KeyDef("i", "I", subLabel = "8", value = "i", shiftValue = "I"),
            KeyDef("o", "O", subLabel = "9", value = "o", shiftValue = "O"),
            KeyDef("p", "P", subLabel = "0", value = "p", shiftValue = "P")
        ),
        listOf(
            KeyDef("a", "A", subLabel = "@", value = "a", shiftValue = "A"),
            KeyDef("s", "S", subLabel = "#", value = "s", shiftValue = "S"),
            KeyDef("d", "D", subLabel = "$", value = "d", shiftValue = "D"),
            KeyDef("f", "F", subLabel = "%", value = "f", shiftValue = "F"),
            KeyDef("g", "G", subLabel = "&", value = "g", shiftValue = "G"),
            KeyDef("h", "H", subLabel = "-", value = "h", shiftValue = "H"),
            KeyDef("j", "J", subLabel = "+", value = "j", shiftValue = "J"),
            KeyDef("k", "K", subLabel = "(", value = "k", shiftValue = "K"),
            KeyDef("l", "L", subLabel = ")", value = "l", shiftValue = "L")
        ),
        listOf(
            KeyDef("shift", "SHIFT", kind = KeyKind.SHIFT, flex = 1.45f),
            KeyDef("z", "Z", subLabel = "*", value = "z", shiftValue = "Z"),
            KeyDef("x", "X", subLabel = "\"", value = "x", shiftValue = "X"),
            KeyDef("c", "C", subLabel = "'", value = "c", shiftValue = "C"),
            KeyDef("v", "V", subLabel = ":", value = "v", shiftValue = "V"),
            KeyDef("b", "B", subLabel = ";", value = "b", shiftValue = "B"),
            KeyDef("n", "N", subLabel = "!", value = "n", shiftValue = "N"),
            KeyDef("m", "M", subLabel = "?", value = "m", shiftValue = "M"),
            KeyDef("backspace", "BACK", kind = KeyKind.BACKSPACE, flex = 1.45f)
        )
    )

    val PROVAT_ROWS: List<List<KeyDef>> = listOf(
        listOf(
            KeyDef("p1", "দ", shiftLabel = "ধ", subLabel = "ধ", value = "দ", shiftValue = "ধ"),
            KeyDef("p2", "ূ", shiftLabel = "ঊ", subLabel = "ঊ", value = "ূ", shiftValue = "ঊ"),
            KeyDef("p3", "ী", shiftLabel = "ঈ", subLabel = "ঈ", value = "ী", shiftValue = "ঈ"),
            KeyDef("p4", "র", shiftLabel = "ড়", subLabel = "ড়", value = "র", shiftValue = "ড়",
                altOptions = listOf(
                    AltKeyOption("র্", "\u09B0\u09CD"),
                    AltKeyOption("ড়", "ড়"),
                    AltKeyOption("্র", "\u09CD\u09B0")
                )
            ),
            KeyDef("p5", "ট", shiftLabel = "ঠ", subLabel = "ঠ", value = "ট", shiftValue = "ঠ"),
            KeyDef("p6", "এ", shiftLabel = "ঐ", subLabel = "ঐ", value = "এ", shiftValue = "ঐ",
                altOptions = listOf(
                    AltKeyOption("ঞ", "ঞ"),
                    AltKeyOption("ঐ", "ঐ")
                )
            ),
            KeyDef("p7", "ু", shiftLabel = "উ", subLabel = "উ", value = "ু", shiftValue = "উ",
                altOptions = listOf(
                    AltKeyOption("ৎ", "ৎ"),
                    AltKeyOption("উ", "উ")
                )
            ),
            KeyDef("p8", "ি", shiftLabel = "ই", subLabel = "ই", value = "ি", shiftValue = "ই"),
            KeyDef("p9", "ও", shiftLabel = "ঔ", subLabel = "ঔ", value = "ও", shiftValue = "ঔ"),
            KeyDef("p10", "প", shiftLabel = "ফ", subLabel = "ফ", value = "প", shiftValue = "ফ"),
            KeyDef("p11", "ে", shiftLabel = "ৈ", subLabel = "ৈ", value = "ে", shiftValue = "ৈ"),
            KeyDef("p12", "ো", shiftLabel = "ৌ", subLabel = "ৌ", value = "ো", shiftValue = "ৌ")
        ),
        listOf(
            KeyDef("p13", "া", shiftLabel = "অ", subLabel = "অ", value = "া", shiftValue = "অ"),
            KeyDef("p14", "স", shiftLabel = "ষ", subLabel = "ষ", value = "স", shiftValue = "ষ"),
            KeyDef("p15", "ড", shiftLabel = "ঢ", subLabel = "ঢ", value = "ড", shiftValue = "ঢ"),
            KeyDef("p16", "ত", shiftLabel = "থ", subLabel = "থ", value = "ত", shiftValue = "থ"),
            KeyDef("p17", "গ", shiftLabel = "ঘ", subLabel = "ঘ", value = "গ", shiftValue = "ঘ"),
            KeyDef("p18", "হ", shiftLabel = "ঃ", subLabel = "ঃ", value = "হ", shiftValue = "ঃ"),
            KeyDef("p19", "জ", shiftLabel = "ঝ", subLabel = "ঝ", value = "জ", shiftValue = "ঝ"),
            KeyDef("p20", "ক", shiftLabel = "খ", subLabel = "খ", value = "ক", shiftValue = "খ"),
            KeyDef("p21", "ল", shiftLabel = "ং", subLabel = "ং", value = "ল", shiftValue = "ং")
        ),
        listOf(
            KeyDef("shift", "SHIFT", kind = KeyKind.SHIFT, flex = 1.25f),
            KeyDef("p22", "য়", shiftLabel = "য", subLabel = "য", value = "য়", shiftValue = "য",
                altOptions = listOf(
                    AltKeyOption("্য", "\u09CD\u09AF"),
                    AltKeyOption("য", "য")
                )
            ),
            KeyDef("p23", "শ", shiftLabel = "ঢ়", subLabel = "ঢ়", value = "শ", shiftValue = "ঢ়"),
            KeyDef("p24", "চ", shiftLabel = "ছ", subLabel = "ছ", value = "চ", shiftValue = "ছ"),
            KeyDef("p25", "আ", shiftLabel = "ঋ", subLabel = "ঋ", value = "আ", shiftValue = "ঋ"),
            KeyDef("p26", "ব", shiftLabel = "ভ", subLabel = "ভ", value = "ব", shiftValue = "ভ"),
            KeyDef("p27", "ন", shiftLabel = "ণ", subLabel = "ণ", value = "ন", shiftValue = "ণ"),
            KeyDef("p28", "ম", shiftLabel = "ঙ", subLabel = "ঙ", value = "ম", shiftValue = "ঙ"),
            KeyDef("p29", "<", shiftLabel = "ৃ", subLabel = "ৃ", value = "<", shiftValue = "ৃ",
                altOptions = listOf(
                    AltKeyOption("র্", "\u09B0\u09CD"),
                    AltKeyOption("্য", "\u09CD\u09AF"),
                    AltKeyOption("্র", "\u09CD\u09B0"),
                    AltKeyOption("ৃ", "ৃ")
                )
            ),
            KeyDef("p30", "্", shiftLabel = "ঁ", subLabel = "ঁ", value = "্", shiftValue = "ঁ",
                altOptions = listOf(
                    AltKeyOption("র্", "\u09B0\u09CD"),
                    AltKeyOption("্য", "\u09CD\u09AF"),
                    AltKeyOption("্র", "\u09CD\u09B0"),
                    AltKeyOption("ঁ", "ঁ")
                )
            ),
            KeyDef("backspace", "BACK", kind = KeyKind.BACKSPACE, flex = 1.25f)
        )
    )

    val SYMBOL_ROWS_1: List<List<KeyDef>> = listOf(
        listOf(
            KeyDef("s1", "1", subLabel = "১", value = "1"), KeyDef("s2", "2", subLabel = "২", value = "2"),
            KeyDef("s3", "3", subLabel = "৩", value = "3"), KeyDef("s4", "4", subLabel = "৪", value = "4"),
            KeyDef("s5", "5", subLabel = "৫", value = "5"), KeyDef("s6", "6", subLabel = "৬", value = "6"),
            KeyDef("s7", "7", subLabel = "৭", value = "7"), KeyDef("s8", "8", subLabel = "৮", value = "8"),
            KeyDef("s9", "9", subLabel = "৯", value = "9"), KeyDef("s0", "0", subLabel = "০", value = "0")
        ),
        listOf(
            KeyDef("sy1", "@", value = "@"), KeyDef("sy2", "#", value = "#"),
            KeyDef("sy3", "৳", subLabel = "$", value = "৳"), KeyDef("sy4", "_", value = "_"),
            KeyDef("sy5", "&", value = "&"), KeyDef("sy6", "-", value = "-"),
            KeyDef("sy7", "+", value = "+"), KeyDef("sy8", "(", value = "("),
            KeyDef("sy9", ")", value = ")"), KeyDef("sy10", "/", value = "/")
        ),
        listOf(
            KeyDef("layer2", "=\\<", kind = KeyKind.LAYER, flex = 1.45f),
            KeyDef("sy11", "*", value = "*"), KeyDef("sy12", "\"", value = "\""),
            KeyDef("sy13", "'", value = "'"), KeyDef("sy14", ":", value = ":"),
            KeyDef("sy15", ";", value = ";"), KeyDef("sy16", "!", value = "!"),
            KeyDef("sy17", "?", value = "?"),
            KeyDef("backspace", "BACK", kind = KeyKind.BACKSPACE, flex = 1.45f)
        )
    )

    val SYMBOL_ROWS_2: List<List<KeyDef>> = listOf(
        NUMBER_ROW_BN,
        listOf(
            KeyDef("sb2_1", "~", value = "~"), KeyDef("sb2_2", "`", value = "`"),
            KeyDef("sb2_3", "|", value = "|"), KeyDef("sb2_4", "•", value = "•"),
            KeyDef("sb2_5", "√", value = "√"), KeyDef("sb2_6", "$", value = "$"),
            KeyDef("sb2_7", "€", value = "€"), KeyDef("sb2_8", "£", value = "£"),
            KeyDef("sb2_9", "%", value = "%"), KeyDef("sb2_10", "°", value = "°")
        ),
        listOf(
            KeyDef("layer1", "?123", kind = KeyKind.LAYER, flex = 1.45f),
            KeyDef("sb2_11", "=", value = "="), KeyDef("sb2_12", "{", value = "{"),
            KeyDef("sb2_13", "}", value = "}"), KeyDef("sb2_14", "[", value = "["),
            KeyDef("sb2_15", "]", value = "]"), KeyDef("sb2_16", "।", value = "।"),
            KeyDef("sb2_17", "—", value = "—"),
            KeyDef("backspace", "BACK", kind = KeyKind.BACKSPACE, flex = 1.45f)
        )
    )
}
