package com.ridmikstudio.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

private class BoardBackgroundDrawable(
    private val theme: KeyboardTheme,
    private val density: Float
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val patternPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var hexShader: BitmapShader? = null
    private var starShader: BitmapShader? = null
    private var polyShader: BitmapShader? = null
    private var lastW = -1
    private var lastH = -1

    private fun ensureHexShader() {
        if (hexShader != null) return
        val w = maxOf(24, (56f * density).toInt())
        val h = maxOf(42, (98f * density).toInt())
        val tile = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        val sx = w / 56f
        val sy = h / 98f

        val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(38, 185, 28, 28)
        }
        val innerPath = Path().apply {
            moveTo(28f * sx, 5f * sy)
            lineTo(51f * sx, 18.5f * sy)
            lineTo(51f * sx, 46.5f * sy)
            lineTo(28f * sx, 60f * sy)
            lineTo(5f * sx, 46.5f * sy)
            lineTo(5f * sx, 18.5f * sy)
            close()
        }
        c.drawPath(innerPath, innerPaint)

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(122, 255, 36, 50)
            strokeWidth = 1.4f * density
            strokeJoin = Paint.Join.ROUND
        }
        val lattice = Path().apply {
            moveTo(28f * sx, 0f)
            lineTo(56f * sx, 16.3f * sy)
            lineTo(56f * sx, 49f * sy)
            lineTo(28f * sx, 65.3f * sy)
            lineTo(0f, 49f * sy)
            lineTo(0f, 16.3f * sy)
            close()
            moveTo(28f * sx, 98f * sy)
            lineTo(56f * sx, 81.7f * sy)
            lineTo(56f * sx, 49f * sy)
            moveTo(0f, 49f * sy)
            lineTo(0f, 81.7f * sy)
            lineTo(28f * sx, 98f * sy)
        }
        c.drawPath(lattice, strokePaint)
        hexShader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    private fun ensureStarShader() {
        if (starShader != null) return
        val sz = maxOf(48, (90f * density).toInt())
        val tile = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        val s = sz / 90f

        val starStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(74, 255, 255, 255)
            strokeWidth = 1.1f * density
            strokeJoin = Paint.Join.ROUND
        }
        fun drawStar(pts: FloatArray) {
            val p = Path()
            p.moveTo(pts[0] * s, pts[1] * s)
            var i = 2
            while (i < pts.size) {
                p.lineTo(pts[i] * s, pts[i + 1] * s)
                i += 2
            }
            p.close()
            c.drawPath(p, starStroke)
        }
        drawStar(floatArrayOf(20f, 6f, 22.8f, 14f, 31f, 14f, 24.4f, 19f, 26.9f, 27f, 20f, 22.2f, 13.1f, 27f, 15.6f, 19f, 9f, 14f, 17.2f, 14f))
        starStroke.color = Color.argb(62, 209, 250, 229)
        drawStar(floatArrayOf(68f, 46f, 70f, 51.5f, 76f, 51.5f, 71.2f, 55f, 73f, 60.5f, 68f, 57f, 63f, 60.5f, 64.8f, 55f, 60f, 51.5f, 66f, 51.5f))

        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        dotPaint.color = Color.argb(140, 255, 255, 255)
        c.drawCircle(48f * s, 18f * s, 1.3f * s, dotPaint)
        dotPaint.color = Color.argb(115, 255, 255, 255)
        c.drawCircle(12f * s, 62f * s, 1.1f * s, dotPaint)
        dotPaint.color = Color.argb(130, 255, 255, 255)
        c.drawCircle(80f * s, 22f * s, 0.9f * s, dotPaint)
        dotPaint.color = Color.argb(105, 255, 255, 255)
        c.drawCircle(38f * s, 76f * s, 1.2f * s, dotPaint)

        starShader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    private fun ensurePolyShader() {
        if (polyShader != null) return
        val sz = maxOf(64, (120f * density).toInt())
        val tile = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        val s = sz / 120f

        val facetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        fun poly(alpha: Int, rgb: Int, pts: FloatArray) {
            facetPaint.color = Color.argb(alpha, rgb, rgb, rgb)
            val p = Path()
            p.moveTo(pts[0] * s, pts[1] * s)
            var i = 2
            while (i < pts.size) {
                p.lineTo(pts[i] * s, pts[i + 1] * s)
                i += 2
            }
            p.close()
            c.drawPath(p, facetPaint)
        }
        poly(12, 255, floatArrayOf(0f, 0f, 70f, 0f, 45f, 55f, 0f, 40f))
        poly(92, 0, floatArrayOf(70f, 0f, 120f, 20f, 95f, 85f, 45f, 55f))
        poly(8, 255, floatArrayOf(0f, 40f, 45f, 55f, 25f, 120f, 0f, 120f))
        poly(6, 255, floatArrayOf(45f, 55f, 95f, 85f, 120f, 120f, 25f, 120f))

        polyShader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        fillPaint.color = theme.boardBg
        canvas.drawRect(b, fillPaint)

        when (theme.boardPatternKind) {
            "hex" -> {
                ensureHexShader()
                patternPaint.shader = hexShader
                canvas.drawRect(b, patternPaint)
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = RadialGradient(
                        b.left + w * 0.5f,
                        b.top + h * 0.30f,
                        maxOf(w, h) * 0.65f,
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.62f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
            "stars" -> {
                ensureStarShader()
                patternPaint.shader = starShader
                canvas.drawRect(b, patternPaint)
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = RadialGradient(
                        b.left + w * 0.5f,
                        b.top + h * 0.22f,
                        maxOf(w, h) * 0.68f,
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.60f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
            "poly" -> {
                ensurePolyShader()
                patternPaint.shader = polyShader
                canvas.drawRect(b, patternPaint)
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = RadialGradient(
                        b.left + w * 0.3f,
                        b.top + h * 0.25f,
                        maxOf(w, h) * 0.72f,
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.60f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
            "radial" -> {
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = RadialGradient(
                        b.left + w * 0.5f,
                        b.top + h * 0.42f,
                        maxOf(w, h) * 0.65f,
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.55f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
            "bottomGlow" -> {
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = RadialGradient(
                        b.left + w * 0.5f,
                        b.bottom.toFloat(),
                        maxOf(w, h) * 0.72f,
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.55f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
            "diag3d" -> {
                if (lastW != b.width() || lastH != b.height()) {
                    lastW = b.width()
                    lastH = b.height()
                    overlayPaint.shader = LinearGradient(
                        b.left.toFloat(),
                        b.top.toFloat(),
                        b.left + w * 0.36f,
                        b.bottom.toFloat(),
                        intArrayOf(theme.boardGlowColor, theme.boardMidColor, theme.boardEndColor),
                        floatArrayOf(0f, 0.52f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(b, overlayPaint)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

private class KeycapDrawable(
    private val baseBg: Int,
    private val gradTop: Int,
    private val gradMid: Int,
    private val gradBot: Int,
    private val baseBorder: Int,
    private val pressedBg: Int,
    private val pressedBorder: Int,
    private val glowColor: Int,
    private val haloColor: Int,
    private val is3dBevel: Boolean,
    private val hasInnerDish: Boolean,
    private val hasTopGloss: Boolean,
    private val isLightTheme: Boolean,
    private val useGradient: Boolean,
    private val radiusPx: Float,
    private val density: Float
) : Drawable() {

    private var isDown = false
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dishPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bodyRect = RectF()
    private val dishRect = RectF()
    private val lipRect = RectF()
    private val haloRect = RectF()
    private var lastW = -1f
    private var lastH = -1f

    fun setPressedState(down: Boolean) {
        if (isDown == down) return
        isDown = down
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 2f || h <= 2f) return

        val lipOffset = if (hasInnerDish) 3.2f * density else if (is3dBevel) 2.5f * density else 0f
        val topDrop = if (is3dBevel && isDown) 1.5f * density else 0f
        val inset = if (is3dBevel) 0.5f * density else 1.0f * density

        bodyRect.set(
            b.left + inset,
            b.top + inset + topDrop,
            b.right - inset,
            b.bottom - inset - lipOffset + (if (isDown && is3dBevel) 1.0f * density else 0f)
        )
        val r = minOf(radiusPx, bodyRect.height() / 2f)

        // Outer neon / champagne halo (works for both flat neon and 3D halo themes)
        val effectiveHalo = if (haloColor != 0) haloColor else if (!is3dBevel) glowColor else 0
        if (effectiveHalo != 0) {
            val gAlpha = Color.alpha(effectiveHalo)
            val gR = Color.red(effectiveHalo)
            val gG = Color.green(effectiveHalo)
            val gB = Color.blue(effectiveHalo)

            strokePaint.color = Color.argb((gAlpha * 0.48f).toInt(), gR, gG, gB)
            strokePaint.strokeWidth = 2.6f * density
            haloRect.set(bodyRect)
            haloRect.inset(-0.7f * density, -0.7f * density)
            canvas.drawRoundRect(haloRect, r + 0.7f * density, r + 0.7f * density, strokePaint)
        }

        // 3D bottom lip (bevel depth block underneath the cap)
        if (is3dBevel && glowColor != 0) {
            fillPaint.shader = null
            fillPaint.color = glowColor
            lipRect.set(
                bodyRect.left,
                bodyRect.top + lipOffset,
                bodyRect.right,
                b.bottom - inset
            )
            canvas.drawRoundRect(lipRect, r, r, fillPaint)
        }

        // Key surface fill (3-stop gradient or pressed flat color)
        if (!isDown && useGradient && gradTop != 0) {
            if (lastW != w || lastH != h || fillPaint.shader == null) {
                lastW = w
                lastH = h
                fillPaint.shader = LinearGradient(
                    0f,
                    bodyRect.top,
                    0f,
                    bodyRect.bottom,
                    intArrayOf(gradTop, gradMid, gradBot),
                    floatArrayOf(0f, 0.54f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        } else {
            fillPaint.shader = null
            fillPaint.color = if (isDown) pressedBg else baseBg
        }
        canvas.drawRoundRect(bodyRect, r, r, fillPaint)

        // Sculpted recessed mechanical keycap dish (Image 5)
        if (hasInnerDish && bodyRect.width() > 14f * density && bodyRect.height() > 14f * density) {
            dishRect.set(
                bodyRect.left + 3.0f * density,
                bodyRect.top + 2.4f * density,
                bodyRect.right - 3.0f * density,
                bodyRect.bottom - 3.6f * density
            )
            val dr = maxOf(2f * density, r - 2.0f * density)
            dishPaint.shader = LinearGradient(
                0f,
                dishRect.top,
                0f,
                dishRect.bottom,
                intArrayOf(
                    if (isDown) Color.parseColor("#13161A") else Color.parseColor("#1B1E24"),
                    if (isDown) Color.parseColor("#181B20") else Color.parseColor("#242830")
                ),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(dishRect, dr, dr, dishPaint)
            strokePaint.color = Color.argb(65, 255, 255, 255)
            strokePaint.strokeWidth = 0.8f * density
            canvas.drawRoundRect(dishRect, dr, dr, strokePaint)
        }

        // Subtle top inner glass specular highlight
        if (hasTopGloss && !isDown) {
            glossPaint.color = if (isLightTheme) Color.argb(140, 255, 255, 255) else if (haloColor != 0) Color.argb(72, 255, 255, 255) else Color.argb(42, 255, 255, 255)
            glossPaint.strokeWidth = (if (haloColor != 0) 1.3f else 1.0f) * density
            val padX = maxOf(r * 0.55f, 4f * density)
            val yLine = bodyRect.top + 1.2f * density
            canvas.drawLine(bodyRect.left + padX, yLine, bodyRect.right - padX, yLine, glossPaint)
        }

        // Crisp border stroke
        strokePaint.color = if (isDown) pressedBorder else baseBorder
        strokePaint.strokeWidth = (if (effectiveHalo != 0) 1.25f else 1.0f) * density
        canvas.drawRoundRect(bodyRect, r, r, strokePaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

private class ShiftKeyIconView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private var showCapsBar: Boolean = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val capRect = RectF()

    fun setStyle(fg: Int, capsLock: Boolean) {
        fgColor = fg
        showCapsBar = capsLock
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val unit = minOf(width, height).toFloat()
        if (unit <= 4f) return
        val s = (unit * 0.84f) / 24f
        val ox = (width - 24f * s) / 2f
        val oy = (height - 24f * s) / 2f - (if (showCapsBar) 1.2f * s else 0f)

        paint.color = fgColor
        path.reset()
        path.moveTo(ox + 12f * s, oy + 4f * s)
        path.lineTo(ox + 4f * s, oy + 12f * s)
        path.lineTo(ox + 9f * s, oy + 12f * s)
        path.lineTo(ox + 9f * s, oy + 19f * s)
        path.lineTo(ox + 15f * s, oy + 19f * s)
        path.lineTo(ox + 15f * s, oy + 12f * s)
        path.lineTo(ox + 20f * s, oy + 12f * s)
        path.close()
        canvas.drawPath(path, paint)

        if (showCapsBar) {
            capRect.set(ox + 7f * s, oy + 20.8f * s, ox + 17f * s, oy + 22.8f * s)
            canvas.drawRoundRect(capRect, 1f * s, 1f * s, paint)
        }
    }
}

private class BackspaceKeyIconView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val outlinePath = Path()

    fun setStyle(fg: Int) {
        fgColor = fg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val unit = minOf(width, height).toFloat()
        if (unit <= 4f) return
        val s = (unit * 0.84f) / 24f
        val ox = (width - 24f * s) / 2f
        val oy = (height - 24f * s) / 2f

        paint.color = fgColor
        paint.strokeWidth = 2.0f * s
        outlinePath.reset()
        outlinePath.moveTo(ox + 20f * s, oy + 5f * s)
        outlinePath.lineTo(ox + 9f * s, oy + 5f * s)
        outlinePath.lineTo(ox + 2.5f * s, oy + 12f * s)
        outlinePath.lineTo(ox + 9f * s, oy + 19f * s)
        outlinePath.lineTo(ox + 20f * s, oy + 19f * s)
        outlinePath.quadTo(ox + 21.8f * s, oy + 19f * s, ox + 21.8f * s, oy + 17f * s)
        outlinePath.lineTo(ox + 21.8f * s, oy + 7f * s)
        outlinePath.quadTo(ox + 21.8f * s, oy + 5f * s, ox + 20f * s, oy + 5f * s)
        outlinePath.close()
        canvas.drawPath(outlinePath, paint)

        canvas.drawLine(ox + 17.5f * s, oy + 9.5f * s, ox + 12.5f * s, oy + 14.5f * s, paint)
        canvas.drawLine(ox + 12.5f * s, oy + 9.5f * s, ox + 17.5f * s, oy + 14.5f * s, paint)
    }
}

private class ToggleCircleTView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private var activeBg: Int = Color.TRANSPARENT
    private var isActive: Boolean = false
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val arcRect = RectF()
    private val arrowPath = Path()

    fun setStyle(active: Boolean, fg: Int, bg: Int) {
        isActive = active
        fgColor = fg
        activeBg = bg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val minSide = minOf(width, height).toFloat()
        if (minSide <= 6f) return

        val cx = width / 2f
        val cy = height / 2f

        if (isActive) {
            fillPaint.color = activeBg
            canvas.drawCircle(cx, cy, minSide * 0.45f, fillPaint)
        }

        // Normalized 24x24 SVG coordinate space (matching Web SVG)
        val box = minSide * 0.72f
        val s = box / 24f
        val ox = cx - 12f * s
        val oy = cy - 12f * s

        ringPaint.color = fgColor
        ringPaint.strokeWidth = 1.4f * s
        arcRect.set(ox + (12f - 8.6f) * s, oy + (12f - 8.6f) * s, ox + (12f + 8.6f) * s, oy + (12f + 8.6f) * s)

        // Slender circular double-arrows leaving top & bottom clear
        canvas.drawArc(arcRect, 204f, 128f, false, ringPaint)
        canvas.drawArc(arcRect, 24f, 128f, false, ringPaint)

        // Small compact arrowheads tucked cleanly at 332 deg & 152 deg
        drawChevron(canvas, ox, oy, s, 19.0f, 4.4f, 19.0f, 6.8f, 16.6f, 6.8f)
        drawChevron(canvas, ox, oy, s, 5.0f, 19.6f, 5.0f, 17.2f, 7.4f, 17.2f)

        // Crisp geometric Serif T so top horizontal crossbar is unmistakably sharp
        tPaint.color = fgColor
        tPaint.strokeWidth = 2.1f * s
        canvas.drawLine(ox + 7.8f * s, oy + 8.4f * s, ox + 16.2f * s, oy + 8.4f * s, tPaint)

        tPaint.strokeWidth = 1.4f * s
        canvas.drawLine(ox + 7.9f * s, oy + 8.4f * s, ox + 7.9f * s, oy + 9.8f * s, tPaint)
        canvas.drawLine(ox + 16.1f * s, oy + 8.4f * s, ox + 16.1f * s, oy + 9.8f * s, tPaint)

        tPaint.strokeWidth = 1.95f * s
        canvas.drawLine(ox + 12.0f * s, oy + 8.4f * s, ox + 12.0f * s, oy + 15.8f * s, tPaint)

        tPaint.strokeWidth = 1.45f * s
        canvas.drawLine(ox + 10.3f * s, oy + 15.8f * s, ox + 13.7f * s, oy + 15.8f * s, tPaint)
    }

    private fun drawChevron(
        canvas: Canvas,
        ox: Float,
        oy: Float,
        s: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float
    ) {
        arrowPath.reset()
        arrowPath.moveTo(ox + x1 * s, oy + y1 * s)
        arrowPath.lineTo(ox + x2 * s, oy + y2 * s)
        arrowPath.lineTo(ox + x3 * s, oy + y3 * s)
        canvas.drawPath(arrowPath, ringPaint)
    }
}

private class MicIconView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val capsuleRect = RectF()
    private val cradleRect = RectF()

    fun setStyle(fg: Int) {
        fgColor = fg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val unit = minOf(width, height).toFloat()
        if (unit <= 4f) return

        fillPaint.color = fgColor
        strokePaint.color = fgColor
        strokePaint.strokeWidth = 1.8f * d

        // Capsule head
        val capW = unit * 0.24f
        val capH = unit * 0.42f
        val capTop = cy - unit * 0.30f
        capsuleRect.set(cx - capW / 2f, capTop, cx + capW / 2f, capTop + capH)
        canvas.drawRoundRect(capsuleRect, capW / 2f, capW / 2f, fillPaint)

        // U cradle arc around capsule
        val crRx = unit * 0.23f
        val crTop = cy - unit * 0.14f
        val crBottom = cy + unit * 0.19f
        cradleRect.set(cx - crRx, crTop, cx + crRx, crBottom)
        canvas.drawArc(cradleRect, 0f, 180f, false, strokePaint)

        // Vertical stem + base line
        canvas.drawLine(cx, crBottom, cx, cy + unit * 0.31f, strokePaint)
        canvas.drawLine(cx - unit * 0.15f, cy + unit * 0.31f, cx + unit * 0.15f, cy + unit * 0.31f, strokePaint)
    }
}

class RidmikKeyboardView(
    context: Context,
    private val callbacks: Callbacks
) : LinearLayout(context) {

    interface Callbacks {
        fun onCommitText(text: String)
        fun onBackspace()
        fun onDeleteWord()
        fun onEnter()
        fun onMoveCursor(action: String)
        fun onSelectAll()
        fun onCopy()
        fun onCut()
        fun onPasteSystem()
        fun onCopyVisibleScreen(): String
        fun isScreenReaderEnabled(): Boolean
        fun onOpenAccessibilitySettings()
        fun onCopyPlainText(text: String)
        fun onVoiceInput()
        fun onApplySuggestion(candidate: SpellCandidate)
        fun getTextBeforeCursor(): String
        fun onPreferencesChanged()
        fun onSoundPreview()
    }

    enum class Panel { KEYS, EMOJI, CURSOR, CLIPBOARD, THEMES, SETTINGS }

    private val prefs = context.getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
    private val clipStore = ClipboardStore(context)
    private val mainHandler = Handler(Looper.getMainLooper())

    var language: KeyboardLanguage = if (prefs.getString("last_language", "ENGLISH") == "PROVAT") KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
        private set
    private var layer: KeyLayer = KeyLayer.ALPHA
    private var shift: Boolean = false
    private var capsLock: Boolean = false
    private var lastShiftTap: Long = 0L
    private var activePanel: Panel = Panel.KEYS
    private var showToolbar: Boolean = false
    private var isVoiceListening: Boolean = false
    private var emojiCatId: String = "recent"
    private var clipPinnedTab: Boolean = true
    private var cursorTranslatorOpen: Boolean = false
    private var transSourceText: String = ""
    private var transResultText: String = ""
    private var transTargetMode: String = "auto"
    private var transLoading: Boolean = false
    private var transStatusMsg: String = ""
    private var needScreenPermPrompt: Boolean = false

    private var theme: KeyboardTheme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
    private var keyHeightMode: String = prefs.getString("key_height", "standard") ?: "standard"
    private var keySizeMode: String = prefs.getString("key_size", "medium") ?: "medium"
    private var soundProfile: String = prefs.getString("sound_profile", "mechanical") ?: "mechanical"
    private var showNumberRow: Boolean = prefs.getBoolean("show_num_row", false)
    private var showPopup: Boolean = prefs.getBoolean("show_popup", true)
    private var spellCheckEnabled: Boolean = prefs.getBoolean("spell_check", true)
    private val recentEmojis: MutableList<String> = (
        prefs.getString("recent_emojis", "😀,❤️,🇧🇩,👍,🔥,✨") ?: "😀,❤️,🇧🇩,👍,🔥,✨"
    ).split(",").filter { it.isNotEmpty() }.toMutableList()

    private var currentSuggestions: List<SpellCandidate> = emptyList()
    private var aiSuggestions: List<SpellCandidate> = emptyList()
    private var aiDebounceRunnable: Runnable? = null

    private val topBarRow = LinearLayout(context)
    private val toolbarContainer = LinearLayout(context)
    private val suggestionStripScroll = HorizontalScrollView(context)
    private val suggestionStrip = LinearLayout(context)
    private val bodyContainer = FrameLayout(context)

    private var keyPopupWindow: PopupWindow? = null
    private var keyPopupText: TextView? = null
    private var keyPopupMark: BanglaMarkView? = null
    private var altPopupWindow: PopupWindow? = null
    private var altActiveOptions: List<AltKeyOption> = emptyList()
    private val altTileCards = ArrayList<FrameLayout>()
    private var altSelectedIdx: Int = 0
    private var altPopupScreenX: Float = 0f
    private var altTileStepPx: Float = 1f

    private var bsHoldRunnable: Runnable? = null
    private var bsRepeatRunnable: Runnable? = null
    private var bsDidRepeat = false
    private var bsDidSwipe = false
    private var bsStartX = 0f

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        rebuildAll()
    }

    private fun recordRecentEmoji(em: String) {
        recentEmojis.remove(em)
        recentEmojis.add(0, em)
        if (recentEmojis.size > 28) {
            recentEmojis.subList(28, recentEmojis.size).clear()
        }
        prefs.edit().putString("recent_emojis", recentEmojis.joinToString(",")).apply()
    }

    fun setVoiceListening(listening: Boolean) {
        if (isVoiceListening == listening) return
        isVoiceListening = listening
        renderTopBarContent()
    }

    private fun clearBackspaceRepeat() {
        bsHoldRunnable?.let { mainHandler.removeCallbacks(it) }
        bsRepeatRunnable?.let { mainHandler.removeCallbacks(it) }
        bsHoldRunnable = null
        bsRepeatRunnable = null
    }

    fun resetToKeysPanel() {
        hideKeyPopupBubble()
        hideAltPopup()
        clearBackspaceRepeat()
        val needsRebuild = (
            activePanel != Panel.KEYS ||
            layer != KeyLayer.ALPHA ||
            showToolbar ||
            shift ||
            capsLock
        )
        activePanel = Panel.KEYS
        layer = KeyLayer.ALPHA
        shift = false
        capsLock = false
        showToolbar = false
        cursorTranslatorOpen = false
        needScreenPermPrompt = false
        if (needsRebuild) {
            rebuildAll()
        }
    }

    fun reloadFromPrefs(resetToKeys: Boolean = false) {
        if (resetToKeys) {
            hideKeyPopupBubble()
            hideAltPopup()
            clearBackspaceRepeat()
            activePanel = Panel.KEYS
            layer = KeyLayer.ALPHA
            shift = false
            capsLock = false
            showToolbar = false
            cursorTranslatorOpen = false
            needScreenPermPrompt = false
        }
        theme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
        keyHeightMode = prefs.getString("key_height", "standard") ?: "standard"
        keySizeMode = prefs.getString("key_size", "medium") ?: "medium"
        soundProfile = prefs.getString("sound_profile", "mechanical") ?: "mechanical"
        showNumberRow = prefs.getBoolean("show_num_row", false)
        showPopup = prefs.getBoolean("show_popup", true)
        spellCheckEnabled = prefs.getBoolean("spell_check", true)
        rebuildAll()
    }

    fun refreshSuggestions() {
        if (activePanel != Panel.KEYS || showToolbar) {
            renderTopBarContent()
            return
        }
        if (!spellCheckEnabled) {
            currentSuggestions = emptyList()
            renderSuggestions()
            return
        }
        val before = callbacks.getTextBeforeCursor()
        val local = SpellDetector.suggestLocal(before, language)
        currentSuggestions = if (aiSuggestions.isNotEmpty()) {
            (aiSuggestions + local).distinctBy { it.word }.take(5)
        } else local
        renderSuggestions()
        scheduleAiCheck(before)
    }

    private fun scheduleAiCheck(before: String) {
        aiDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        val apiKey = prefs.getString("gemini_api_key", "") ?: ""
        if (apiKey.isBlank()) return

        val trimmedEnd = before.trimEnd()
        val word = if (before.endsWith(" ")) trimmedEnd.split(Regex("\\s+")).lastOrNull().orEmpty()
        else before.substringAfterLast(' ').substringAfterLast('\n')
        if (word.length < 3 || SpellDetector.isKnownWord(word, language)) {
            aiSuggestions = emptyList()
            return
        }
        val r = Runnable {
            Thread {
                val res = SpellDetector.fetchAiCorrection(apiKey, word, before.dropLast(word.length), language)
                if (res.isNotEmpty()) {
                    val isLast = before.endsWith(" ")
                    aiSuggestions = res.map { SpellCandidate(it, isCorrection = true, isAi = true, replaceLastWord = isLast) }
                    mainHandler.post {
                        val local = SpellDetector.suggestLocal(callbacks.getTextBeforeCursor(), language)
                        currentSuggestions = (aiSuggestions + local).distinctBy { it.word }.take(5)
                        renderSuggestions()
                    }
                }
            }.start()
        }
        aiDebounceRunnable = r
        mainHandler.postDelayed(r, 900L)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBox(bg: Int, border: Int, radiusDp: Int = 8, strokeDp: Int = 1): GradientDrawable {
        return GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(strokeDp), border)
        }
    }

    private fun makeKeycapDrawable(
        bg: Int,
        border: Int,
        radiusDp: Int = theme.cornerRadiusDp,
        useGradient: Boolean = true
    ): KeycapDrawable {
        val d = resources.displayMetrics.density
        return KeycapDrawable(
            baseBg = bg,
            gradTop = theme.keyGradTop,
            gradMid = theme.keyGradMid,
            gradBot = theme.keyGradBot,
            baseBorder = border,
            pressedBg = theme.keyPressedBg,
            pressedBorder = theme.accent,
            glowColor = theme.keyGlowColor,
            haloColor = theme.haloColor,
            is3dBevel = theme.is3dBevel,
            hasInnerDish = theme.hasInnerDish,
            hasTopGloss = theme.hasTopGloss,
            isLightTheme = theme.isLight,
            useGradient = useGradient,
            radiusPx = dp(radiusDp).toFloat(),
            density = d
        )
    }

    fun rebuildAll() {
        hideAltPopup()
        background = BoardBackgroundDrawable(theme, resources.displayMetrics.density)
        removeAllViews()
        buildTopBar()
        addView(topBarRow)
        addView(bodyContainer, LayoutParams(LayoutParams.MATCH_PARENT, dp(keysBodyHeightDp())))
        renderBody()
        refreshSuggestions()
    }

    private fun buildTopBar() {
        topBarRow.removeAllViews()
        topBarRow.orientation = HORIZONTAL
        topBarRow.gravity = Gravity.CENTER_VERTICAL
        topBarRow.setBackgroundColor(if (showToolbar) theme.toolbarBg else theme.suggestionBg)
        topBarRow.setPadding(dp(6), dp(4), dp(6), dp(4))
        topBarRow.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(44))
        topBarRow.visibility = View.VISIBLE

        // Leftmost circular-arrow T cycle toggle button
        val tToggle = ToggleCircleTView(context).apply {
            setStyle(
                active = showToolbar,
                fg = if (showToolbar) Color.WHITE else theme.accentText,
                bg = theme.accent
            )
            layoutParams = LayoutParams(dp(32), dp(32)).apply {
                setMargins(dp(2), 0, dp(4), 0)
            }
            contentDescription = "টুলবার ও সাজেশন পরিবর্তন"
            setOnClickListener {
                callbacks.onSoundPreview()
                showToolbar = !showToolbar
                renderTopBarContent()
            }
        }
        topBarRow.addView(tToggle)

        val sep = View(context).apply {
            setBackgroundColor(theme.keyBorder)
            layoutParams = LayoutParams(dp(1), dp(20)).apply { setMargins(dp(2), 0, dp(5), 0) }
        }
        topBarRow.addView(sep)

        buildToolbar()
        buildSuggestionStrip()
        topBarRow.addView(toolbarContainer, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        topBarRow.addView(suggestionStripScroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        renderTopBarContent()
    }

    private fun autoShowSuggestionsOnTyping() {
        if (showToolbar) {
            showToolbar = false
            renderTopBarContent()
        }
    }

    private fun renderTopBarContent() {
        topBarRow.visibility = View.VISIBLE
        topBarRow.setBackgroundColor(if (showToolbar) theme.toolbarBg else theme.suggestionBg)
        if (showToolbar) {
            toolbarContainer.visibility = View.VISIBLE
            suggestionStripScroll.visibility = View.GONE
            buildToolbar()
        } else {
            toolbarContainer.visibility = View.GONE
            suggestionStripScroll.visibility = View.VISIBLE
            renderSuggestions()
        }
    }

    private fun buildToolbar() {
        toolbarContainer.removeAllViews()
        toolbarContainer.orientation = HORIZONTAL
        toolbarContainer.gravity = Gravity.CENTER_VERTICAL
        toolbarContainer.setBackgroundColor(Color.TRANSPARENT)

        // 1. ব / En
        toolbarContainer.addView(makeToolBtn(if (language == KeyboardLanguage.ENGLISH) "ব" else "En", language == KeyboardLanguage.PROVAT) {
            language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
            prefs.edit().putString("last_language", language.name).apply()
            layer = KeyLayer.ALPHA
            shift = false
            capsLock = false
            activePanel = Panel.KEYS
            aiSuggestions = emptyList()
            rebuildAll()
        })

        // 2. Emoji
        toolbarContainer.addView(makeToolBtn("☺", activePanel == Panel.EMOJI) {
            activePanel = if (activePanel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI
            rebuildAll()
        })

        // 3. Cursor ◄|►
        toolbarContainer.addView(makeToolBtn("◄|►", activePanel == Panel.CURSOR) {
            activePanel = if (activePanel == Panel.CURSOR) Panel.KEYS else Panel.CURSOR
            rebuildAll()
        })

        // 4. Clipboard
        toolbarContainer.addView(makeToolBtn("📋", activePanel == Panel.CLIPBOARD) {
            activePanel = if (activePanel == Panel.CLIPBOARD) Panel.KEYS else Panel.CLIPBOARD
            rebuildAll()
        })

        // 5. Theme
        toolbarContainer.addView(makeToolBtn("🎨", activePanel == Panel.THEMES) {
            activePanel = if (activePanel == Panel.THEMES) Panel.KEYS else Panel.THEMES
            rebuildAll()
        })

        // 6. Settings Gear
        toolbarContainer.addView(makeToolBtn("⚙", activePanel == Panel.SETTINGS) {
            activePanel = if (activePanel == Panel.SETTINGS) Panel.KEYS else Panel.SETTINGS
            rebuildAll()
        })

        // 7. Crisp Vector Voice Microphone (replaces mouthpiece/karaoke emoji)
        val micWrap = FrameLayout(context).apply {
            background = roundedBox(
                if (isVoiceListening) theme.accent else Color.TRANSPARENT,
                if (isVoiceListening) theme.accent else Color.TRANSPARENT,
                8
            )
            layoutParams = LayoutParams(0, dp(34), 1f).apply {
                setMargins(dp(2), 0, dp(1), 0)
            }
            contentDescription = "ভয়েস টাইপিং"
            setOnClickListener {
                callbacks.onVoiceInput()
            }
        }
        val micIcon = MicIconView(context).apply {
            setStyle(if (isVoiceListening) Color.WHITE else theme.accentText)
            layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        }
        micWrap.addView(micIcon)
        toolbarContainer.addView(micWrap)
    }

    private fun makeToolBtn(label: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 14.5f
            typeface = FontHelper.forText(context, label, bold = true)
            gravity = Gravity.CENTER
            setTextColor(theme.accentText)
            background = roundedBox(
                if (active) Color.argb(45, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent)) else Color.TRANSPARENT,
                if (active) theme.accent else Color.TRANSPARENT,
                8
            )
            layoutParams = LayoutParams(0, dp(34), 1f).apply {
                setMargins(dp(1), 0, dp(1), 0)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildSuggestionStrip() {
        suggestionStripScroll.isHorizontalScrollBarEnabled = false
        suggestionStripScroll.setBackgroundColor(Color.TRANSPARENT)
        suggestionStrip.orientation = HORIZONTAL
        suggestionStrip.gravity = Gravity.CENTER_VERTICAL
        suggestionStrip.setPadding(dp(2), dp(2), dp(4), dp(2))
        suggestionStripScroll.removeAllViews()
        suggestionStripScroll.addView(suggestionStrip)
    }

    private fun renderSuggestions() {
        suggestionStrip.removeAllViews()

        if (isVoiceListening) {
            val listeningBadge = TextView(context).apply {
                text = "শুনছি... কথা বলুন (থামাতে T -> মাইক)"
                textSize = 12f
                typeface = FontHelper.banglaBold(context)
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = roundedBox(theme.accent, theme.accent, 7)
            }
            suggestionStrip.addView(listeningBadge)
            return
        }

        if (!spellCheckEnabled) {
            val offTv = TextView(context).apply {
                text = "শব্দ প্রেডিকশন বন্ধ"
                textSize = 11f
                typeface = FontHelper.banglaRegular(context)
                setTextColor(theme.subText)
            }
            suggestionStrip.addView(offTv)
            return
        }

        val hasCorr = currentSuggestions.any { it.isCorrection }
        val tagText = if (hasCorr) "শুদ্ধ:" else "শব্দ:"
        val tag = TextView(context).apply {
            text = tagText
            textSize = 11f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(if (hasCorr) theme.accentText else theme.subText)
            setPadding(dp(2), 0, dp(6), 0)
        }
        suggestionStrip.addView(tag)

        for ((idx, cand) in currentSuggestions.withIndex()) {
            val chipText = if (cand.isAi) "✦ ${cand.word}" else if (cand.isCorrection) "✓ ${cand.word}" else cand.word
            val chip = TextView(context).apply {
                text = chipText
                textSize = 13.5f
                typeface = FontHelper.forKeyText(context, cand.word, bold = (cand.isCorrection || idx == 0))
                setTextColor(if (cand.isCorrection && idx == 0) Color.WHITE else theme.keyText)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = roundedBox(
                    when {
                        cand.isCorrection && idx == 0 -> theme.accent
                        cand.isCorrection -> Color.argb(50, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        idx == 0 -> theme.keyBg
                        else -> Color.TRANSPARENT
                    },
                    if (cand.isCorrection || idx == 0) theme.accent else Color.TRANSPARENT,
                    7
                )
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, 0, dp(6), 0)
                }
                setOnClickListener {
                    aiSuggestions = emptyList()
                    callbacks.onApplySuggestion(cand)
                    refreshSuggestions()
                }
            }
            suggestionStrip.addView(chip)
        }
    }

    private fun renderBody() {
        hideAltPopup()
        bodyContainer.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(keysBodyHeightDp()))
        bodyContainer.removeAllViews()
        when (activePanel) {
            Panel.KEYS -> renderKeysPanel()
            Panel.EMOJI -> renderEmojiPanel()
            Panel.CURSOR -> renderCursorPanel()
            Panel.CLIPBOARD -> renderClipboardPanel()
            Panel.THEMES -> renderThemesPanel()
            Panel.SETTINGS -> renderSettingsPanel()
        }
    }

    private fun keyHeightDp(): Int = when (keyHeightMode) {
        "compact" -> 60
        "tall" -> 82
        else -> 72
    }

    private fun charTextSizeSp(): Float = when (keySizeMode) {
        "small" -> 19f
        "large" -> 29f
        else -> 24f
    }

    private fun fnTextSizeSp(): Float = when (keySizeMode) {
        "small" -> 17f
        "large" -> 24f
        else -> 21f
    }

    private fun layerTextSizeSp(): Float = when (keySizeMode) {
        "small" -> 12f
        "large" -> 16f
        else -> 14f
    }

    private fun markSizeDp(): Int = when (keySizeMode) {
        "small" -> 19
        "large" -> 28
        else -> 24
    }

    private fun subTextSizeSp(): Float = when (keySizeMode) {
        "small" -> 9.5f
        "large" -> 12f
        else -> 11f
    }

    private fun subMarkDp(): Int = when (keySizeMode) {
        "small" -> 10
        "large" -> 13
        else -> 12
    }

    private fun fnIconDp(): Int = when (keySizeMode) {
        "small" -> 19
        "large" -> 25
        else -> 22
    }

    private fun bottomPunctSizeSp(): Float = when (keySizeMode) {
        "small" -> 18f
        "large" -> 26f
        else -> 22f
    }

    private fun keysBodyHeightDp(): Int {
        val kH = keyHeightDp()
        val numPart = if (showNumberRow && layer == KeyLayer.ALPHA) 46 else 0
        return 6 + numPart + (kH * 4) + (6 * 3) + 8
    }

    private fun renderKeysPanel() {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        val keyH = dp(keyHeightDp())

        if (showNumberRow && layer == KeyLayer.ALPHA) {
            val numRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)).apply { bottomMargin = dp(6) }
            }
            val nums = if (language == KeyboardLanguage.ENGLISH) KeyboardLayouts.NUMBER_ROW_EN else KeyboardLayouts.NUMBER_ROW_BN
            for (k in nums) numRow.addView(createKeyView(k, dp(40)))
            root.addView(numRow)
        }

        val rows = when (layer) {
            KeyLayer.SYMBOLS1 -> KeyboardLayouts.SYMBOL_ROWS_1
            KeyLayer.SYMBOLS2 -> KeyboardLayouts.SYMBOL_ROWS_2
            KeyLayer.ALPHA -> if (language == KeyboardLanguage.PROVAT) KeyboardLayouts.PROVAT_ROWS else KeyboardLayouts.QWERTY_ROWS
        }

        for ((rIdx, row) in rows.withIndex()) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH).apply { bottomMargin = dp(6) }
                if (rIdx == 1 && row.size == 9) setPadding(dp(12), 0, dp(12), 0)
            }
            for (k in row) rowLayout.addView(createKeyView(k, keyH))
            root.addView(rowLayout)
        }

        // Bottom Row
        val bottomRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH)
        }

        bottomRow.addView(makeKeycapActionKey(
            label = if (layer == KeyLayer.ALPHA) "?123" else "ABC",
            weight = 1.25f,
            bg = theme.fnKeyBg,
            border = theme.fnKeyBorder,
            fg = if (theme.fnKeyAccent) Color.WHITE else if (theme.id == "starlight-3d-black") theme.keyText else theme.accentText,
            radiusDp = 28,
            useGradient = !theme.fnKeyAccent
        ) {
            callbacks.onSoundPreview()
            layer = if (layer == KeyLayer.ALPHA) KeyLayer.SYMBOLS1 else KeyLayer.ALPHA
            rebuildAll()
        }.apply { textSize = layerTextSizeSp() })

        bottomRow.addView(makeKeycapActionKey(",", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, theme.cornerRadiusDp, true) {
            autoShowSuggestionsOnTyping()
            callbacks.onCommitText(",")
            refreshSuggestions()
        }.apply { textSize = bottomPunctSizeSp() })

        bottomRow.addView(makeKeycapActionKey(
            label = "☺",
            weight = 0.95f,
            bg = theme.fnKeyBg,
            border = theme.fnKeyBorder,
            fg = if (theme.fnKeyAccent) Color.WHITE else if (theme.id == "starlight-3d-black") theme.keyText else if (theme.shiftColor != 0) theme.shiftColor else theme.accentText,
            radiusDp = theme.cornerRadiusDp,
            useGradient = !theme.fnKeyAccent
        ) {
            callbacks.onSoundPreview()
            activePanel = if (activePanel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI
            rebuildAll()
        }.apply {
            textSize = when (keySizeMode) {
                "small" -> 16f
                "large" -> 22f
                else -> 19f
            }
        })

        bottomRow.addView(createSpacebar(keyH))

        bottomRow.addView(makeKeycapActionKey(if (language == KeyboardLanguage.ENGLISH) "." else "।", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, theme.cornerRadiusDp, true) {
            autoShowSuggestionsOnTyping()
            callbacks.onCommitText(if (language == KeyboardLanguage.ENGLISH) "." else "।")
            refreshSuggestions()
        }.apply { textSize = bottomPunctSizeSp() })

        val enterBorder = if (theme.enterBorderColor != 0) theme.enterBorderColor else theme.enterBg
        val enterRad = if (theme.enterBorderColor != 0) theme.cornerRadiusDp else 12
        bottomRow.addView(makeKeycapActionKey("↵", 1.4f, theme.enterBg, enterBorder, theme.enterIcon, enterRad, theme.useGradientOnEnter) {
            autoShowSuggestionsOnTyping()
            aiSuggestions = emptyList()
            callbacks.onEnter()
            refreshSuggestions()
        }.apply {
            textSize = when (keySizeMode) {
                "small" -> 17f
                "large" -> 24f
                else -> 20f
            }
        })

        root.addView(bottomRow)
        bodyContainer.addView(root)
    }

    private fun createKeyView(k: KeyDef, keyH: Int): View {
        val isFn = k.kind != KeyKind.CHAR
        val isShiftActive = k.kind == KeyKind.SHIFT && (shift || capsLock)
        val bg = when {
            isShiftActive -> theme.accent
            isFn -> theme.fnKeyBg
            else -> theme.keyBg
        }
        val border = when {
            isShiftActive -> theme.accent
            isFn -> theme.fnKeyBorder
            else -> theme.keyBorder
        }
        val useGrad = !isShiftActive && !(isFn && theme.fnKeyAccent)
        val keyBgDrawable = makeKeycapDrawable(bg, border, theme.cornerRadiusDp, useGrad)

        val frame = FrameLayout(context).apply {
            background = keyBgDrawable
            layoutParams = LayoutParams(0, keyH, k.flex).apply {
                val gap = if (language == KeyboardLanguage.PROVAT && layer == KeyLayer.ALPHA) dp(1) else dp(2)
                setMargins(gap, 0, gap, 0)
            }
        }

        val displayChar = when {
            k.kind == KeyKind.SHIFT -> if (capsLock) "⇪" else "⇧"
            k.kind == KeyKind.BACKSPACE -> "⌫"
            shift && k.shiftLabel != null -> k.shiftLabel
            language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA ->
                if (shift) k.label.uppercase() else k.label.lowercase()
            else -> k.label
        }

        if (k.subLabel != null && k.kind == KeyKind.CHAR) {
            if (BanglaMarkView.isMark(k.subLabel)) {
                val subM = dp(subMarkDp())
                val subMark = BanglaMarkView(context).apply {
                    setMark(k.subLabel, theme.subText, isSub = true)
                    layoutParams = FrameLayout.LayoutParams(subM, subM, Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(3); rightMargin = dp(3)
                    }
                }
                frame.addView(subMark)
            } else {
                val subTv = TextView(context).apply {
                    text = k.subLabel
                    textSize = subTextSizeSp()
                    typeface = FontHelper.forKeyText(context, k.subLabel)
                    setTextColor(theme.subText)
                    layoutParams = FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(2); rightMargin = dp(4)
                    }
                }
                frame.addView(subTv)
            }
        }

        if (k.kind == KeyKind.SHIFT) {
            val iconFg = if (isShiftActive || theme.fnKeyAccent) Color.WHITE else if (theme.shiftColor != 0) theme.shiftColor else theme.accent
            val fIcon = dp(fnIconDp())
            val shiftIcon = ShiftKeyIconView(context).apply {
                setStyle(iconFg, capsLock)
                layoutParams = FrameLayout.LayoutParams(fIcon, fIcon, Gravity.CENTER)
            }
            frame.addView(shiftIcon)
        } else if (k.kind == KeyKind.BACKSPACE) {
            val iconFg = if (theme.fnKeyAccent) Color.WHITE else if (theme.backspaceColor != 0) theme.backspaceColor else theme.accent
            val fIcon = dp(fnIconDp())
            val bsIcon = BackspaceKeyIconView(context).apply {
                setStyle(iconFg)
                layoutParams = FrameLayout.LayoutParams(fIcon, fIcon, Gravity.CENTER)
            }
            frame.addView(bsIcon)
        } else if (k.kind == KeyKind.CHAR && BanglaMarkView.isMark(displayChar)) {
            val mDp = dp(markSizeDp())
            val markView = BanglaMarkView(context).apply {
                setMark(displayChar, theme.keyText, isSub = false)
                layoutParams = FrameLayout.LayoutParams(mDp, mDp, Gravity.CENTER).apply {
                    if (language == KeyboardLanguage.PROVAT) topMargin = dp(if (keySizeMode == "large") 6 else 5)
                }
            }
            frame.addView(markView)
        } else {
            val isCompactNumRow = keyH <= dp(46)
            val mainTv = TextView(context).apply {
                text = displayChar
                includeFontPadding = false
                setPadding(0, 0, 0, 0)
                textSize = if (isCompactNumRow) {
                    when (keySizeMode) {
                        "small" -> 13f
                        "large" -> 17f
                        else -> 15f
                    }
                } else if (k.kind == KeyKind.LAYER) {
                    layerTextSizeSp()
                } else if (isFn) {
                    fnTextSizeSp()
                } else {
                    charTextSizeSp()
                }
                typeface = FontHelper.forKeyText(context, displayChar)
                setTextColor(when {
                    k.kind == KeyKind.LAYER && theme.fnKeyAccent -> Color.WHITE
                    k.kind == KeyKind.LAYER -> theme.accentText
                    else -> theme.keyText
                })
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
                    if (language == KeyboardLanguage.PROVAT && k.kind == KeyKind.CHAR && !isCompactNumRow) {
                        topMargin = dp(if (keySizeMode == "large") 6 else 5)
                    }
                }
            }
            frame.addView(mainTv)
        }

        if (k.kind == KeyKind.BACKSPACE) {
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideAltPopup()
                        bsStartX = event.x
                        bsDidRepeat = false
                        bsDidSwipe = false
                        keyBgDrawable.setPressedState(true)
                        bsHoldRunnable = Runnable {
                            bsDidRepeat = true
                            autoShowSuggestionsOnTyping()
                            callbacks.onBackspace()
                            val rep = object : Runnable {
                                override fun run() {
                                    callbacks.onBackspace()
                                    mainHandler.postDelayed(this, 52L)
                                }
                            }
                            bsRepeatRunnable = rep
                            mainHandler.postDelayed(rep, 52L)
                        }
                        mainHandler.postDelayed(bsHoldRunnable!!, 320L)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (event.x - bsStartX <= -dp(26)) {
                            clearBsTimers()
                            bsDidSwipe = true
                            bsStartX = event.x
                            autoShowSuggestionsOnTyping()
                            callbacks.onDeleteWord()
                            refreshSuggestions()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        clearBsTimers()
                        keyBgDrawable.setPressedState(false)
                        if (!bsDidRepeat && !bsDidSwipe && event.action == MotionEvent.ACTION_UP) {
                            autoShowSuggestionsOnTyping()
                            callbacks.onBackspace()
                            refreshSuggestions()
                        } else {
                            refreshSuggestions()
                        }
                        true
                    }
                    else -> false
                }
            }
        } else {
            var longPressTriggered = false
            val lpRunnable = Runnable {
                if (k.kind == KeyKind.CHAR && k.altOptions.isNotEmpty()) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    showAltOptionsPopup(frame, k.altOptions, centerOnAnchor = (k.id == "p4"))
                } else if (k.kind == KeyKind.CHAR && k.id == "v" && language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    autoShowSuggestionsOnTyping()
                    callbacks.onPasteSystem()
                    refreshSuggestions()
                } else if (k.kind == KeyKind.CHAR && k.subLabel != null) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    autoShowSuggestionsOnTyping()
                    callbacks.onCommitText(k.subLabel)
                    refreshSuggestions()
                }
            }
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideAltPopup()
                        longPressTriggered = false
                        keyBgDrawable.setPressedState(true)
                        if (showPopup && k.kind == KeyKind.CHAR) showKeyPopupBubble(frame, displayChar)
                        if (k.kind == KeyKind.CHAR && (k.altOptions.isNotEmpty() || k.subLabel != null)) {
                            mainHandler.postDelayed(lpRunnable, 340L)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (longPressTriggered && altActiveOptions.isNotEmpty()) {
                            val nextIdx = ((event.rawX - altPopupScreenX) / altTileStepPx)
                                .toInt()
                                .coerceIn(0, altActiveOptions.lastIndex)
                            updateAltPopupSelection(nextIdx)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        keyBgDrawable.setPressedState(false)
                        if (longPressTriggered && k.altOptions.isNotEmpty() && altActiveOptions.isNotEmpty()) {
                            val chosen = altActiveOptions[altSelectedIdx.coerceIn(0, altActiveOptions.lastIndex)]
                            hideAltPopup()
                            autoShowSuggestionsOnTyping()
                            callbacks.onCommitText(chosen.value)
                            refreshSuggestions()
                        } else if (!longPressTriggered) {
                            handleKeyTap(k)
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        hideAltPopup()
                        keyBgDrawable.setPressedState(false)
                        true
                    }
                    else -> false
                }
            }
        }
        return frame
    }

    private fun clearBsTimers() {
        bsHoldRunnable?.let { mainHandler.removeCallbacks(it) }
        bsRepeatRunnable?.let { mainHandler.removeCallbacks(it) }
        bsHoldRunnable = null
        bsRepeatRunnable = null
    }

    private fun handleKeyTap(k: KeyDef) {
        when (k.kind) {
            KeyKind.SHIFT -> {
                callbacks.onSoundPreview()
                val now = System.currentTimeMillis()
                if (now - lastShiftTap < 280L) {
                    capsLock = !capsLock
                    shift = capsLock
                } else if (capsLock) {
                    capsLock = false
                    shift = false
                } else {
                    shift = !shift
                }
                lastShiftTap = now
                renderBody()
            }
            KeyKind.LAYER -> {
                callbacks.onSoundPreview()
                layer = if (k.id == "layer2") KeyLayer.SYMBOLS2 else KeyLayer.SYMBOLS1
                renderBody()
            }
            else -> {
                val out = when {
                    shift && k.shiftValue != null -> k.shiftValue
                    language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA && !shift ->
                        (k.value ?: k.label).lowercase()
                    else -> k.value ?: k.label
                }
                autoShowSuggestionsOnTyping()
                callbacks.onCommitText(out)
                if (shift && !capsLock) {
                    shift = false
                    renderBody()
                }
                refreshSuggestions()
            }
        }
    }

    private fun createSpacebar(keyH: Int): View {
        val label = if (language == KeyboardLanguage.ENGLISH) "‹   English   ›" else "‹   প্রভাত   ›"
        val spaceBgDrawable = makeKeycapDrawable(theme.spaceBg, theme.keyBorder, theme.cornerRadiusDp, true)
        val btn = TextView(context).apply {
            text = label
            textSize = when (keySizeMode) {
                "small" -> 12.5f
                "large" -> 16.5f
                else -> 14.5f
            }
            typeface = FontHelper.forKeyText(context, label, bold = false)
            setTextColor(theme.spaceText)
            gravity = Gravity.CENTER
            background = spaceBgDrawable
            layoutParams = LayoutParams(0, keyH, 3.2f).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        var startX = 0f
        var swiped = false
        btn.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x
                    swiped = false
                    spaceBgDrawable.setPressedState(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!swiped && kotlin.math.abs(event.x - startX) >= dp(24)) {
                        swiped = true
                        callbacks.onSoundPreview()
                        language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
                        prefs.edit().putString("last_language", language.name).apply()
                        layer = KeyLayer.ALPHA
                        shift = false
                        capsLock = false
                        aiSuggestions = emptyList()
                        rebuildAll()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    spaceBgDrawable.setPressedState(false)
                    if (!swiped) {
                        autoShowSuggestionsOnTyping()
                        callbacks.onCommitText(" ")
                        refreshSuggestions()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    spaceBgDrawable.setPressedState(false)
                    true
                }
                else -> false
            }
        }
        return btn
    }

    private fun makeKeycapActionKey(
        label: String,
        weight: Float,
        bg: Int,
        border: Int,
        fg: Int,
        radiusDp: Int,
        useGradient: Boolean,
        onClick: () -> Unit
    ): TextView {
        val capDrawable = makeKeycapDrawable(bg, border, radiusDp, useGradient)
        return TextView(context).apply {
            text = label
            textSize = 14.5f
            typeface = FontHelper.forText(context, label, bold = true)
            setTextColor(fg)
            gravity = Gravity.CENTER
            background = capDrawable
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply { setMargins(dp(2), 0, dp(2), 0) }
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        capDrawable.setPressedState(true)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        capDrawable.setPressedState(false)
                        onClick()
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        capDrawable.setPressedState(false)
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun makeActionKey(label: String, weight: Float, bg: Int, border: Int, fg: Int, radiusDp: Int, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 14.5f
            typeface = FontHelper.forText(context, label, bold = true)
            setTextColor(fg)
            gravity = Gravity.CENTER
            background = roundedBox(bg, border, radiusDp)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply { setMargins(dp(2), 0, dp(2), 0) }
            setOnClickListener { onClick() }
        }
    }

    private fun showKeyPopupBubble(anchor: View, ch: String) {
        try {
            if (keyPopupWindow == null) {
                val box = FrameLayout(context).apply {
                    background = roundedBox(theme.popupBg, theme.accent, 10, 2)
                }
                keyPopupText = TextView(context).apply {
                    textSize = 26f
                    gravity = Gravity.CENTER
                    setTextColor(theme.popupText)
                }
                keyPopupMark = BanglaMarkView(context)
                box.addView(keyPopupText, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
                box.addView(keyPopupMark, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
                keyPopupWindow = PopupWindow(box, dp(50), dp(54), false).apply {
                    isTouchable = false
                }
            }
            (keyPopupWindow?.contentView as? FrameLayout)?.background = roundedBox(theme.popupBg, theme.accent, 10, 2)
            if (BanglaMarkView.isMark(ch)) {
                keyPopupText?.visibility = View.GONE
                keyPopupMark?.visibility = View.VISIBLE
                keyPopupMark?.setMark(ch, theme.popupText, isSub = false)
            } else {
                keyPopupMark?.visibility = View.GONE
                keyPopupText?.visibility = View.VISIBLE
                keyPopupText?.typeface = FontHelper.forKeyText(context, ch)
                keyPopupText?.text = ch
                keyPopupText?.setTextColor(theme.popupText)
            }
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            keyPopupWindow?.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0] + (anchor.width - dp(50)) / 2, loc[1] - dp(58))
        } catch (_: Exception) {}
    }

    private fun hideKeyPopupBubble() {
        try { keyPopupWindow?.dismiss() } catch (_: Exception) {}
    }

    private fun showAltOptionsPopup(anchor: View, options: List<AltKeyOption>, centerOnAnchor: Boolean = false) {
        try {
            hideAltPopup()
            altActiveOptions = options
            val padH = dp(6)
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(theme.popupBg, theme.accent, 10, 2)
                setPadding(padH, dp(6), padH, dp(6))
            }
            val btnW = dp(40)
            val btnH = dp(44)
            val tileGap = dp(4)
            val winLoc = IntArray(2)
            anchor.getLocationInWindow(winLoc)
            val screenLoc = IntArray(2)
            anchor.getLocationOnScreen(screenLoc)
            val winToScreenDx = (screenLoc[0] - winLoc[0]).toFloat()

            val estW = options.size * (btnW + tileGap) + padH * 2
            val screenW = resources.displayMetrics.widthPixels
            val rawX = if (centerOnAnchor) {
                winLoc[0] + (anchor.width - estW) / 2
            } else {
                winLoc[0] + anchor.width - estW
            }
            val x = rawX.coerceIn(dp(6), (screenW - estW - dp(6)).coerceAtLeast(dp(6)))

            val defaultIdx = (((screenLoc[0] + anchor.width / 2f) - (x + winToScreenDx + padH)) / (btnW + tileGap).toFloat())
                .toInt()
                .coerceIn(0, options.lastIndex)
            altSelectedIdx = defaultIdx

            for ((idx, opt) in options.withIndex()) {
                val selected = idx == altSelectedIdx
                val card = FrameLayout(context).apply {
                    background = roundedBox(
                        if (selected) theme.accent else theme.keyBg,
                        if (selected) theme.accent else theme.keyBorder,
                        7
                    )
                    layoutParams = LayoutParams(btnW, btnH).apply { setMargins(dp(2), 0, dp(2), 0) }
                    setOnClickListener {
                        callbacks.onCommitText(opt.value)
                        refreshSuggestions()
                        hideAltPopup()
                    }
                }
                val fg = if (selected) Color.WHITE else theme.keyText
                if (BanglaMarkView.isMark(opt.label)) {
                    card.addView(BanglaMarkView(context).apply {
                        setMark(opt.label, fg, isSub = false)
                        layoutParams = FrameLayout.LayoutParams(dp(21), dp(21), Gravity.CENTER)
                    })
                } else {
                    card.addView(TextView(context).apply {
                        text = opt.label
                        textSize = 21f
                        typeface = FontHelper.forKeyText(context, opt.label)
                        gravity = Gravity.CENTER
                        setTextColor(fg)
                        layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
                    })
                }
                altTileCards.add(card)
                row.addView(card)
            }
            val pop = PopupWindow(row, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, false).apply {
                isOutsideTouchable = true
                isFocusable = false
            }
            altPopupWindow = pop
            altTileStepPx = (btnW + tileGap).toFloat()
            altPopupScreenX = x + winToScreenDx + padH.toFloat()
            pop.showAtLocation(anchor, Gravity.NO_GRAVITY, x, winLoc[1] - btnH - dp(16))
        } catch (_: Exception) {}
    }

    private fun updateAltPopupSelection(newIdx: Int) {
        if (newIdx == altSelectedIdx || newIdx !in altTileCards.indices) return
        altSelectedIdx = newIdx
        for ((idx, card) in altTileCards.withIndex()) {
            val selected = idx == altSelectedIdx
            card.background = roundedBox(
                if (selected) theme.accent else theme.keyBg,
                if (selected) theme.accent else theme.keyBorder,
                7
            )
            val opt = altActiveOptions.getOrNull(idx) ?: continue
            val fg = if (selected) Color.WHITE else theme.keyText
            val child = card.getChildAt(0)
            if (child is BanglaMarkView) {
                child.setMark(opt.label, fg, isSub = false)
            } else if (child is TextView) {
                child.setTextColor(fg)
            }
        }
    }

    private fun hideAltPopup() {
        try { altPopupWindow?.dismiss() } catch (_: Exception) {}
        altPopupWindow = null
        altActiveOptions = emptyList()
        altTileCards.clear()
        altSelectedIdx = 0
    }

    private fun renderEmojiPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val tabScroll = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(context).apply { orientation = HORIZONTAL }

        val recentActive = emojiCatId == "recent"
        tabRow.addView(TextView(context).apply {
            text = "🕒 সাম্প্রতিক"
            textSize = 12f
            setTextColor(if (recentActive) Color.WHITE else theme.keyText)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = roundedBox(if (recentActive) theme.accent else theme.keyBg, theme.keyBorder, 8)
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
            setOnClickListener { emojiCatId = "recent"; renderBody() }
        })

        for (cat in EmojiData.CATEGORIES) {
            val active = cat.id == emojiCatId
            tabRow.addView(TextView(context).apply {
                text = cat.label
                textSize = 12f
                setTextColor(if (active) Color.WHITE else theme.keyText)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = roundedBox(if (active) theme.accent else theme.keyBg, theme.keyBorder, 8)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
                setOnClickListener { emojiCatId = cat.id; renderBody() }
            })
        }
        tabScroll.addView(tabRow)
        wrap.addView(tabScroll)

        val emojis = if (emojiCatId == "recent") {
            recentEmojis.toList()
        } else {
            EmojiData.CATEGORIES.firstOrNull { it.id == emojiCatId }?.emojis ?: emptyList()
        }
        val gridScroll = ScrollView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) }
        }
        val grid = LinearLayout(context).apply { orientation = VERTICAL }
        if (emojis.isEmpty()) {
            grid.addView(TextView(context).apply {
                text = "সাম্প্রতিক ব্যবহৃত ইমোজি এখানে জমা হবে"
                textSize = 12.5f
                gravity = Gravity.CENTER
                setTextColor(theme.subText)
                setPadding(dp(12), dp(36), dp(12), dp(36))
            })
        } else {
            val cols = 7
            for (chunk in emojis.chunked(cols)) {
                val row = LinearLayout(context).apply { orientation = HORIZONTAL }
                for (em in chunk) {
                    row.addView(TextView(context).apply {
                        text = em
                        textSize = 26f
                        gravity = Gravity.CENTER
                        background = roundedBox(theme.keyBg, Color.TRANSPARENT, 8)
                        layoutParams = LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2.5f.toInt()), dp(2), dp(2.5f.toInt()), dp(2)) }
                        setOnClickListener {
                            recordRecentEmoji(em)
                            callbacks.onCommitText(em)
                        }
                    })
                }
                repeat(cols - chunk.size) { row.addView(View(context), LayoutParams(0, dp(48), 1f)) }
                grid.addView(row)
            }
        }
        gridScroll.addView(grid)
        wrap.addView(gridScroll)

        val footer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)).apply { topMargin = dp(6) }
        }
        footer.addView(makeActionKey("কিবোর্ডে ফিরুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        footer.addView(makeActionKey("⌫ মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            callbacks.onBackspace()
        })
        wrap.addView(footer)
        bodyContainer.addView(wrap)
    }

    private fun runCursorTranslate(source: String, mode: String = transTargetMode) {
        val clean = source.trim()
        if (clean.isEmpty()) {
            transResultText = ""
            transStatusMsg = "অনুবাদের জন্য আগে Copy চাপুন বা লেখা দিন"
            renderBody()
            return
        }
        transSourceText = clean
        transTargetMode = mode
        transLoading = true
        transStatusMsg = ""
        renderBody()
        val apiKey = prefs.getString("gemini_api_key", "") ?: ""
        ScreenTranslator.translate(
            sourceText = clean,
            targetMode = mode,
            geminiApiKey = apiKey,
            onSuccess = { translated, _ ->
                transLoading = false
                transResultText = translated
                transStatusMsg = ""
                if (activePanel == Panel.CURSOR) renderBody()
            },
            onError = { msg ->
                transLoading = false
                transStatusMsg = msg
                if (activePanel == Panel.CURSOR) renderBody()
            }
        )
    }

    private fun triggerScreenCopy(openTranslator: Boolean) {
        callbacks.onSoundPreview()
        if (!callbacks.isScreenReaderEnabled()) {
            needScreenPermPrompt = true
            transStatusMsg = "স্ক্রিন কপির জন্য Accessibility চালু করুন"
            renderBody()
            return
        }
        needScreenPermPrompt = false
        val captured = callbacks.onCopyVisibleScreen()
        if (captured.isBlank()) {
            transStatusMsg = "দৃশ্যমান লেখা পাওয়া যায়নি"
            renderBody()
            return
        }
        transSourceText = captured
        transStatusMsg = "কপি সম্পন্ন (${captured.length} অক্ষর)"
        if (openTranslator || cursorTranslatorOpen) {
            cursorTranslatorOpen = true
            runCursorTranslate(captured, transTargetMode)
        } else {
            renderBody()
        }
    }

    private fun renderCursorPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        if (cursorTranslatorOpen) {
            // Translator sub-view inside Cursor panel
            val header = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(28)).apply { bottomMargin = dp(5) }
            }
            header.addView(TextView(context).apply {
                text = "Smart Screen Copy & Translator"
                textSize = 12f
                typeface = FontHelper.banglaBold(context)
                setTextColor(theme.keyText)
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            })
            header.addView(makeActionKey("← ফিরে যান", 0f, theme.keyBg, theme.keyBorder, theme.keyText, 7) {
                cursorTranslatorOpen = false; renderBody()
            }.apply {
                textSize = 10.5f
                setPadding(dp(8), 0, dp(8), 0)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(26)).apply { rightMargin = dp(4) }
            })
            header.addView(makeActionKey("ABC", 0f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 7) {
                cursorTranslatorOpen = false; activePanel = Panel.KEYS; rebuildAll()
            }.apply {
                textSize = 10.5f
                setPadding(dp(8), 0, dp(8), 0)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(26))
            })
            wrap.addView(header)

            // Multi-language selector row
            val langScroll = HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(30)).apply { bottomMargin = dp(5) }
            }
            val langRow = LinearLayout(context).apply { orientation = HORIZONTAL }
            val langOptions = listOf(
                "auto" to "স্বয়ংক্রিয়",
                "bn" to "বাংলা",
                "en" to "English",
                "ar" to "আরবি",
                "hi" to "হিন্দি",
                "ur" to "উর্দু",
                "ms" to "মালয়",
                "es" to "স্প্যানিশ",
                "fr" to "ফরাসি"
            )
            for ((code, label) in langOptions) {
                val active = transTargetMode == code
                val chip = TextView(context).apply {
                    text = label
                    textSize = 11f
                    typeface = FontHelper.banglaBold(context)
                    gravity = Gravity.CENTER
                    setPadding(dp(9), dp(3), dp(9), dp(3))
                    setTextColor(if (active) Color.WHITE else theme.keyText)
                    background = roundedBox(
                        if (active) theme.accent else theme.keyBg,
                        if (active) theme.accent else theme.keyBorder,
                        7
                    )
                    layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(28)).apply { rightMargin = dp(4) }
                    setOnClickListener {
                        transTargetMode = code
                        if (transSourceText.isNotBlank()) runCursorTranslate(transSourceText, code) else renderBody()
                    }
                }
                langRow.addView(chip)
            }
            langScroll.addView(langRow)
            wrap.addView(langScroll)

            if (needScreenPermPrompt && !callbacks.isScreenReaderEnabled()) {
                val permRow = LinearLayout(context).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBox(theme.keyBg, theme.accent, 7)
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(32)).apply { bottomMargin = dp(5) }
                }
                permRow.addView(TextView(context).apply {
                    text = "স্ক্রিন কপির অনুমতি প্রয়োজন"
                    textSize = 11f
                    typeface = FontHelper.banglaRegular(context)
                    setTextColor(theme.keyText)
                    layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                })
                permRow.addView(makeActionKey("খুলুন", 0f, theme.accent, theme.accent, Color.WHITE, 6) {
                    callbacks.onOpenAccessibilitySettings()
                }.apply {
                    textSize = 10.5f
                    setPadding(dp(10), 0, dp(10), 0)
                    layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(24))
                })
                wrap.addView(permRow)
            }

            // Source quick actions + preview
            val srcBar = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(5) }
            }
            val srcScroll = ScrollView(context).apply {
                background = roundedBox(theme.keyBg, theme.keyBorder, 7)
                setPadding(dp(7), dp(4), dp(7), dp(4))
                layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(4) }
            }
            srcScroll.addView(TextView(context).apply {
                text = if (transSourceText.isBlank()) "'স্ক্রিন নিন' বা 'বক্স নিন' চাপুন..." else transSourceText
                textSize = 11f
                typeface = FontHelper.forKeyText(context, transSourceText)
                setTextColor(if (transSourceText.isBlank()) theme.subText else theme.keyText)
            })
            srcBar.addView(srcScroll)
            srcBar.addView(makeActionKey("স্ক্রিন নিন", 0.42f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 7) {
                triggerScreenCopy(openTranslator = true)
            }.apply { textSize = 10.5f })
            srcBar.addView(makeActionKey("বক্স নিন", 0.38f, theme.keyBg, theme.keyBorder, theme.keyText, 7) {
                val boxTxt = callbacks.getTextBeforeCursor().trim()
                if (boxTxt.isNotBlank()) runCursorTranslate(boxTxt, transTargetMode)
            }.apply { textSize = 10.5f })
            wrap.addView(srcBar)

            // Translated result box
            val resScroll = ScrollView(context).apply {
                background = roundedBox(theme.keyBg, theme.accent, 8)
                setPadding(dp(8), dp(6), dp(8), dp(6))
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f).apply { bottomMargin = dp(5) }
            }
            resScroll.addView(TextView(context).apply {
                text = when {
                    transLoading -> "অনুবাদ করা হচ্ছে..."
                    transStatusMsg.isNotBlank() && transResultText.isBlank() -> transStatusMsg
                    transResultText.isNotBlank() -> transResultText
                    else -> "ভাষা নির্বাচন করুন — অনুবাদের ফলাফল এখানে দেখাবে।"
                }
                textSize = 12.5f
                typeface = if (transResultText.isNotBlank()) FontHelper.forKeyText(context, transResultText) else FontHelper.banglaUi(context)
                setTextColor(theme.keyText)
            })
            wrap.addView(resScroll)

            val transBottom = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(32))
            }
            transBottom.addView(makeActionKey("← ফিরে যান", 0.9f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 7) {
                cursorTranslatorOpen = false; renderBody()
            }.apply { textSize = 11f })
            transBottom.addView(makeActionKey("অনুবাদ কপি", 1.1f, theme.keyBg, theme.keyBorder, theme.accentText, 7) {
                if (transResultText.isNotBlank()) {
                    callbacks.onCopyPlainText(transResultText)
                    transStatusMsg = "অনুবাদ কপি হয়েছে"
                    renderBody()
                }
            }.apply { textSize = 11f })
            transBottom.addView(makeActionKey("বক্সে বসান", 1.1f, theme.accent, theme.accent, Color.WHITE, 7) {
                if (transResultText.isNotBlank()) {
                    callbacks.onCommitText(transResultText)
                }
            }.apply { textSize = 11f })
            wrap.addView(transBottom)
            bodyContainer.addView(wrap)
            return
        }

        // Top Header + ABC
        val topHeader = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(22)).apply { bottomMargin = dp(3) }
        }
        topHeader.addView(TextView(context).apply {
            text = "টেক্সট এডিটিং ও কপি-পেস্ট"
            textSize = 11f
            typeface = FontHelper.banglaBold(context)
            setTextColor(theme.subText)
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        })
        topHeader.addView(makeActionKey("ABC", 0f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 7) {
            activePanel = Panel.KEYS; rebuildAll()
        }.apply {
            textSize = 10.5f
            setPadding(dp(10), 0, dp(10), 0)
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(22))
        })
        wrap.addView(topHeader)

        // Row 1 & Row 2 + Smart Screen Copy & Translator packed cleanly from the top; extra space stays at bottom
        val row1 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(5) }
        }
        row1.addView(makeActionKey("Select All", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onSelectAll() }.apply { textSize = 11.5f })
        row1.addView(makeActionKey("Copy", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCopy() }.apply { textSize = 11.5f })
        row1.addView(makeActionKey("Cut", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCut() }.apply { textSize = 11.5f })
        row1.addView(makeActionKey("Paste", 1f, theme.accent, theme.accent, Color.WHITE, 8) { callbacks.onPasteSystem() }.apply { textSize = 11.5f })
        wrap.addView(row1)

        val row2 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(6) }
        }
        row2.addView(makeActionKey("|◄ শুরু", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("start") }.apply { textSize = 11.5f })
        row2.addView(makeActionKey("◄ বামে", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("left") }.apply { textSize = 11.5f })
        row2.addView(makeActionKey("ডানে ►", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("right") }.apply { textSize = 11.5f })
        row2.addView(makeActionKey("শেষ ►|", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("end") }.apply { textSize = 11.5f })
        wrap.addView(row2)

        if (needScreenPermPrompt && !callbacks.isScreenReaderEnabled()) {
            val permCard = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(theme.keyBg, theme.accent, 8)
                setPadding(dp(8), dp(3), dp(8), dp(3))
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(30)).apply { bottomMargin = dp(5) }
            }
            permCard.addView(TextView(context).apply {
                text = "স্ক্রিন কপির জন্য Accessibility চালু করুন"
                textSize = 10.5f
                typeface = FontHelper.banglaRegular(context)
                setTextColor(theme.keyText)
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            })
            permCard.addView(makeActionKey("খুলুন", 0f, theme.accent, theme.accent, Color.WHITE, 6) {
                callbacks.onOpenAccessibilitySettings()
            }.apply {
                textSize = 10.5f
                setPadding(dp(10), 0, dp(10), 0)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, dp(24))
            })
            wrap.addView(permCard)
        }

        // Compact section directly below Row 2 matching upper box size; extra space remains at the bottom
        val titleRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(2)
                bottomMargin = dp(4)
            }
        }
        titleRow.addView(TextView(context).apply {
            text = "Smart Screen Copy & Translator"
            textSize = 11.5f
            typeface = FontHelper.banglaBold(context)
            setTextColor(theme.keyText)
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        })
        if (transStatusMsg.isNotBlank()) {
            titleRow.addView(TextView(context).apply {
                text = "✓ $transStatusMsg"
                textSize = 10.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                typeface = FontHelper.banglaRegular(context)
                setTextColor(theme.accentText)
            })
        }
        wrap.addView(titleRow)

        val twoBoxes = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36))
        }
        twoBoxes.addView(makeActionKey("📋 Copy", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            triggerScreenCopy(openTranslator = false)
        }.apply {
            textSize = 11.5f
            typeface = FontHelper.banglaBold(context)
        })
        twoBoxes.addView(makeActionKey("🌐 Translator", 1f, theme.keyBg, theme.accent, theme.accentText, 8) {
            callbacks.onSoundPreview()
            val seed = transSourceText.ifBlank {
                clipStore.getAll().firstOrNull()?.text ?: callbacks.getTextBeforeCursor().trim()
            }
            if (seed.isNotBlank()) {
                transSourceText = seed
                cursorTranslatorOpen = true
                if (transResultText.isBlank()) {
                    runCursorTranslate(seed, transTargetMode)
                    return@makeActionKey
                }
            } else {
                cursorTranslatorOpen = true
            }
            renderBody()
        }.apply {
            textSize = 11.5f
            typeface = FontHelper.banglaBold(context)
        })
        wrap.addView(twoBoxes)

        bodyContainer.addView(wrap)
    }

    private fun renderClipboardPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val all = clipStore.getAll()
        val pinned = all.filter { it.pinned }
        val temp = all.filter { !it.pinned }

        // Tabs: পিন কমেন্ট (LEFT) & অস্থায়ী কমেন্ট (RIGHT)
        val tabRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(6) }
        }
        tabRow.addView(makeActionKey("📌 পিন কমেন্ট (${pinned.size}/40)", 1f,
            if (clipPinnedTab) theme.accent else theme.keyBg, theme.accent,
            if (clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = true; renderBody()
        }.apply { textSize = 11.5f })
        tabRow.addView(makeActionKey("⏱ অস্থায়ী কমেন্ট (${temp.size})", 1f,
            if (!clipPinnedTab) theme.accent else theme.keyBg, theme.keyBorder,
            if (!clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = false; renderBody()
        }.apply { textSize = 11.5f })
        wrap.addView(tabRow)

        val items = if (clipPinnedTab) pinned else temp
        val scroll = ScrollView(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f) }
        val listCol = LinearLayout(context).apply { orientation = VERTICAL }

        if (items.isEmpty()) {
            listCol.addView(TextView(context).apply {
                text = if (clipPinnedTab) "কোনো পিন কমেন্ট নেই (সর্বোচ্চ ৪০টি স্থায়ী থাকবে)"
                else "অস্থায়ী কমেন্ট খালি — কপি করলে ১২ ঘন্টার জন্য সেভ হবে"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(theme.subText)
                setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        } else {
            for (item in items) {
                val card = LinearLayout(context).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    setPadding(dp(10), dp(8), dp(6), dp(8))
                    layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
                }
                val txtCol = LinearLayout(context).apply {
                    orientation = VERTICAL
                    layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener { callbacks.onCommitText(item.text) }
                }
                txtCol.addView(TextView(context).apply {
                    text = item.text
                    textSize = 13f
                    typeface = FontHelper.forKeyText(context, item.text)
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(theme.keyText)
                })
                if (!item.pinned) {
                    txtCol.addView(TextView(context).apply {
                        text = clipStore.formatRemaining(item.createdAt)
                        textSize = 10f
                        typeface = FontHelper.banglaRegular(context)
                        setTextColor(theme.subText)
                    })
                }
                card.addView(txtCol)

                card.addView(TextView(context).apply {
                    text = if (item.pinned) "✕📌" else "📌"
                    textSize = 14f
                    setPadding(dp(6), dp(4), dp(6), dp(4))
                    setOnClickListener { clipStore.togglePin(item.id); renderBody() }
                })
                card.addView(TextView(context).apply {
                    text = "🗑"
                    textSize = 14f
                    setPadding(dp(6), dp(4), dp(6), dp(4))
                    setOnClickListener { clipStore.deleteItem(item.id); renderBody() }
                })
                listCol.addView(card)
            }
        }
        scroll.addView(listCol)
        wrap.addView(scroll)

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(34)).apply { topMargin = dp(6) }
        }
        bottom.addView(makeActionKey("সব মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            clipStore.clearScope(clipPinnedTab); renderBody()
        }.apply { textSize = 12f })
        bottom.addView(makeActionKey("কিবোর্ড", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        }.apply { textSize = 12f })
        wrap.addView(bottom)
        bodyContainer.addView(wrap)
    }

    private fun renderThemesPanel() {
        val scroll = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        }
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val d = resources.displayMetrics.density
        for (t in KeyboardThemes.ALL) {
            val active = t.id == theme.id
            val card = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(t.boardBg, if (active) t.accent else t.keyBorder, 10, if (active) 2 else 1)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(7) }
                setOnClickListener {
                    prefs.edit().putString("theme_id", t.id).apply()
                    theme = t
                    callbacks.onPreferencesChanged()
                    rebuildAll()
                }
            }

            // Live miniature theme pattern + key swatch
            val swatch = FrameLayout(context).apply {
                background = BoardBackgroundDrawable(t, d * 0.7f)
                layoutParams = LayoutParams(dp(44), dp(30)).apply { rightMargin = dp(10) }
                setPadding(dp(6), dp(5), dp(6), dp(5))
            }
            val miniKey = View(context).apply {
                background = KeycapDrawable(
                    baseBg = t.keyBg,
                    gradTop = t.keyGradTop,
                    gradMid = t.keyGradMid,
                    gradBot = t.keyGradBot,
                    baseBorder = t.keyBorder,
                    pressedBg = t.keyPressedBg,
                    pressedBorder = t.accent,
                    glowColor = t.keyGlowColor,
                    haloColor = t.haloColor,
                    is3dBevel = t.is3dBevel,
                    hasInnerDish = t.hasInnerDish,
                    hasTopGloss = t.hasTopGloss,
                    isLightTheme = t.isLight,
                    useGradient = true,
                    radiusPx = dp(minOf(6, maxOf(4, t.cornerRadiusDp / 2))).toFloat(),
                    density = d
                )
                layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            }
            swatch.addView(miniKey)
            card.addView(swatch)

            val textCol = LinearLayout(context).apply {
                orientation = VERTICAL
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(context).apply {
                text = t.name
                textSize = 13f
                typeface = FontHelper.latinBold(context)
                setTextColor(t.keyText)
            })
            textCol.addView(TextView(context).apply {
                text = t.nameBn
                textSize = 11f
                typeface = FontHelper.banglaRegular(context)
                setTextColor(t.subText)
            })
            card.addView(textCol)

            val badge = TextView(context).apply {
                text = if (active) "✓ চালু" else "পছন্দ"
                textSize = 11f
                typeface = FontHelper.banglaBold(context)
                setTextColor(if (active) Color.WHITE else t.accentText)
                setPadding(dp(9), dp(4), dp(9), dp(4))
                background = roundedBox(if (active) t.accent else Color.TRANSPARENT, t.accent, 6)
            }
            card.addView(badge)
            wrap.addView(card)
        }
        scroll.addView(wrap)
        bodyContainer.addView(scroll)
    }

    private fun renderSettingsPanel() {
        val scroll = ScrollView(context).apply {
            isFillViewport = true
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        }
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val hLabel = TextView(context).apply {
            text = "কিবোর্ডের উচ্চতা:"
            textSize = 11.5f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(theme.subText)
            setPadding(dp(2), 0, 0, dp(5))
        }
        wrap.addView(hLabel)

        val hRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(10) }
        }
        for ((heightId, heightLabel) in listOf("compact" to "উচ্চতা: ছোট", "standard" to "সাধারণ", "tall" to "বড়")) {
            val active = keyHeightMode == heightId
            hRow.addView(makeActionKey(heightLabel, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 8) {
                keyHeightMode = heightId
                prefs.edit().putString("key_height", heightId).apply()
                callbacks.onPreferencesChanged()
                rebuildAll()
            }.apply { textSize = 13f })
        }
        wrap.addView(hRow)

        val szLabel = TextView(context).apply {
            text = "কিবোর্ডের কী সাইজ (প্রভাত ও ইংরেজি):"
            textSize = 11.5f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(theme.subText)
            setPadding(dp(2), 0, 0, dp(5))
        }
        wrap.addView(szLabel)

        val szRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(10) }
        }
        for ((sizeId, sizeLabel) in listOf("small" to "ছোট", "medium" to "মাঝারি", "large" to "বড়")) {
            val active = keySizeMode == sizeId
            szRow.addView(makeActionKey(sizeLabel, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 8) {
                keySizeMode = sizeId
                prefs.edit().putString("key_size", sizeId).apply()
                callbacks.onPreferencesChanged()
                rebuildAll()
            }.apply { textSize = 13f })
        }
        wrap.addView(szRow)

        val sndLabel = TextView(context).apply {
            text = "টাইপিং সাউন্ড (আইফোন / হোয়াটসঅ্যাপ / মেকানিক্যাল):"
            textSize = 11.5f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(theme.subText)
            setPadding(dp(2), 0, 0, dp(5))
        }
        wrap.addView(sndLabel)

        val currentSnd = if (!prefs.getBoolean("sound_on", "mechanical" != "off")) "off" else soundProfile
        val normalizedSnd = when (currentSnd) {
            "pc" -> "mechanical"
            "soft" -> "whatsapp"
            else -> currentSnd
        }
        val sndRow1 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(6) }
        }
        for ((sndId, sndBtnLabel) in listOf(
            "iphone" to "আইফোন",
            "whatsapp" to "হোয়াটসঅ্যাপ",
            "laptop" to "ল্যাপটপ"
        )) {
            val active = normalizedSnd == sndId
            sndRow1.addView(makeActionKey(sndBtnLabel, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 7) {
                soundProfile = sndId
                prefs.edit()
                    .putString("sound_profile", sndId)
                    .putBoolean("sound_on", true)
                    .apply()
                callbacks.onPreferencesChanged()
                callbacks.onSoundPreview()
                renderBody()
            }.apply { textSize = 11.5f })
        }
        wrap.addView(sndRow1)

        val sndRow2 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(12) }
        }
        for ((sndId, sndBtnLabel) in listOf(
            "mechanical" to "মেকানিক্যাল",
            "off" to "বন্ধ"
        )) {
            val active = normalizedSnd == sndId
            sndRow2.addView(makeActionKey(sndBtnLabel, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 7) {
                soundProfile = sndId
                prefs.edit()
                    .putString("sound_profile", sndId)
                    .putBoolean("sound_on", sndId != "off")
                    .apply()
                callbacks.onPreferencesChanged()
                if (sndId != "off") callbacks.onSoundPreview()
                renderBody()
            }.apply { textSize = 11.5f })
        }
        wrap.addView(sndRow2)

        val onFill = Color.parseColor("#16A34A")
        val onStroke = Color.parseColor("#22C55E")
        val offFill = Color.parseColor("#2A1822")
        val offStroke = Color.parseColor("#EF4444")
        val offText = Color.parseColor("#FCA5A5")

        val tRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(10) }
        }
        tRow.addView(makeActionKey("বানান ডিকেক্টর: ${if (spellCheckEnabled) "● চালু" else "○ বন্ধ"}", 1f,
            if (spellCheckEnabled) onFill else offFill,
            if (spellCheckEnabled) onStroke else offStroke,
            if (spellCheckEnabled) Color.WHITE else offText, 8) {
            spellCheckEnabled = !spellCheckEnabled
            prefs.edit().putBoolean("spell_check", spellCheckEnabled).apply()
            rebuildAll()
        }.apply { textSize = 12.5f })
        tRow.addView(makeActionKey("পপ-আপ: ${if (showPopup) "● চালু" else "○ বন্ধ"}", 1f,
            if (showPopup) onFill else offFill,
            if (showPopup) onStroke else offStroke,
            if (showPopup) Color.WHITE else offText, 8) {
            showPopup = !showPopup
            prefs.edit().putBoolean("show_popup", showPopup).apply()
            renderBody()
        }.apply { textSize = 12.5f })
        wrap.addView(tRow)

        wrap.addView(View(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f)
        })

        val bRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(48))
        }
        bRow.addView(makeActionKey("নাম্বার সারি: ${if (showNumberRow) "● চালু" else "○ বন্ধ"}", 1f,
            if (showNumberRow) onFill else offFill,
            if (showNumberRow) onStroke else offStroke,
            if (showNumberRow) Color.WHITE else offText, 8) {
            showNumberRow = !showNumberRow
            prefs.edit().putBoolean("show_num_row", showNumberRow).apply()
            rebuildAll()
        }.apply { textSize = 12.5f })
        bRow.addView(makeActionKey("সম্পন্ন", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            showToolbar = false; activePanel = Panel.KEYS; rebuildAll()
        }.apply { textSize = 14f })
        wrap.addView(bRow)

        scroll.addView(wrap)
        bodyContainer.addView(scroll)
    }
}
