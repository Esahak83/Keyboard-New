package com.ridmikstudio.keyboard

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.lang.ref.WeakReference

class RidmikInputMethodService : InputMethodService(), RidmikKeyboardView.Callbacks {

    companion object {
        private var activeRef: WeakReference<RidmikInputMethodService>? = null

        fun tryDeliverPendingVoice() {
            activeRef?.get()?.commitPendingVoice()
        }
    }

    private var keyboardView: RidmikKeyboardView? = null
    private lateinit var clipStore: ClipboardStore
    private var clipboardManager: ClipboardManager? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListeningVoice: Boolean = false

    private var soundPool: SoundPool? = null
    private val loadedSoundIds = HashSet<Int>()
    private var sndIphoneKey = 0
    private var sndIphoneMod = 0
    private var sndWhatsappKey = 0
    private var sndWhatsappMod = 0
    private var sndLaptopKey = 0
    private var sndLaptopMod = 0
    private var sndMechKey = 0
    private var sndMechMod = 0

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val txt = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!txt.isNullOrBlank()) {
            clipStore.addClip(txt)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeRef = WeakReference(this)
        clipStore = ClipboardStore(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipListener)
        initSoundPool()
    }

    private fun initSoundPool() {
        try {
            loadedSoundIds.clear()
            // Use USAGE_MEDIA so exact keystroke audio plays consistently across Realme/ColorOS, MIUI, OneUI
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val sp = SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(attrs)
                .build()
            sp.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) loadedSoundIds.add(sampleId)
            }
            sndIphoneKey = sp.load(this, R.raw.snd_iphone_key, 1)
            sndIphoneMod = sp.load(this, R.raw.snd_iphone_mod, 1)
            sndWhatsappKey = sp.load(this, R.raw.snd_whatsapp_key, 1)
            sndWhatsappMod = sp.load(this, R.raw.snd_whatsapp_mod, 1)
            sndLaptopKey = sp.load(this, R.raw.snd_laptop_key, 1)
            sndLaptopMod = sp.load(this, R.raw.snd_laptop_mod, 1)
            sndMechKey = sp.load(this, R.raw.snd_mech_key, 1)
            sndMechMod = sp.load(this, R.raw.snd_mech_mod, 1)
            soundPool = sp
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        stopInlineVoice()
        activeRef = null
        try { soundPool?.release() } catch (_: Exception) {}
        soundPool = null
        loadedSoundIds.clear()
        clipboardManager?.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        if (soundPool == null) initSoundPool()
        val v = RidmikKeyboardView(this, this)
        keyboardView = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        activeRef = WeakReference(this)
        if (soundPool == null) initSoundPool()
        keyboardView?.reloadFromPrefs(resetToKeys = true)
        commitPendingVoice()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        keyboardView?.resetToKeysPanel()
        super.onFinishInputView(finishingInput)
    }

    override fun onWindowHidden() {
        keyboardView?.resetToKeysPanel()
        super.onWindowHidden()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        commitPendingVoice()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        keyboardView?.refreshSuggestions()
    }

    private fun commitPendingVoice() {
        val prefs = getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
        val pending = prefs.getString("pending_voice_text", null) ?: return
        val ic = currentInputConnection ?: return
        prefs.edit().remove("pending_voice_text").apply()
        if (pending.isNotBlank()) {
            ic.commitText("$pending ", 1)
            keyboardView?.refreshSuggestions()
        }
    }

    private fun stopInlineVoice() {
        isListeningVoice = false
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        keyboardView?.setVoiceListening(false)
    }

    private fun launchVoiceFallbackActivity(langTag: String) {
        try {
            val intent = Intent(this, VoiceInputActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("lang_tag", langTag)
            }
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun feedback(isSpecial: Boolean = false) {
        val prefs = getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("vibrate_on", true)) {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(14L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(14L)
                }
            }
        }
        val defProf = "mechanical"
        val soundOn = prefs.getBoolean("sound_on", defProf != "off")
        val profile = prefs.getString("sound_profile", defProf) ?: defProf
        if (soundOn && profile != "off") {
            if (soundPool == null) initSoundPool()
            val sndId = when (profile) {
                "whatsapp", "soft" -> if (isSpecial) sndWhatsappMod else sndWhatsappKey
                "laptop" -> if (isSpecial) sndLaptopMod else sndLaptopKey
                "mechanical", "pc" -> if (isSpecial) sndMechMod else sndMechKey
                else -> if (isSpecial) sndIphoneMod else sndIphoneKey
            }
            val sp = soundPool
            if (sp != null && sndId != 0 && loadedSoundIds.contains(sndId)) {
                val streamId = sp.play(sndId, 1.0f, 1.0f, 1, 0, 1.0f)
                if (streamId == 0) {
                    val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.85f)
                }
            } else {
                val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.85f)
            }
        }
    }

    override fun onCommitText(text: String) {
        feedback(isSpecial = text == " ")
        currentInputConnection?.commitText(text, 1)
    }

    override fun onBackspace() {
        feedback(isSpecial = true)
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(4, 0) ?: ""
        if (before.isEmpty()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
            return
        }
        val lastCodePoint = Character.codePointBefore(before, before.length)
        val charCount = Character.charCount(lastCodePoint)
        ic.deleteSurroundingText(charCount, 0)
    }

    override fun onDeleteWord() {
        feedback(isSpecial = true)
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: return
        if (before.isEmpty()) return
        val trimmed = before.trimEnd()
        val cut = if (trimmed.isEmpty()) before.length
        else {
            val lastSpace = trimmed.lastIndexOfAny(charArrayOf(' ', '\n'))
            if (lastSpace == -1) before.length else before.length - (lastSpace + 1)
        }
        ic.deleteSurroundingText(cut, 0)
    }

    override fun onEnter() {
        feedback(isSpecial = true)
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_GO) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    override fun onMoveCursor(action: String) {
        val ic = currentInputConnection ?: return
        when (action) {
            "left" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_LEFT))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_LEFT))
            }
            "right" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT))
            }
            "start" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MOVE_HOME))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MOVE_HOME))
            }
            "end" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MOVE_END))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MOVE_END))
            }
        }
    }

    override fun onSelectAll() {
        currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
    }

    override fun onCopy() {
        currentInputConnection?.performContextMenuAction(android.R.id.copy)
    }

    override fun onCut() {
        currentInputConnection?.performContextMenuAction(android.R.id.cut)
    }

    override fun onPasteSystem() {
        val txt = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!txt.isNullOrEmpty()) {
            currentInputConnection?.commitText(txt, 1)
        } else {
            currentInputConnection?.performContextMenuAction(android.R.id.paste)
        }
    }

    override fun onCopyVisibleScreen(): String {
        val captured = RidmikScreenReaderService.captureVisibleText(this)
        if (captured.isNotBlank()) {
            try {
                clipboardManager?.setPrimaryClip(ClipData.newPlainText("Ridmik Screen Copy", captured))
            } catch (_: Exception) {
            }
            clipStore.addClip(captured)
        }
        return captured
    }

    override fun isScreenReaderEnabled(): Boolean {
        return RidmikScreenReaderService.isServiceEnabled(this)
    }

    override fun onOpenAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            Toast.makeText(this, "Ridmik Studio স্ক্রিন কপি সার্ভিসটি চালু করুন", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
        }
    }

    override fun onCopyPlainText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        try {
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("Ridmik Translate", clean))
        } catch (_: Exception) {
        }
        clipStore.addClip(clean)
        Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show()
    }

    override fun onVoiceInput() {
        feedback()
        val langTag = if (keyboardView?.language == KeyboardLanguage.PROVAT) "bn-BD" else "en-US"
        if (isListeningVoice) {
            stopInlineVoice()
            return
        }

        val hasAudioPerm = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudioPerm && SpeechRecognizer.isRecognitionAvailable(this)) {
            try {
                stopInlineVoice()
                val sr = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = sr
                isListeningVoice = true
                keyboardView?.setVoiceListening(true)

                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}

                    override fun onError(error: Int) {
                        stopInlineVoice()
                        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ||
                            error == SpeechRecognizer.ERROR_CLIENT ||
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                        ) {
                            launchVoiceFallbackActivity(langTag)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spoken = matches?.firstOrNull()?.trim().orEmpty()
                        stopInlineVoice()
                        if (spoken.isNotEmpty()) {
                            currentInputConnection?.commitText("$spoken ", 1)
                            keyboardView?.refreshSuggestions()
                        }
                    }
                })

                val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                sr.startListening(recIntent)
                return
            } catch (_: Exception) {
                stopInlineVoice()
            }
        }

        launchVoiceFallbackActivity(langTag)
    }

    override fun onApplySuggestion(candidate: SpellCandidate) {
        feedback()
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(80, 0)?.toString() ?: ""
        if (candidate.replaceLastWord) {
            val match = Regex("([^\\s.,!?;:।]+)(\\s+)$").find(before)
            if (match != null) {
                ic.deleteSurroundingText(match.value.length, 0)
            }
        } else if (before.isNotEmpty() && !before.last().isWhitespace()) {
            val token = before.substringAfterLast(' ').substringAfterLast('\n')
            if (token.isNotEmpty()) {
                ic.deleteSurroundingText(token.length, 0)
            }
        }
        ic.commitText(candidate.word + " ", 1)
    }

    override fun getTextBeforeCursor(): String {
        return currentInputConnection?.getTextBeforeCursor(160, 0)?.toString() ?: ""
    }

    override fun onPreferencesChanged() {
        // persisted in SharedPreferences
    }

    override fun onSoundPreview() {
        feedback(isSpecial = false)
    }
}
