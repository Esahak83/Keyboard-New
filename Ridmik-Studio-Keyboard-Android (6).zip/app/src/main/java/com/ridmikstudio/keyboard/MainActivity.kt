package com.ridmikstudio.keyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#080A0F")) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(20)
            setPadding(p, dp(28), p, dp(28))
        }

        root.addView(TextView(this).apply {
            text = "Ridmik Studio Keyboard"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })

        root.addView(TextView(this).apply {
            text = "প্রভাত বাংলা ও English কিবোর্ড — Facebook, Messenger, WhatsApp সব অ্যাপে ব্যবহারের জন্য নিচের ধাপগুলো সম্পন্ন করুন:"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(8), 0, dp(18))
        })

        root.addView(makePrimaryBtn("১. কিবোর্ড চালু করুন (Enable Keyboard)") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })

        root.addView(makePrimaryBtn("২. Ridmik Studio সিলেক্ট করুন (Switch Keyboard)", "#1F2937", "#EF4444") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        root.addView(makePrimaryBtn("৩. ভয়েস টাইপিং মাইক অনুমতি দিন (Mic Permission)", "#111827", "#38BDF8") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "মাইক্রোফোন অনুমতি ইতিমধ্যে দেওয়া আছে", Toast.LENGTH_SHORT).show()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            }
        })

        root.addView(TextView(this).apply {
            text = "এখানে টাইপ করে পরীক্ষা করুন:"
            textSize = 13f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, dp(16), 0, dp(6))
        })

        root.addView(EditText(this).apply {
            hint = "এখানে ট্যাপ করে বাংলা বা ইংরেজি লিখুন..."
            typeface = FontHelper.banglaRegular(this@MainActivity)
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            minLines = 3
            gravity = Gravity.TOP
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#11151E"))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
        })

        // Sound & Vibration switches + Laptop/PC Sound selector
        root.addView(makeSwitch("কী-প্রেস সাউন্ড", prefs.getBoolean("sound_on", true)) { on ->
            prefs.edit().putBoolean("sound_on", on).apply()
        })

        root.addView(TextView(this).apply {
            text = "টাইপিং সাউন্ডের ধরন (ল্যাপটপ / পিসি / মেকানিক্যাল):"
            textSize = 12.5f
            typeface = FontHelper.banglaRegular(this@MainActivity)
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(4), 0, dp(6))
        })

        val sndRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply {
                bottomMargin = dp(8)
            }
        }
        val sndBtns = ArrayList<Button>()
        val sndOptions = listOf(
            "laptop" to "ল্যাপটপ",
            "pc" to "পিসি",
            "mechanical" to "মেকা",
            "soft" to "সফট",
            "off" to "বন্ধ"
        )
        fun refreshSoundBtns(sel: String) {
            for ((idx, pair) in sndOptions.withIndex()) {
                val active = pair.first == sel
                sndBtns[idx].background = GradientDrawable().apply {
                    setColor(Color.parseColor(if (active) "#EF4444" else "#11151E"))
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.parseColor(if (active) "#EF4444" else "#334155"))
                }
            }
        }
        val initSnd = if (!prefs.getBoolean("sound_on", true)) "off" else (prefs.getString("sound_profile", "laptop") ?: "laptop")
        for ((sndId, sndLabel) in sndOptions) {
            val btn = Button(this).apply {
                text = sndLabel
                isAllCaps = false
                textSize = 12f
                typeface = FontHelper.banglaBold(this@MainActivity)
                setTextColor(Color.WHITE)
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
                setOnClickListener {
                    prefs.edit()
                        .putString("sound_profile", sndId)
                        .putBoolean("sound_on", sndId != "off")
                        .apply()
                    refreshSoundBtns(sndId)
                }
            }
            sndBtns.add(btn)
            sndRow.addView(btn)
        }
        refreshSoundBtns(initSnd)
        root.addView(sndRow)

        root.addView(makeSwitch("ভাইব্রেশন ফিডব্যাক", prefs.getBoolean("vibrate_on", true)) { on ->
            prefs.edit().putBoolean("vibrate_on", on).apply()
        })
        root.addView(makeSwitch("বানান ও টাইপিং ভুল ডিকেক্টর", prefs.getBoolean("spell_check", true)) { on ->
            prefs.edit().putBoolean("spell_check", on).apply()
        })

        // Optional Gemini API key input for cloud AI spell check
        root.addView(TextView(this).apply {
            text = "ঐচ্ছিক: Gemini AI স্পেল-চেক (অফলাইনেও লোকাল ডিকেক্টর সবসময় কাজ করবে)"
            textSize = 12f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(16), 0, dp(6))
        })

        val keyInput = EditText(this).apply {
            hint = "Gemini API Key (ঐচ্ছিক)"
            setText(prefs.getString("gemini_api_key", ""))
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#11151E"))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
        }
        root.addView(keyInput)

        root.addView(makePrimaryBtn("সেটিংস সংরক্ষণ করুন", "#16A34A", "#16A34A") {
            prefs.edit().putString("gemini_api_key", keyInput.text.toString().trim()).apply()
        })

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun makePrimaryBtn(label: String, bgHex: String = "#EF4444", borderHex: String = "#EF4444", onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor(borderHex))
            }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)).apply {
                bottomMargin = dp(10)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeSwitch(label: String, checked: Boolean, onChanged: (Boolean) -> Unit): Switch {
        return Switch(this).apply {
            text = label
            isChecked = checked
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(12))
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
    }
}
