package com.ridmikstudio.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

object FontHelper {
    @Volatile private var bnReg: Typeface? = null
    @Volatile private var bnBold: Typeface? = null
    @Volatile private var enReg: Typeface? = null
    @Volatile private var enBold: Typeface? = null

    fun banglaRegular(context: Context): Typeface {
        bnReg?.let { return it }
        val loaded = try {
            Typeface.createFromAsset(context.applicationContext.assets, "fonts/NotoSansBengali-Regular.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT
        }
        bnReg = loaded
        return loaded
    }

    fun banglaBold(context: Context): Typeface {
        bnBold?.let { return it }
        val loaded = try {
            Typeface.createFromAsset(context.applicationContext.assets, "fonts/NotoSansBengali-SemiBold.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT_BOLD
        }
        bnBold = loaded
        return loaded
    }

    fun latinRegular(context: Context): Typeface {
        enReg?.let { return it }
        val loaded = try {
            Typeface.createFromAsset(context.applicationContext.assets, "fonts/PlusJakartaSans-Regular.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT
        }
        enReg = loaded
        return loaded
    }

    fun latinBold(context: Context): Typeface {
        enBold?.let { return it }
        val loaded = try {
            Typeface.createFromAsset(context.applicationContext.assets, "fonts/PlusJakartaSans-SemiBold.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT_BOLD
        }
        enBold = loaded
        return loaded
    }

    fun forText(context: Context, text: String, bold: Boolean = false): Typeface {
        val hasBn = text.any { it in '\u0964'..'\u09FF' || it == '৳' }
        return if (hasBn) {
            if (bold) banglaBold(context) else banglaRegular(context)
        } else {
            if (bold) latinBold(context) else latinRegular(context)
        }
    }
}

private object BanglaMarkRenderer {
    private const val SIZE = 160
    private const val BASE_X = 48f
    private const val BASE_Y = 108f
    private const val TEXT_PX = 86f
    private const val DOTTED_CIRCLE = "\u25CC"

    private val cache = HashMap<String, Bitmap>()
    private var tmplAlpha: IntArray? = null
    private var tmplX0 = 0
    private var tmplY0 = 0
    private var tmplW = 0
    private var tmplH = 0
    private var tmplChecked = false

    private var baseAlpha: IntArray? = null
    private var baseX0 = 0
    private var baseY0 = 0
    private var baseW = 0
    private var baseH = 0
    private var baseChecked = false

    private fun makePaint(context: Context): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = TEXT_PX
        typeface = FontHelper.banglaRegular(context)
        textLocale = Locale("bn", "BD")
    }

    private fun renderPixels(context: Context, text: String): IntArray {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawText(text, BASE_X, BASE_Y, makePaint(context))
        val px = IntArray(SIZE * SIZE)
        bmp.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        bmp.recycle()
        return px
    }

    private fun ensureTemplate(context: Context) {
        if (tmplChecked) return
        tmplChecked = true
        val p1 = renderPixels(context, "${DOTTED_CIRCLE}\u09BE") // ◌া
        val p2 = renderPixels(context, "${DOTTED_CIRCLE}\u09C1") // ◌ু
        val p3 = renderPixels(context, "${DOTTED_CIRCLE}\u0981") // ◌ঁ
        val inter = IntArray(SIZE * SIZE)
        var x0 = SIZE
        var y0 = SIZE
        var x1 = -1
        var y1 = -1

        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val i = y * SIZE + x
                val a = min(Color.alpha(p1[i]), min(Color.alpha(p2[i]), Color.alpha(p3[i])))
                inter[i] = a
                if (a > 24) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                    if (y < y0) y0 = y
                    if (y > y1) y1 = y
                }
            }
        }
        if (x1 <= x0 || y1 <= y0) return
        val w = x1 - x0 + 1
        val h = y1 - y0 + 1
        val arr = IntArray(w * h)
        for (ly in 0 until h) {
            for (lx in 0 until w) {
                arr[ly * w + lx] = inter[(y0 + ly) * SIZE + (x0 + lx)]
            }
        }
        tmplX0 = x0
        tmplY0 = y0
        tmplW = w
        tmplH = h
        tmplAlpha = arr
    }

    private fun ensureBaseConsonant(context: Context) {
        if (baseChecked) return
        baseChecked = true
        val px = renderPixels(context, "\u09AC") // ব
        var x0 = SIZE
        var y0 = SIZE
        var x1 = -1
        var y1 = -1
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                if (Color.alpha(px[y * SIZE + x]) > 20) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                    if (y < y0) y0 = y
                    if (y > y1) y1 = y
                }
            }
        }
        if (x1 <= x0 || y1 <= y0) return
        val w = x1 - x0 + 1
        val h = y1 - y0 + 1
        val arr = IntArray(w * h)
        for (ly in 0 until h) {
            for (lx in 0 until w) {
                arr[ly * w + lx] = Color.alpha(px[(y0 + ly) * SIZE + (x0 + lx)])
            }
        }
        baseX0 = x0
        baseY0 = y0
        baseW = w
        baseH = h
        baseAlpha = arr
    }

    private fun isFolaOrReph(ch: String): Boolean =
        ch == "র্" || ch == "\u09B0\u09CD" ||
        ch == "্য" || ch == "\u09CD\u09AF" ||
        ch == "্র" || ch == "\u09CD\u09B0"

    private fun folaTargetCluster(ch: String): String = when (ch) {
        "র্", "\u09B0\u09CD" -> "\u09B0\u09CD\u09AC" // র্ব
        "্য", "\u09CD\u09AF" -> "\u09AC\u09CD\u09AF" // ব্য
        else -> "\u09AC\u09CD\u09B0" // ব্র
    }

    private fun eraseTemplate(
        px: IntArray,
        tmpl: IntArray,
        tx0: Int,
        ty0: Int,
        tw: Int,
        th: Int,
        dxMin: Int,
        dxMax: Int,
        dyMin: Int,
        dyMax: Int
    ) {
        var bestDx = 0
        var bestDy = 0
        var bestScore = Long.MIN_VALUE
        val hx0 = (tw * 25) / 100
        val hx1 = (tw * 75) / 100
        val hy0 = (th * 25) / 100
        val hy1 = (th * 75) / 100

        for (dy in dyMin..dyMax) {
            if (ty0 + dy < 0 || ty0 + dy + th >= SIZE) continue
            for (dx in dxMin..dxMax) {
                if (tx0 + dx < 0 || tx0 + dx + tw >= SIZE) continue
                var score = 0L
                for (ly in 0 until th) {
                    val sy = ty0 + dy + ly
                    for (lx in 0 until tw) {
                        val sx = tx0 + dx + lx
                        val ba = Color.alpha(px[sy * SIZE + sx])
                        val ta = tmpl[ly * tw + lx]
                        if (ta > 20) {
                            score += min(ba, ta)
                        } else if (ta < 8 && lx in hx0..hx1 && ly in hy0..hy1) {
                            score -= ba * 2L
                        }
                    }
                }
                if (score > bestScore) {
                    bestScore = score
                    bestDx = dx
                    bestDy = dy
                }
            }
        }

        if (bestScore > 0L) {
            for (ly in 0 until th) {
                val sy = ty0 + bestDy + ly
                if (sy !in 0 until SIZE) continue
                for (lx in 0 until tw) {
                    val sx = tx0 + bestDx + lx
                    if (sx !in 0 until SIZE) continue
                    val ta = tmpl[ly * tw + lx]
                    val idx = sy * SIZE + sx
                    if (ta > 10) {
                        px[idx] = 0
                    } else if (ta > 2) {
                        val na = max(0, Color.alpha(px[idx]) - ta * 3)
                        px[idx] = Color.argb(na, 255, 255, 255)
                    }
                }
            }
        }
    }

    @Synchronized
    fun getBitmap(context: Context, ch: String, isSub: Boolean): Bitmap? {
        val key = "$ch:$isSub"
        cache[key]?.let { return it }

        val fola = isFolaOrReph(ch)
        val px = renderPixels(context, if (fola) folaTargetCluster(ch) else "$DOTTED_CIRCLE$ch")
        if (fola) {
            ensureBaseConsonant(context)
            val bt = baseAlpha
            if (bt != null && baseW > 0 && baseH > 0) {
                eraseTemplate(px, bt, baseX0, baseY0, baseW, baseH, -4, 8, -8, 4)
            }
        } else {
            ensureTemplate(context)
            val tmpl = tmplAlpha
            if (tmpl != null && tmplW > 0 && tmplH > 0) {
                eraseTemplate(px, tmpl, tmplX0, tmplY0, tmplW, tmplH, -12, SIZE - tmplX0 - tmplW - 2, 0, 0)
            }
        }

        var minX = SIZE
        var minY = SIZE
        var maxX = -1
        var maxY = -1
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                if (Color.alpha(px[y * SIZE + x]) > 14) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < minX || maxY < minY) return null

        val cx0: Int
        val cx1: Int
        val cy0: Int
        val cy1: Int
        if (fola) {
            val midX = (minX + maxX) / 2
            val midY = (minY + maxY) / 2
            val halfMin = 22
            cx0 = max(0, min(minX - 5, midX - halfMin))
            cx1 = min(SIZE - 1, max(maxX + 5, midX + halfMin))
            cy0 = max(0, min(minY - 5, midY - halfMin))
            cy1 = min(SIZE - 1, max(maxY + 5, midY + halfMin))
        } else {
            val padX = 4
            cx0 = max(0, minX - padX)
            cx1 = min(SIZE - 1, maxX + padX)
            cy0 = if (isSub) max(0, minY - 3) else max(0, min(minY - 2, BASE_Y.toInt() - 56))
            cy1 = if (isSub) min(SIZE - 1, maxY + 3) else min(SIZE - 1, max(maxY + 2, BASE_Y.toInt() + 18))
        }

        val cw = cx1 - cx0 + 1
        val chOut = cy1 - cy0 + 1
        val cropped = IntArray(cw * chOut)
        for (y in 0 until chOut) {
            for (x in 0 until cw) {
                val a = Color.alpha(px[(cy0 + y) * SIZE + (cx0 + x)])
                cropped[y * cw + x] = Color.argb(a, 255, 255, 255)
            }
        }

        val out = Bitmap.createBitmap(cw, chOut, Bitmap.Config.ARGB_8888)
        out.setPixels(cropped, 0, cw, 0, 0, cw, chOut)
        cache[key] = out
        return out
    }
}

class BanglaMarkView(context: Context) : View(context) {
    private var markChar: String = ""
    private var isSubMark: Boolean = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRect = RectF()

    companion object {
        private val MARKS = setOf(
            "া", "ি", "ী", "ু", "ূ", "ে", "ৈ", "ো", "ৌ", "ঃ", "ং", "্", "ৃ", "ঁ",
            "্র", "্য", "র্", "\u09CD\u09B0", "\u09CD\u09AF", "\u09B0\u09CD"
        )
        fun isMark(ch: String): Boolean = MARKS.contains(ch)
    }

    fun setMark(ch: String, color: Int, isSub: Boolean = false) {
        markChar = ch
        isSubMark = isSub
        paint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (markChar.isEmpty() || width == 0 || height == 0) return
        val bmp = BanglaMarkRenderer.getBitmap(context, markChar, isSubMark) ?: return

        val availW = width.toFloat()
        val availH = height.toFloat()
        val scale = min(availW / bmp.width.toFloat(), availH / bmp.height.toFloat())
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        val left = (availW - dw) / 2f
        val top = (availH - dh) / 2f

        srcRect.set(0, 0, bmp.width, bmp.height)
        dstRect.set(left, top, left + dw, top + dh)
        canvas.drawBitmap(bmp, srcRect, dstRect, paint)
    }
}
