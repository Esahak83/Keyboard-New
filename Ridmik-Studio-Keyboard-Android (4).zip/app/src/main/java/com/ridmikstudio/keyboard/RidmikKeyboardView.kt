package com.ridmikstudio.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

private class ToggleCircleTView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private var activeBg: Int = Color.TRANSPARENT
    private var isActive: Boolean = false
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val arcRect = RectF()
    private val arrowPath = Path()

    fun setStyle(active: Boolean, fg: Int, bg: Int) {
        isActive = active
        fgColor = fg
        activeBg = bg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val minSide = minOf(width, height).toFloat()
        if (minSide <= 6f) return

        val cx = width / 2f
        val cy = height / 2f

        if (isActive) {
            fillPaint.color = activeBg
            canvas.drawCircle(cx, cy, minSide * 0.45f, fillPaint)
        }

        // Normalized 24x24 SVG coordinate space (matching Web SVG)
        val box = minSide * 0.72f
        val s = box / 24f
        val ox = cx - 12f * s
        val oy = cy - 12f * s

        ringPaint.color = fgColor
        ringPaint.strokeWidth = 1.4f * s
        val r = 8.6f * s
        arcRect.set(ox + (12f - 8.6f) * s, oy + (12f - 8.6f) * s, ox + (12f + 8.6f) * s, oy + (12f + 8.6f) * s)

        // Slender circular double-arrows leaving top & bottom clear
        canvas.drawArc(arcRect, 204f, 128f, false, ringPaint)
        canvas.drawArc(arcRect, 24f, 128f, false, ringPaint)

        // Small compact arrowheads tucked cleanly at 332 deg & 152 deg
        drawChevron(canvas, ox, oy, s, 19.0f, 4.4f, 19.0f, 6.8f, 16.6f, 6.8f)
        drawChevron(canvas, ox, oy, s, 5.0f, 19.6f, 5.0f, 17.2f, 7.4f, 17.2f)

        // Crisp geometric Serif T so top horizontal crossbar is unmistakably sharp
        tPaint.color = fgColor
        tPaint.strokeWidth = 2.1f * s
        canvas.drawLine(ox + 7.8f * s, oy + 8.4f * s, ox + 16.2f * s, oy + 8.4f * s, tPaint)

        tPaint.strokeWidth = 1.4f * s
        canvas.drawLine(ox + 7.9f * s, oy + 8.4f * s, ox + 7.9f * s, oy + 9.8f * s, tPaint)
        canvas.drawLine(ox + 16.1f * s, oy + 8.4f * s, ox + 16.1f * s, oy + 9.8f * s, tPaint)

        tPaint.strokeWidth = 1.95f * s
        canvas.drawLine(ox + 12.0f * s, oy + 8.4f * s, ox + 12.0f * s, oy + 15.8f * s, tPaint)

        tPaint.strokeWidth = 1.45f * s
        canvas.drawLine(ox + 10.3f * s, oy + 15.8f * s, ox + 13.7f * s, oy + 15.8f * s, tPaint)
    }

    private fun drawChevron(
        canvas: Canvas,
        ox: Float,
        oy: Float,
        s: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float
    ) {
        arrowPath.reset()
        arrowPath.moveTo(ox + x1 * s, oy + y1 * s)
        arrowPath.lineTo(ox + x2 * s, oy + y2 * s)
        arrowPath.lineTo(ox + x3 * s, oy + y3 * s)
        canvas.drawPath(arrowPath, ringPaint)
    }
}

private class MicIconView(context: Context) : View(context) {
    private var fgColor: Int = Color.WHITE
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val capsuleRect = RectF()
    private val cradleRect = RectF()

    fun setStyle(fg: Int) {
        fgColor = fg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val unit = minOf(width, height).toFloat()
        if (unit <= 4f) return

        fillPaint.color = fgColor
        strokePaint.color = fgColor
        strokePaint.strokeWidth = 1.8f * d

        // Capsule head
        val capW = unit * 0.24f
        val capH = unit * 0.42f
        val capTop = cy - unit * 0.30f
        capsuleRect.set(cx - capW / 2f, capTop, cx + capW / 2f, capTop + capH)
        canvas.drawRoundRect(capsuleRect, capW / 2f, capW / 2f, fillPaint)

        // U cradle arc around capsule
        val crRx = unit * 0.23f
        val crTop = cy - unit * 0.14f
        val crBottom = cy + unit * 0.19f
        cradleRect.set(cx - crRx, crTop, cx + crRx, crBottom)
        canvas.drawArc(cradleRect, 0f, 180f, false, strokePaint)

        // Vertical stem + base line
        canvas.drawLine(cx, crBottom, cx, cy + unit * 0.31f, strokePaint)
        canvas.drawLine(cx - unit * 0.15f, cy + unit * 0.31f, cx + unit * 0.15f, cy + unit * 0.31f, strokePaint)
    }
}

class RidmikKeyboardView(
    context: Context,
    private val callbacks: Callbacks
) : LinearLayout(context) {

    interface Callbacks {
        fun onCommitText(text: String)
        fun onBackspace()
        fun onDeleteWord()
        fun onEnter()
        fun onMoveCursor(action: String)
        fun onSelectAll()
        fun onCopy()
        fun onCut()
        fun onPasteSystem()
        fun onVoiceInput()
        fun onApplySuggestion(candidate: SpellCandidate)
        fun getTextBeforeCursor(): String
        fun onPreferencesChanged()
        fun onSoundPreview()
    }

    enum class Panel { KEYS, EMOJI, CURSOR, CLIPBOARD, THEMES, SETTINGS }

    private val prefs = context.getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
    private val clipStore = ClipboardStore(context)
    private val mainHandler = Handler(Looper.getMainLooper())

    var language: KeyboardLanguage = KeyboardLanguage.ENGLISH
        private set
    private var layer: KeyLayer = KeyLayer.ALPHA
    private var shift: Boolean = false
    private var capsLock: Boolean = false
    private var lastShiftTap: Long = 0L
    private var activePanel: Panel = Panel.KEYS
    private var showToolbar: Boolean = false
    private var isVoiceListening: Boolean = false
    private var emojiCatId: String = "recent"
    private var clipPinnedTab: Boolean = true

    private var theme: KeyboardTheme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
    private var keyHeightMode: String = prefs.getString("key_height", "standard") ?: "standard"
    private var soundProfile: String = prefs.getString("sound_profile", "laptop") ?: "laptop"
    private var showNumberRow: Boolean = prefs.getBoolean("show_num_row", false)
    private var showPopup: Boolean = prefs.getBoolean("show_popup", true)
    private var spellCheckEnabled: Boolean = prefs.getBoolean("spell_check", true)
    private val recentEmojis: MutableList<String> = (
        prefs.getString("recent_emojis", "😀,❤️,🇧🇩,👍,🔥,✨") ?: "😀,❤️,🇧🇩,👍,🔥,✨"
    ).split(",").filter { it.isNotEmpty() }.toMutableList()

    private var currentSuggestions: List<SpellCandidate> = emptyList()
    private var aiSuggestions: List<SpellCandidate> = emptyList()
    private var aiDebounceRunnable: Runnable? = null

    private val topBarRow = LinearLayout(context)
    private val toolbarContainer = LinearLayout(context)
    private val suggestionStripScroll = HorizontalScrollView(context)
    private val suggestionStrip = LinearLayout(context)
    private val bodyContainer = FrameLayout(context)

    private var keyPopupWindow: PopupWindow? = null
    private var keyPopupText: TextView? = null
    private var keyPopupMark: BanglaMarkView? = null
    private var altPopupWindow: PopupWindow? = null
    private var altActiveOptions: List<AltKeyOption> = emptyList()
    private val altTileCards = ArrayList<FrameLayout>()
    private var altSelectedIdx: Int = 0
    private var altPopupScreenX: Float = 0f
    private var altTileStepPx: Float = 1f

    private var bsHoldRunnable: Runnable? = null
    private var bsRepeatRunnable: Runnable? = null
    private var bsDidRepeat = false
    private var bsDidSwipe = false
    private var bsStartX = 0f

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        rebuildAll()
    }

    private fun recordRecentEmoji(em: String) {
        recentEmojis.remove(em)
        recentEmojis.add(0, em)
        if (recentEmojis.size > 28) {
            recentEmojis.subList(28, recentEmojis.size).clear()
        }
        prefs.edit().putString("recent_emojis", recentEmojis.joinToString(",")).apply()
    }

    fun setVoiceListening(listening: Boolean) {
        if (isVoiceListening == listening) return
        isVoiceListening = listening
        renderTopBarContent()
    }

    fun reloadFromPrefs() {
        theme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
        keyHeightMode = prefs.getString("key_height", "standard") ?: "standard"
        soundProfile = prefs.getString("sound_profile", "laptop") ?: "laptop"
        showNumberRow = prefs.getBoolean("show_num_row", false)
        showPopup = prefs.getBoolean("show_popup", true)
        spellCheckEnabled = prefs.getBoolean("spell_check", true)
        rebuildAll()
    }

    fun refreshSuggestions() {
        if (activePanel != Panel.KEYS || showToolbar) {
            renderTopBarContent()
            return
        }
        if (!spellCheckEnabled) {
            currentSuggestions = emptyList()
            renderSuggestions()
            return
        }
        val before = callbacks.getTextBeforeCursor()
        val local = SpellDetector.suggestLocal(before, language)
        currentSuggestions = if (aiSuggestions.isNotEmpty()) {
            (aiSuggestions + local).distinctBy { it.word }.take(5)
        } else local
        renderSuggestions()
        scheduleAiCheck(before)
    }

    private fun scheduleAiCheck(before: String) {
        aiDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        val apiKey = prefs.getString("gemini_api_key", "") ?: ""
        if (apiKey.isBlank()) return

        val trimmedEnd = before.trimEnd()
        val word = if (before.endsWith(" ")) trimmedEnd.split(Regex("\\s+")).lastOrNull().orEmpty()
        else before.substringAfterLast(' ').substringAfterLast('\n')
        if (word.length < 3 || SpellDetector.isKnownWord(word, language)) {
            aiSuggestions = emptyList()
            return
        }
        val r = Runnable {
            Thread {
                val res = SpellDetector.fetchAiCorrection(apiKey, word, before.dropLast(word.length), language)
                if (res.isNotEmpty()) {
                    val isLast = before.endsWith(" ")
                    aiSuggestions = res.map { SpellCandidate(it, isCorrection = true, isAi = true, replaceLastWord = isLast) }
                    mainHandler.post {
                        val local = SpellDetector.suggestLocal(callbacks.getTextBeforeCursor(), language)
                        currentSuggestions = (aiSuggestions + local).distinctBy { it.word }.take(5)
                        renderSuggestions()
                    }
                }
            }.start()
        }
        aiDebounceRunnable = r
        mainHandler.postDelayed(r, 900L)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBox(bg: Int, border: Int, radiusDp: Int = 8, strokeDp: Int = 1): GradientDrawable {
        return GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(strokeDp), border)
        }
    }

    fun rebuildAll() {
        hideAltPopup()
        setBackgroundColor(theme.boardBg)
        removeAllViews()
        buildTopBar()
        addView(topBarRow)
        addView(bodyContainer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        renderBody()
        refreshSuggestions()
    }

    private fun buildTopBar() {
        topBarRow.removeAllViews()
        topBarRow.orientation = HORIZONTAL
        topBarRow.gravity = Gravity.CENTER_VERTICAL
        topBarRow.setBackgroundColor(if (showToolbar) theme.toolbarBg else theme.suggestionBg)
        topBarRow.setPadding(dp(6), dp(4), dp(6), dp(4))
        topBarRow.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(42))
        topBarRow.visibility = if (activePanel == Panel.KEYS || showToolbar) View.VISIBLE else View.GONE

        // Leftmost circular-arrow T cycle toggle button
        val tToggle = ToggleCircleTView(context).apply {
            setStyle(
                active = showToolbar,
                fg = if (showToolbar) Color.WHITE else theme.accentText,
                bg = theme.accent
            )
            layoutParams = LayoutParams(dp(32), dp(32)).apply {
                setMargins(dp(2), 0, dp(4), 0)
            }
            contentDescription = "টুলবার ও সাজেশন পরিবর্তন"
            setOnClickListener {
                showToolbar = !showToolbar
                rebuildAll()
            }
        }
        topBarRow.addView(tToggle)

        val sep = View(context).apply {
            setBackgroundColor(theme.keyBorder)
            layoutParams = LayoutParams(dp(1), dp(20)).apply { setMargins(dp(2), 0, dp(5), 0) }
        }
        topBarRow.addView(sep)

        buildToolbar()
        buildSuggestionStrip()
        topBarRow.addView(toolbarContainer, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        topBarRow.addView(suggestionStripScroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        renderTopBarContent()
    }

    private fun renderTopBarContent() {
        topBarRow.visibility = if (activePanel == Panel.KEYS || showToolbar) View.VISIBLE else View.GONE
        topBarRow.setBackgroundColor(if (showToolbar) theme.toolbarBg else theme.suggestionBg)
        if (showToolbar) {
            toolbarContainer.visibility = View.VISIBLE
            suggestionStripScroll.visibility = View.GONE
            buildToolbar()
        } else {
            toolbarContainer.visibility = View.GONE
            suggestionStripScroll.visibility = View.VISIBLE
            renderSuggestions()
        }
    }

    private fun buildToolbar() {
        toolbarContainer.removeAllViews()
        toolbarContainer.orientation = HORIZONTAL
        toolbarContainer.gravity = Gravity.CENTER_VERTICAL
        toolbarContainer.setBackgroundColor(Color.TRANSPARENT)

        // 1. ব / En
        toolbarContainer.addView(makeToolBtn(if (language == KeyboardLanguage.ENGLISH) "ব" else "En", language == KeyboardLanguage.PROVAT) {
            language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
            layer = KeyLayer.ALPHA
            shift = false
            capsLock = false
            activePanel = Panel.KEYS
            aiSuggestions = emptyList()
            rebuildAll()
        })

        // 2. Emoji
        toolbarContainer.addView(makeToolBtn("☺", activePanel == Panel.EMOJI) {
            activePanel = if (activePanel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI
            rebuildAll()
        })

        // 3. Cursor ◄|►
        toolbarContainer.addView(makeToolBtn("◄|►", activePanel == Panel.CURSOR) {
            activePanel = if (activePanel == Panel.CURSOR) Panel.KEYS else Panel.CURSOR
            rebuildAll()
        })

        // 4. Clipboard
        toolbarContainer.addView(makeToolBtn("📋", activePanel == Panel.CLIPBOARD) {
            activePanel = if (activePanel == Panel.CLIPBOARD) Panel.KEYS else Panel.CLIPBOARD
            rebuildAll()
        })

        // 5. Theme
        toolbarContainer.addView(makeToolBtn("🎨", activePanel == Panel.THEMES) {
            activePanel = if (activePanel == Panel.THEMES) Panel.KEYS else Panel.THEMES
            rebuildAll()
        })

        // 6. Settings Gear
        toolbarContainer.addView(makeToolBtn("⚙", activePanel == Panel.SETTINGS) {
            activePanel = if (activePanel == Panel.SETTINGS) Panel.KEYS else Panel.SETTINGS
            rebuildAll()
        })

        // 7. Crisp Vector Voice Microphone (replaces mouthpiece/karaoke emoji)
        val micWrap = FrameLayout(context).apply {
            background = roundedBox(
                if (isVoiceListening) theme.accent else Color.TRANSPARENT,
                if (isVoiceListening) theme.accent else Color.TRANSPARENT,
                8
            )
            layoutParams = LayoutParams(0, dp(34), 1f).apply {
                setMargins(dp(2), 0, dp(1), 0)
            }
            contentDescription = "ভয়েস টাইপিং"
            setOnClickListener {
                callbacks.onVoiceInput()
            }
        }
        val micIcon = MicIconView(context).apply {
            setStyle(if (isVoiceListening) Color.WHITE else theme.accentText)
            layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        }
        micWrap.addView(micIcon)
        toolbarContainer.addView(micWrap)
    }

    private fun makeToolBtn(label: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 14.5f
            typeface = FontHelper.forText(context, label, bold = true)
            gravity = Gravity.CENTER
            setTextColor(theme.accentText)
            background = roundedBox(
                if (active) Color.argb(45, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent)) else Color.TRANSPARENT,
                if (active) theme.accent else Color.TRANSPARENT,
                8
            )
            layoutParams = LayoutParams(0, dp(34), 1f).apply {
                setMargins(dp(1), 0, dp(1), 0)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildSuggestionStrip() {
        suggestionStripScroll.isHorizontalScrollBarEnabled = false
        suggestionStripScroll.setBackgroundColor(Color.TRANSPARENT)
        suggestionStrip.orientation = HORIZONTAL
        suggestionStrip.gravity = Gravity.CENTER_VERTICAL
        suggestionStrip.setPadding(dp(2), dp(2), dp(4), dp(2))
        suggestionStripScroll.removeAllViews()
        suggestionStripScroll.addView(suggestionStrip)
    }

    private fun renderSuggestions() {
        suggestionStrip.removeAllViews()

        if (isVoiceListening) {
            val listeningBadge = TextView(context).apply {
                text = "শুনছি... কথা বলুন (থামাতে T -> মাইক)"
                textSize = 12f
                typeface = FontHelper.banglaBold(context)
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = roundedBox(theme.accent, theme.accent, 7)
            }
            suggestionStrip.addView(listeningBadge)
            return
        }

        if (!spellCheckEnabled) {
            val offTv = TextView(context).apply {
                text = "শব্দ প্রেডিকশন বন্ধ"
                textSize = 11f
                typeface = FontHelper.banglaRegular(context)
                setTextColor(theme.subText)
            }
            suggestionStrip.addView(offTv)
            return
        }

        val hasCorr = currentSuggestions.any { it.isCorrection }
        val tagText = if (hasCorr) "শুদ্ধ:" else "শব্দ:"
        val tag = TextView(context).apply {
            text = tagText
            textSize = 11f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(if (hasCorr) theme.accentText else theme.subText)
            setPadding(dp(2), 0, dp(6), 0)
        }
        suggestionStrip.addView(tag)

        for ((idx, cand) in currentSuggestions.withIndex()) {
            val chipText = if (cand.isAi) "✦ ${cand.word}" else if (cand.isCorrection) "✓ ${cand.word}" else cand.word
            val chip = TextView(context).apply {
                text = chipText
                textSize = 13.5f
                typeface = FontHelper.forText(context, cand.word, bold = (cand.isCorrection || idx == 0))
                setTextColor(if (cand.isCorrection && idx == 0) Color.WHITE else theme.keyText)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = roundedBox(
                    when {
                        cand.isCorrection && idx == 0 -> theme.accent
                        cand.isCorrection -> Color.argb(50, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        idx == 0 -> theme.keyBg
                        else -> Color.TRANSPARENT
                    },
                    if (cand.isCorrection || idx == 0) theme.accent else Color.TRANSPARENT,
                    7
                )
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, 0, dp(6), 0)
                }
                setOnClickListener {
                    aiSuggestions = emptyList()
                    callbacks.onApplySuggestion(cand)
                    refreshSuggestions()
                }
            }
            suggestionStrip.addView(chip)
        }
    }

    private fun renderBody() {
        hideAltPopup()
        bodyContainer.removeAllViews()
        when (activePanel) {
            Panel.KEYS -> renderKeysPanel()
            Panel.EMOJI -> renderEmojiPanel()
            Panel.CURSOR -> renderCursorPanel()
            Panel.CLIPBOARD -> renderClipboardPanel()
            Panel.THEMES -> renderThemesPanel()
            Panel.SETTINGS -> renderSettingsPanel()
        }
    }

    private fun keyHeightDp(): Int = when (keyHeightMode) {
        "compact" -> 52
        "tall" -> 70
        else -> 62
    }

    private fun renderKeysPanel() {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val keyH = dp(keyHeightDp())

        if (showNumberRow && layer == KeyLayer.ALPHA) {
            val numRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(5) }
            }
            val nums = if (language == KeyboardLanguage.ENGLISH) KeyboardLayouts.NUMBER_ROW_EN else KeyboardLayouts.NUMBER_ROW_BN
            for (k in nums) numRow.addView(createKeyView(k, dp(36)))
            root.addView(numRow)
        }

        val rows = when (layer) {
            KeyLayer.SYMBOLS1 -> KeyboardLayouts.SYMBOL_ROWS_1
            KeyLayer.SYMBOLS2 -> KeyboardLayouts.SYMBOL_ROWS_2
            KeyLayer.ALPHA -> if (language == KeyboardLanguage.PROVAT) KeyboardLayouts.PROVAT_ROWS else KeyboardLayouts.QWERTY_ROWS
        }

        for ((rIdx, row) in rows.withIndex()) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH).apply { bottomMargin = dp(5) }
                if (rIdx == 1 && row.size == 9) setPadding(dp(12), 0, dp(12), 0)
            }
            for (k in row) rowLayout.addView(createKeyView(k, keyH))
            root.addView(rowLayout)
        }

        // Bottom Row
        val bottomRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH)
        }

        bottomRow.addView(makeActionKey(if (layer == KeyLayer.ALPHA) "?123" else "ABC", 1.25f, theme.fnKeyBg, theme.fnKeyBorder, theme.accentText, 24) {
            layer = if (layer == KeyLayer.ALPHA) KeyLayer.SYMBOLS1 else KeyLayer.ALPHA
            rebuildAll()
        })
        bottomRow.addView(makeActionKey(",", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, 8) {
            callbacks.onCommitText(",")
            refreshSuggestions()
        })
        bottomRow.addView(makeActionKey("☺", 0.95f, theme.fnKeyBg, theme.fnKeyBorder, theme.accentText, 8) {
            activePanel = if (activePanel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI
            rebuildAll()
        })
        bottomRow.addView(createSpacebar(keyH))
        bottomRow.addView(makeActionKey(if (language == KeyboardLanguage.ENGLISH) "." else "।", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, 8) {
            callbacks.onCommitText(if (language == KeyboardLanguage.ENGLISH) "." else "।")
            refreshSuggestions()
        })
        bottomRow.addView(makeActionKey("↵", 1.4f, theme.enterBg, theme.enterBg, Color.WHITE, 12) {
            aiSuggestions = emptyList()
            callbacks.onEnter()
            refreshSuggestions()
        })

        root.addView(bottomRow)
        bodyContainer.addView(root)
    }

    private fun createKeyView(k: KeyDef, keyH: Int): View {
        val isFn = k.kind != KeyKind.CHAR
        val bg = when {
            k.kind == KeyKind.SHIFT && (shift || capsLock) -> theme.accent
            isFn -> theme.fnKeyBg
            else -> theme.keyBg
        }
        val border = when {
            k.kind == KeyKind.SHIFT && (shift || capsLock) -> theme.accent
            isFn -> theme.fnKeyBorder
            else -> theme.keyBorder
        }

        val frame = FrameLayout(context).apply {
            background = roundedBox(bg, border, 8)
            layoutParams = LayoutParams(0, keyH, k.flex).apply {
                val gap = if (language == KeyboardLanguage.PROVAT && layer == KeyLayer.ALPHA) dp(1) else dp(2)
                setMargins(gap, 0, gap, 0)
            }
        }

        val displayChar = when {
            k.kind == KeyKind.SHIFT -> if (capsLock) "⇪" else "⇧"
            k.kind == KeyKind.BACKSPACE -> "⌫"
            shift && k.shiftLabel != null -> k.shiftLabel
            language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA ->
                if (shift) k.label.uppercase() else k.label.lowercase()
            else -> k.label
        }

        if (k.subLabel != null && k.kind == KeyKind.CHAR) {
            if (BanglaMarkView.isMark(k.subLabel)) {
                val subMark = BanglaMarkView(context).apply {
                    setMark(k.subLabel, theme.subText, isSub = true)
                    layoutParams = FrameLayout.LayoutParams(dp(13), dp(13), Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(3); rightMargin = dp(3)
                    }
                }
                frame.addView(subMark)
            } else {
                val subTv = TextView(context).apply {
                    text = k.subLabel
                    textSize = 10f
                    typeface = FontHelper.forText(context, k.subLabel)
                    setTextColor(theme.subText)
                    layoutParams = FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(2); rightMargin = dp(4)
                    }
                }
                frame.addView(subTv)
            }
        }

        if (k.kind == KeyKind.CHAR && BanglaMarkView.isMark(displayChar)) {
            val markView = BanglaMarkView(context).apply {
                setMark(displayChar, theme.keyText, isSub = false)
                layoutParams = FrameLayout.LayoutParams(dp(26), dp(28), Gravity.CENTER).apply {
                    if (language == KeyboardLanguage.PROVAT) topMargin = dp(4)
                }
            }
            frame.addView(markView)
        } else {
            val mainTv = TextView(context).apply {
                text = displayChar
                textSize = if (k.kind == KeyKind.LAYER) 12.5f else if (isFn) 18f else if (language == KeyboardLanguage.PROVAT) 19.5f else 19f
                typeface = FontHelper.forText(context, displayChar)
                setTextColor(when {
                    k.kind == KeyKind.SHIFT && (shift || capsLock) -> Color.WHITE
                    k.kind == KeyKind.SHIFT || k.kind == KeyKind.BACKSPACE || k.kind == KeyKind.LAYER -> theme.accentText
                    else -> theme.keyText
                })
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
                    if (language == KeyboardLanguage.PROVAT && k.kind == KeyKind.CHAR) topMargin = dp(5)
                }
            }
            frame.addView(mainTv)
        }

        if (k.kind == KeyKind.BACKSPACE) {
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideAltPopup()
                        bsStartX = event.x
                        bsDidRepeat = false
                        bsDidSwipe = false
                        frame.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                        bsHoldRunnable = Runnable {
                            bsDidRepeat = true
                            callbacks.onBackspace()
                            val rep = object : Runnable {
                                override fun run() {
                                    callbacks.onBackspace()
                                    mainHandler.postDelayed(this, 52L)
                                }
                            }
                            bsRepeatRunnable = rep
                            mainHandler.postDelayed(rep, 52L)
                        }
                        mainHandler.postDelayed(bsHoldRunnable!!, 320L)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (event.x - bsStartX <= -dp(26)) {
                            clearBsTimers()
                            bsDidSwipe = true
                            bsStartX = event.x
                            callbacks.onDeleteWord()
                            refreshSuggestions()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        clearBsTimers()
                        frame.background = roundedBox(bg, border, 8)
                        if (!bsDidRepeat && !bsDidSwipe && event.action == MotionEvent.ACTION_UP) {
                            callbacks.onBackspace()
                            refreshSuggestions()
                        } else {
                            refreshSuggestions()
                        }
                        true
                    }
                    else -> false
                }
            }
        } else {
            var longPressTriggered = false
            val lpRunnable = Runnable {
                if (k.kind == KeyKind.CHAR && k.altOptions.isNotEmpty()) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    showAltOptionsPopup(frame, k.altOptions)
                } else if (k.kind == KeyKind.CHAR && k.id == "v" && language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    callbacks.onPasteSystem()
                    refreshSuggestions()
                } else if (k.kind == KeyKind.CHAR && k.subLabel != null) {
                    longPressTriggered = true
                    hideKeyPopupBubble()
                    callbacks.onCommitText(k.subLabel)
                    refreshSuggestions()
                }
            }
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideAltPopup()
                        longPressTriggered = false
                        frame.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                        if (showPopup && k.kind == KeyKind.CHAR) showKeyPopupBubble(frame, displayChar)
                        if (k.kind == KeyKind.CHAR && (k.altOptions.isNotEmpty() || k.subLabel != null)) {
                            mainHandler.postDelayed(lpRunnable, 340L)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (longPressTriggered && altActiveOptions.isNotEmpty()) {
                            val nextIdx = ((event.rawX - altPopupScreenX) / altTileStepPx)
                                .toInt()
                                .coerceIn(0, altActiveOptions.lastIndex)
                            updateAltPopupSelection(nextIdx)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        frame.background = roundedBox(bg, border, 8)
                        if (longPressTriggered && k.altOptions.isNotEmpty() && altActiveOptions.isNotEmpty()) {
                            val chosen = altActiveOptions[altSelectedIdx.coerceIn(0, altActiveOptions.lastIndex)]
                            hideAltPopup()
                            callbacks.onCommitText(chosen.value)
                            refreshSuggestions()
                        } else if (!longPressTriggered) {
                            handleKeyTap(k)
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        hideAltPopup()
                        frame.background = roundedBox(bg, border, 8)
                        true
                    }
                    else -> false
                }
            }
        }
        return frame
    }

    private fun clearBsTimers() {
        bsHoldRunnable?.let { mainHandler.removeCallbacks(it) }
        bsRepeatRunnable?.let { mainHandler.removeCallbacks(it) }
        bsHoldRunnable = null
        bsRepeatRunnable = null
    }

    private fun handleKeyTap(k: KeyDef) {
        when (k.kind) {
            KeyKind.SHIFT -> {
                val now = System.currentTimeMillis()
                if (now - lastShiftTap < 280L) {
                    capsLock = !capsLock
                    shift = capsLock
                } else if (capsLock) {
                    capsLock = false
                    shift = false
                } else {
                    shift = !shift
                }
                lastShiftTap = now
                renderBody()
            }
            KeyKind.LAYER -> {
                layer = if (k.id == "layer2") KeyLayer.SYMBOLS2 else KeyLayer.SYMBOLS1
                renderBody()
            }
            else -> {
                val out = when {
                    shift && k.shiftValue != null -> k.shiftValue
                    language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA && !shift ->
                        (k.value ?: k.label).lowercase()
                    else -> k.value ?: k.label
                }
                callbacks.onCommitText(out)
                if (shift && !capsLock) {
                    shift = false
                    renderBody()
                }
                refreshSuggestions()
            }
        }
    }

    private fun createSpacebar(keyH: Int): View {
        val label = if (language == KeyboardLanguage.ENGLISH) "‹  English  ›" else "‹  প্রভাত  ›"
        val btn = TextView(context).apply {
            text = label
            textSize = 13f
            typeface = FontHelper.forText(context, label, bold = false)
            setTextColor(theme.keyText)
            gravity = Gravity.CENTER
            background = roundedBox(theme.keyBg, theme.keyBorder, 8)
            layoutParams = LayoutParams(0, keyH, 3.2f).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        var startX = 0f
        var swiped = false
        btn.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x
                    swiped = false
                    btn.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!swiped && kotlin.math.abs(event.x - startX) >= dp(24)) {
                        swiped = true
                        language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
                        layer = KeyLayer.ALPHA
                        shift = false
                        capsLock = false
                        aiSuggestions = emptyList()
                        rebuildAll()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    btn.background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    if (!swiped) {
                        callbacks.onCommitText(" ")
                        refreshSuggestions()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    btn.background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    true
                }
                else -> false
            }
        }
        return btn
    }

    private fun makeActionKey(label: String, weight: Float, bg: Int, border: Int, fg: Int, radiusDp: Int, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 14.5f
            typeface = FontHelper.forText(context, label, bold = true)
            setTextColor(fg)
            gravity = Gravity.CENTER
            background = roundedBox(bg, border, radiusDp)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply { setMargins(dp(2), 0, dp(2), 0) }
            setOnClickListener { onClick() }
        }
    }

    private fun showKeyPopupBubble(anchor: View, ch: String) {
        try {
            if (keyPopupWindow == null) {
                val box = FrameLayout(context).apply {
                    background = roundedBox(theme.keyPressedBg, theme.accent, 10, 2)
                }
                keyPopupText = TextView(context).apply {
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setTextColor(theme.keyText)
                }
                keyPopupMark = BanglaMarkView(context)
                box.addView(keyPopupText, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
                box.addView(keyPopupMark, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
                keyPopupWindow = PopupWindow(box, dp(48), dp(54), false).apply {
                    isTouchable = false
                }
            }
            (keyPopupWindow?.contentView as? FrameLayout)?.background = roundedBox(theme.keyPressedBg, theme.accent, 10, 2)
            if (BanglaMarkView.isMark(ch)) {
                keyPopupText?.visibility = View.GONE
                keyPopupMark?.visibility = View.VISIBLE
                keyPopupMark?.setMark(ch, theme.keyText, isSub = false)
            } else {
                keyPopupMark?.visibility = View.GONE
                keyPopupText?.visibility = View.VISIBLE
                keyPopupText?.typeface = FontHelper.forText(context, ch)
                keyPopupText?.text = ch
                keyPopupText?.setTextColor(theme.keyText)
            }
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            keyPopupWindow?.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0] + (anchor.width - dp(48)) / 2, loc[1] - dp(58))
        } catch (_: Exception) {}
    }

    private fun hideKeyPopupBubble() {
        try { keyPopupWindow?.dismiss() } catch (_: Exception) {}
    }

    private fun showAltOptionsPopup(anchor: View, options: List<AltKeyOption>) {
        try {
            hideAltPopup()
            altActiveOptions = options
            val padH = dp(6)
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(theme.keyPressedBg, theme.accent, 10, 2)
                setPadding(padH, dp(6), padH, dp(6))
            }
            val btnW = dp(40)
            val btnH = dp(44)
            val tileGap = dp(4)
            val winLoc = IntArray(2)
            anchor.getLocationInWindow(winLoc)
            val screenLoc = IntArray(2)
            anchor.getLocationOnScreen(screenLoc)
            val winToScreenDx = (screenLoc[0] - winLoc[0]).toFloat()

            val estW = options.size * (btnW + tileGap) + padH * 2
            val screenW = resources.displayMetrics.widthPixels
            val x = (winLoc[0] + anchor.width - estW).coerceIn(dp(6), (screenW - estW - dp(6)).coerceAtLeast(dp(6)))

            val defaultIdx = (((screenLoc[0] + anchor.width / 2f) - (x + winToScreenDx + padH)) / (btnW + tileGap).toFloat())
                .toInt()
                .coerceIn(0, options.lastIndex)
            altSelectedIdx = defaultIdx

            for ((idx, opt) in options.withIndex()) {
                val selected = idx == altSelectedIdx
                val card = FrameLayout(context).apply {
                    background = roundedBox(
                        if (selected) theme.accent else theme.keyBg,
                        if (selected) theme.accent else theme.keyBorder,
                        7
                    )
                    layoutParams = LayoutParams(btnW, btnH).apply { setMargins(dp(2), 0, dp(2), 0) }
                    setOnClickListener {
                        callbacks.onCommitText(opt.value)
                        refreshSuggestions()
                        hideAltPopup()
                    }
                }
                val fg = if (selected) Color.WHITE else theme.keyText
                if (BanglaMarkView.isMark(opt.label)) {
                    card.addView(BanglaMarkView(context).apply {
                        setMark(opt.label, fg, isSub = false)
                        layoutParams = FrameLayout.LayoutParams(dp(22), dp(24), Gravity.CENTER)
                    })
                } else {
                    card.addView(TextView(context).apply {
                        text = opt.label
                        textSize = 18f
                        typeface = FontHelper.forText(context, opt.label)
                        gravity = Gravity.CENTER
                        setTextColor(fg)
                        layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
                    })
                }
                altTileCards.add(card)
                row.addView(card)
            }
            val pop = PopupWindow(row, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, false).apply {
                isOutsideTouchable = true
                isFocusable = false
            }
            altPopupWindow = pop
            altTileStepPx = (btnW + tileGap).toFloat()
            altPopupScreenX = x + winToScreenDx + padH.toFloat()
            pop.showAtLocation(anchor, Gravity.NO_GRAVITY, x, winLoc[1] - btnH - dp(16))
        } catch (_: Exception) {}
    }

    private fun updateAltPopupSelection(newIdx: Int) {
        if (newIdx == altSelectedIdx || newIdx !in altTileCards.indices) return
        altSelectedIdx = newIdx
        for ((idx, card) in altTileCards.withIndex()) {
            val selected = idx == altSelectedIdx
            card.background = roundedBox(
                if (selected) theme.accent else theme.keyBg,
                if (selected) theme.accent else theme.keyBorder,
                7
            )
            val opt = altActiveOptions.getOrNull(idx) ?: continue
            val fg = if (selected) Color.WHITE else theme.keyText
            val child = card.getChildAt(0)
            if (child is BanglaMarkView) {
                child.setMark(opt.label, fg, isSub = false)
            } else if (child is TextView) {
                child.setTextColor(fg)
            }
        }
    }

    private fun hideAltPopup() {
        try { altPopupWindow?.dismiss() } catch (_: Exception) {}
        altPopupWindow = null
        altActiveOptions = emptyList()
        altTileCards.clear()
        altSelectedIdx = 0
    }

    private fun renderEmojiPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val tabScroll = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(context).apply { orientation = HORIZONTAL }

        val recentActive = emojiCatId == "recent"
        tabRow.addView(TextView(context).apply {
            text = "🕒 সাম্প্রতিক"
            textSize = 12f
            setTextColor(if (recentActive) Color.WHITE else theme.keyText)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = roundedBox(if (recentActive) theme.accent else theme.keyBg, theme.keyBorder, 8)
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
            setOnClickListener { emojiCatId = "recent"; renderBody() }
        })

        for (cat in EmojiData.CATEGORIES) {
            val active = cat.id == emojiCatId
            tabRow.addView(TextView(context).apply {
                text = cat.label
                textSize = 12f
                setTextColor(if (active) Color.WHITE else theme.keyText)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = roundedBox(if (active) theme.accent else theme.keyBg, theme.keyBorder, 8)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
                setOnClickListener { emojiCatId = cat.id; renderBody() }
            })
        }
        tabScroll.addView(tabRow)
        wrap.addView(tabScroll)

        val emojis = if (emojiCatId == "recent") {
            recentEmojis.toList()
        } else {
            EmojiData.CATEGORIES.firstOrNull { it.id == emojiCatId }?.emojis ?: emptyList()
        }
        val gridScroll = ScrollView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(268)).apply { topMargin = dp(8) }
        }
        val grid = LinearLayout(context).apply { orientation = VERTICAL }
        if (emojis.isEmpty()) {
            grid.addView(TextView(context).apply {
                text = "সাম্প্রতিক ব্যবহৃত ইমোজি এখানে জমা হবে"
                textSize = 12.5f
                gravity = Gravity.CENTER
                setTextColor(theme.subText)
                setPadding(dp(12), dp(36), dp(12), dp(36))
            })
        } else {
            val cols = 7
            for (chunk in emojis.chunked(cols)) {
                val row = LinearLayout(context).apply { orientation = HORIZONTAL }
                for (em in chunk) {
                    row.addView(TextView(context).apply {
                        text = em
                        textSize = 26f
                        gravity = Gravity.CENTER
                        background = roundedBox(theme.keyBg, Color.TRANSPARENT, 8)
                        layoutParams = LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2.5f.toInt()), dp(2), dp(2.5f.toInt()), dp(2)) }
                        setOnClickListener {
                            recordRecentEmoji(em)
                            callbacks.onCommitText(em)
                        }
                    })
                }
                repeat(cols - chunk.size) { row.addView(View(context), LayoutParams(0, dp(48), 1f)) }
                grid.addView(row)
            }
        }
        gridScroll.addView(grid)
        wrap.addView(gridScroll)

        val footer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)).apply { topMargin = dp(6) }
        }
        footer.addView(makeActionKey("কিবোর্ডে ফিরুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        footer.addView(makeActionKey("⌫ মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            callbacks.onBackspace()
        })
        wrap.addView(footer)
        bodyContainer.addView(wrap)
    }

    private fun renderCursorPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val row1 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(8) }
        }
        row1.addView(makeActionKey("Select All", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onSelectAll() })
        row1.addView(makeActionKey("Copy", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCopy() })
        row1.addView(makeActionKey("Cut", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCut() })
        row1.addView(makeActionKey("Paste", 1f, theme.accent, theme.accent, Color.WHITE, 8) { callbacks.onPasteSystem() })
        wrap.addView(row1)

        val row2 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(8) }
        }
        row2.addView(makeActionKey("|◄ শুরু", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("start") })
        row2.addView(makeActionKey("◄ বামে", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("left") })
        row2.addView(makeActionKey("ডানে ►", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("right") })
        row2.addView(makeActionKey("শেষ ►|", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("end") })
        wrap.addView(row2)

        wrap.addView(makeActionKey("কিবোর্ডে ফিরুন (ABC)", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        }.apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)) })

        bodyContainer.addView(wrap)
    }

    private fun renderClipboardPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val all = clipStore.getAll()
        val pinned = all.filter { it.pinned }
        val temp = all.filter { !it.pinned }

        // Tabs: পিন কমেন্ট (LEFT) & অস্থায়ী কমেন্ট (RIGHT)
        val tabRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38)).apply { bottomMargin = dp(8) }
        }
        tabRow.addView(makeActionKey("📌 পিন কমেন্ট (${pinned.size}/40)", 1f,
            if (clipPinnedTab) theme.accent else theme.keyBg, theme.accent,
            if (clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = true; renderBody()
        })
        tabRow.addView(makeActionKey("⏱ অস্থায়ী কমেন্ট (${temp.size})", 1f,
            if (!clipPinnedTab) theme.accent else theme.keyBg, theme.keyBorder,
            if (!clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = false; renderBody()
        })
        wrap.addView(tabRow)

        val items = if (clipPinnedTab) pinned else temp
        val scroll = ScrollView(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(170)) }
        val listCol = LinearLayout(context).apply { orientation = VERTICAL }

        if (items.isEmpty()) {
            listCol.addView(TextView(context).apply {
                text = if (clipPinnedTab) "কোনো পিন কমেন্ট নেই (সর্বোচ্চ ৪০টি স্থায়ী থাকবে)"
                else "অস্থায়ী কমেন্ট খালি (১২ ঘন্টা পর অটো-ডিলিট হবে)"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(theme.subText)
                setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        } else {
            for (item in items) {
                val card = LinearLayout(context).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    setPadding(dp(10), dp(8), dp(6), dp(8))
                    layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
                }
                val txtCol = LinearLayout(context).apply {
                    orientation = VERTICAL
                    layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener { callbacks.onCommitText(item.text) }
                }
                txtCol.addView(TextView(context).apply {
                    text = item.text
                    textSize = 13f
                    typeface = FontHelper.forText(context, item.text)
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(theme.keyText)
                })
                if (!item.pinned) {
                    txtCol.addView(TextView(context).apply {
                        text = clipStore.formatRemaining(item.createdAt)
                        textSize = 10f
                        typeface = FontHelper.banglaRegular(context)
                        setTextColor(theme.subText)
                    })
                }
                card.addView(txtCol)

                card.addView(TextView(context).apply {
                    text = if (item.pinned) "✕📌" else "📌"
                    textSize = 14f
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    setOnClickListener { clipStore.togglePin(item.id); renderBody() }
                })
                card.addView(TextView(context).apply {
                    text = "🗑"
                    textSize = 14f
                    setPadding(dp(6), dp(4), dp(6), dp(4))
                    setOnClickListener { clipStore.deleteItem(item.id); renderBody() }
                })
                listCol.addView(card)
            }
        }
        scroll.addView(listCol)
        wrap.addView(scroll)

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { topMargin = dp(6) }
        }
        bottom.addView(makeActionKey("সব মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            clipStore.clearScope(clipPinnedTab); renderBody()
        })
        bottom.addView(makeActionKey("কিবোর্ড", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        wrap.addView(bottom)
        bodyContainer.addView(wrap)
    }

    private fun renderThemesPanel() {
        val scroll = ScrollView(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(260)) }
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        for (t in KeyboardThemes.ALL) {
            val active = t.id == theme.id
            wrap.addView(TextView(context).apply {
                val txt = (if (active) "✓ " else "") + "${t.name} — ${t.nameBn}"
                text = txt
                textSize = 13.5f
                typeface = FontHelper.banglaRegular(context)
                setTextColor(t.keyText)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = roundedBox(t.boardBg, if (active) t.accent else t.keyBorder, 8, if (active) 2 else 1)
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
                setOnClickListener {
                    prefs.edit().putString("theme_id", t.id).apply()
                    theme = t
                    callbacks.onPreferencesChanged()
                    rebuildAll()
                }
            })
        }
        scroll.addView(wrap)
        bodyContainer.addView(scroll)
    }

    private fun renderSettingsPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val hRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38)).apply { bottomMargin = dp(6) }
        }
        for ((id, label) in listOf("compact" to "উচ্চতা: ছোট", "standard" to "সাধারণ", "tall" to "বড়")) {
            val active = keyHeightMode == id
            hRow.addView(makeActionKey(label, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 8) {
                keyHeightMode = id
                prefs.edit().putString("key_height", id).apply()
                callbacks.onPreferencesChanged()
                rebuildAll()
            }.apply { textSize = 12.5f })
        }
        wrap.addView(hRow)

        val sndLabel = TextView(context).apply {
            text = "টাইপিং সাউন্ড (ল্যাপটপ / পিসি / মেকানিক্যাল):"
            textSize = 11f
            typeface = FontHelper.banglaRegular(context)
            setTextColor(theme.subText)
            setPadding(dp(2), 0, 0, dp(4))
        }
        wrap.addView(sndLabel)

        val sndRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(6) }
        }
        val currentSnd = if (!prefs.getBoolean("sound_on", true)) "off" else soundProfile
        for ((id, label) in listOf(
            "laptop" to "ল্যাপটপ",
            "pc" to "পিসি",
            "mechanical" to "মেকা",
            "soft" to "সফট",
            "off" to "বন্ধ"
        )) {
            val active = currentSnd == id
            sndRow.addView(makeActionKey(label, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 7) {
                soundProfile = id
                prefs.edit()
                    .putString("sound_profile", id)
                    .putBoolean("sound_on", id != "off")
                    .apply()
                callbacks.onPreferencesChanged()
                if (id != "off") callbacks.onSoundPreview()
                renderBody()
            }.apply { textSize = 11.5f })
        }
        wrap.addView(sndRow)

        val tRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38)).apply { bottomMargin = dp(6) }
        }
        tRow.addView(makeActionKey("বানান ডিকেক্টর: ${if (spellCheckEnabled) "চালু" else "বন্ধ"}", 1f,
            if (spellCheckEnabled) theme.accent else theme.keyBg, theme.keyBorder, if (spellCheckEnabled) Color.WHITE else theme.keyText, 8) {
            spellCheckEnabled = !spellCheckEnabled
            prefs.edit().putBoolean("spell_check", spellCheckEnabled).apply()
            rebuildAll()
        }.apply { textSize = 12f })
        tRow.addView(makeActionKey("পপ-আপ: ${if (showPopup) "চালু" else "বন্ধ"}", 1f,
            if (showPopup) theme.accent else theme.keyBg, theme.keyBorder, if (showPopup) Color.WHITE else theme.keyText, 8) {
            showPopup = !showPopup
            prefs.edit().putBoolean("show_popup", showPopup).apply()
            renderBody()
        }.apply { textSize = 12f })
        wrap.addView(tRow)

        val bRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38))
        }
        bRow.addView(makeActionKey("নাম্বার সারি: ${if (showNumberRow) "চালু" else "বন্ধ"}", 1f,
            if (showNumberRow) theme.accent else theme.keyBg, theme.keyBorder, if (showNumberRow) Color.WHITE else theme.keyText, 8) {
            showNumberRow = !showNumberRow
            prefs.edit().putBoolean("show_num_row", showNumberRow).apply()
            rebuildAll()
        }.apply { textSize = 12f })
        bRow.addView(makeActionKey("সম্পন্ন", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        }.apply { textSize = 13f })
        wrap.addView(bRow)

        bodyContainer.addView(wrap)
    }
}
