# Ridmik Studio — Android System Keyboard (বাংলা প্রভাত ও English)

এই প্রজেক্টটি **Android-এর আসল সিস্টেম কিবোর্ড (InputMethodService)** হিসেবে তৈরি করা হয়েছে, যাতে **Facebook, Messenger, WhatsApp, Chrome** সহ ফোনের যেকোনো অ্যাপে সরাসরি টাইপ করতে পারবেন।

## GitHub থেকে ১ ক্লিকে APK বানানোর নিয়ম:
1. এই ZIP ফাইলটি Extract/Unzip করুন।
2. [github.com](https://github.com) এ গিয়ে একটি নতুন Repository তৈরি করুন (যেমন: `ridmik-studio-keyboard`)।
3. **Add file -> Upload files** এ গিয়ে Unzip করা ফোল্ডারের সব ফাইল ও `.github` ফোল্ডার আপলোড করে **Commit changes** দিন।
4. এবার রিপোজিটরির **Actions** ট্যাবে যান -> **Build Ridmik Studio Android APK** ওয়ার্কফ্লো অটোমেটিক চলবে (~২ মিনিট লাগবে)।
5. বিল্ড সবুজ (✓) হলে সেখানে ক্লিক করে নিচে **Artifacts -> Ridmik-Studio-Keyboard-APK** থেকে `.apk` ফাইল ডাউনলোড করে ফোনে ইনস্টল করুন।

## ফোনে সেটআপ করার নিয়ম:
1. অ্যাপটি ওপেন করুন।
2. **১. কিবোর্ড চালু করুন (Enable Keyboard)** বাটনে চাপ দিয়ে **Ridmik Studio Keyboard** অন করুন।
3. **২. কিবোর্ড সিলেক্ট করুন (Switch Keyboard)** বাটনে চাপ দিয়ে **Ridmik Studio Keyboard** বেছে নিন।
4. ব্যস! এখন Facebook, Messenger, WhatsApp সব অ্যাপে বাংলা (প্রভাত) ও English টাইপ করতে পারবেন।
