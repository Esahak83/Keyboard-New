package com.ridmikstudio.keyboard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#080A0F")) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(20)
            setPadding(p, dp(28), p, dp(28))
        }

        root.addView(TextView(this).apply {
            text = "Ridmik Studio Keyboard"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })

        root.addView(TextView(this).apply {
            text = "প্রভাত বাংলা ও English কিবোর্ড — Facebook, Messenger, WhatsApp সব অ্যাপে ব্যবহারের জন্য নিচের ২টি ধাপ সম্পন্ন করুন:"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(8), 0, dp(18))
        })

        root.addView(makePrimaryBtn("১. কিবোর্ড চালু করুন (Enable Keyboard)") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })

        root.addView(makePrimaryBtn("২. Ridmik Studio সিলেক্ট করুন (Switch Keyboard)", "#1F2937", "#EF4444") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        root.addView(TextView(this).apply {
            text = "এখানে টাইপ করে পরীক্ষা করুন:"
            textSize = 13f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, dp(16), 0, dp(6))
        })

        root.addView(EditText(this).apply {
            hint = "এখানে ট্যাপ করে বাংলা বা ইংরেজি লিখুন..."
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            minLines = 3
            gravity = Gravity.TOP
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#11151E"))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
        })

        // Sound & Vibration switches
        root.addView(makeSwitch("কী-প্রেস সাউন্ড", prefs.getBoolean("sound_on", true)) { on ->
            prefs.edit().putBoolean("sound_on", on).apply()
        })
        root.addView(makeSwitch("ভাইব্রেশন ফিডব্যাক", prefs.getBoolean("vibrate_on", true)) { on ->
            prefs.edit().putBoolean("vibrate_on", on).apply()
        })
        root.addView(makeSwitch("বানান ও টাইপিং ভুল ডিকেক্টর", prefs.getBoolean("spell_check", true)) { on ->
            prefs.edit().putBoolean("spell_check", on).apply()
        })

        // Optional Gemini API key input for cloud AI spell check
        root.addView(TextView(this).apply {
            text = "ঐচ্ছিক: Gemini AI স্পেল-চেক (অফলাইনেও লোকাল ডিকেক্টর সবসময় কাজ করবে)"
            textSize = 12f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(16), 0, dp(6))
        })

        val keyInput = EditText(this).apply {
            hint = "Gemini API Key (ঐচ্ছিক)"
            setText(prefs.getString("gemini_api_key", ""))
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#11151E"))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
        }
        root.addView(keyInput)

        root.addView(makePrimaryBtn("সেটিংস সংরক্ষণ করুন", "#16A34A", "#16A34A") {
            prefs.edit().putString("gemini_api_key", keyInput.text.toString().trim()).apply()
        })

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun makePrimaryBtn(label: String, bgHex: String = "#EF4444", borderHex: String = "#EF4444", onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor(borderHex))
            }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)).apply {
                bottomMargin = dp(10)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeSwitch(label: String, checked: Boolean, onChanged: (Boolean) -> Unit): Switch {
        return Switch(this).apply {
            text = label
            isChecked = checked
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(12))
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
    }
}
