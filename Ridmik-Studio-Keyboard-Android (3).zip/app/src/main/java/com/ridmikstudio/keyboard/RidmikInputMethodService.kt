package com.ridmikstudio.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class RidmikInputMethodService : InputMethodService(), RidmikKeyboardView.Callbacks {

    private var keyboardView: RidmikKeyboardView? = null
    private lateinit var clipStore: ClipboardStore
    private var clipboardManager: ClipboardManager? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val txt = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!txt.isNullOrBlank()) {
            clipStore.addClip(txt)
        }
    }

    override fun onCreate() {
        super.onCreate()
        clipStore = ClipboardStore(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboardManager?.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = RidmikKeyboardView(this, this)
        keyboardView = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        keyboardView?.reloadFromPrefs()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        keyboardView?.refreshSuggestions()
    }

    private fun feedback() {
        val prefs = getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("vibrate_on", true)) {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(14L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(14L)
                }
            }
        }
        if (prefs.getBoolean("sound_on", true)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.45f)
        }
    }

    override fun onCommitText(text: String) {
        feedback()
        currentInputConnection?.commitText(text, 1)
    }

    override fun onBackspace() {
        feedback()
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(4, 0) ?: ""
        if (before.isEmpty()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
            return
        }
        val lastCodePoint = Character.codePointBefore(before, before.length)
        val charCount = Character.charCount(lastCodePoint)
        ic.deleteSurroundingText(charCount, 0)
    }

    override fun onDeleteWord() {
        feedback()
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: return
        if (before.isEmpty()) return
        val trimmed = before.trimEnd()
        val cut = if (trimmed.isEmpty()) before.length
        else {
            val lastSpace = trimmed.lastIndexOfAny(charArrayOf(' ', '\n'))
            if (lastSpace == -1) before.length else before.length - (lastSpace + 1)
        }
        ic.deleteSurroundingText(cut, 0)
    }

    override fun onEnter() {
        feedback()
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_GO) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    override fun onMoveCursor(action: String) {
        val ic = currentInputConnection ?: return
        when (action) {
            "left" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_LEFT))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_LEFT))
            }
            "right" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT))
            }
            "start" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MOVE_HOME))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MOVE_HOME))
            }
            "end" -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MOVE_END))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MOVE_END))
            }
        }
    }

    override fun onSelectAll() {
        currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
    }

    override fun onCopy() {
        currentInputConnection?.performContextMenuAction(android.R.id.copy)
    }

    override fun onCut() {
        currentInputConnection?.performContextMenuAction(android.R.id.cut)
    }

    override fun onPasteSystem() {
        val txt = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!txt.isNullOrEmpty()) {
            currentInputConnection?.commitText(txt, 1)
        }
    }

    override fun onVoiceInput() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onApplySuggestion(candidate: SpellCandidate) {
        feedback()
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(80, 0)?.toString() ?: ""
        if (candidate.replaceLastWord) {
            val match = Regex("([^\\s.,!?;:।]+)(\\s+)$").find(before)
            if (match != null) {
                ic.deleteSurroundingText(match.value.length, 0)
            }
        } else if (before.isNotEmpty() && !before.last().isWhitespace()) {
            val token = before.substringAfterLast(' ').substringAfterLast('\n')
            if (token.isNotEmpty()) {
                ic.deleteSurroundingText(token.length, 0)
            }
        }
        ic.commitText(candidate.word + " ", 1)
    }

    override fun getTextBeforeCursor(): String {
        return currentInputConnection?.getTextBeforeCursor(160, 0)?.toString() ?: ""
    }

    override fun onPreferencesChanged() {
        // persisted in SharedPreferences
    }
}
