package com.ridmikstudio.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class BanglaMarkView(context: Context) : View(context) {
    private var markChar: String = ""
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val path = Path()

    companion object {
        private val MARKS = setOf(
            "া", "ি", "ী", "ু", "ূ", "ে", "ৈ", "ো", "ৌ", "ঃ", "ং", "্", "ৃ", "ঁ"
        )
        fun isMark(ch: String): Boolean = MARKS.contains(ch)
    }

    fun setMark(ch: String, color: Int, strokeScale: Float = 2.1f) {
        markChar = ch
        strokePaint.color = color
        fillPaint.color = color
        strokePaint.strokeWidth = strokeScale * resources.displayMetrics.density * 0.9f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (markChar.isEmpty() || width == 0 || height == 0) return

        val size = minOf(width, height).toFloat()
        val ox = (width - size) / 2f
        val oy = (height - size) / 2f
        val s = size / 24f

        fun sx(x: Float) = ox + x * s
        fun sy(y: Float) = oy + y * s

        strokePaint.strokeWidth = maxOf(2.2f, 2.1f * s)
        path.reset()

        when (markChar) {
            "া" -> {
                path.moveTo(sx(8f), sy(6.5f)); path.lineTo(sx(15.5f), sy(6.5f))
                path.moveTo(sx(12.5f), sy(6.5f)); path.lineTo(sx(12.5f), sy(19.5f))
                canvas.drawPath(path, strokePaint)
            }
            "ি" -> {
                path.moveTo(sx(7.5f), sy(8.5f)); path.lineTo(sx(12f), sy(8.5f))
                path.moveTo(sx(10f), sy(8.5f)); path.lineTo(sx(10f), sy(20f))
                path.moveTo(sx(10f), sy(8.5f))
                path.cubicTo(sx(10.5f), sy(3.5f), sx(17f), sy(3.5f), sx(18f), sy(9f))
                canvas.drawPath(path, strokePaint)
            }
            "ী" -> {
                path.moveTo(sx(8f), sy(8.5f)); path.lineTo(sx(15.5f), sy(8.5f))
                path.moveTo(sx(11.5f), sy(8.5f)); path.lineTo(sx(11.5f), sy(20f))
                path.moveTo(sx(11.5f), sy(8.5f))
                path.cubicTo(sx(11.5f), sy(4f), sx(16.5f), sy(3f), sx(17.8f), sy(5.8f))
                path.cubicTo(sx(18.7f), sy(7.6f), sx(17f), sy(9.8f), sx(15.3f), sy(9f))
                canvas.drawPath(path, strokePaint)
            }
            "ু" -> {
                path.moveTo(sx(11f), sy(12.5f))
                path.cubicTo(sx(9.2f), sy(12.5f), sx(8.5f), sy(15f), sx(10.5f), sy(16.3f))
                path.cubicTo(sx(12f), sy(17.3f), sx(13.8f), sy(16.1f), sx(13f), sy(14.5f))
                path.cubicTo(sx(12.4f), sy(13.3f), sx(10.8f), sy(13.7f), sx(11.5f), sy(15.6f))
                path.cubicTo(sx(12.3f), sy(17.6f), sx(14.3f), sy(18.8f), sx(16.5f), sy(18.5f))
                canvas.drawPath(path, strokePaint)
            }
            "ূ" -> {
                path.moveTo(sx(8.5f), sy(14f))
                path.cubicTo(sx(8.5f), sy(17f), sx(11f), sy(18.2f), sx(12.7f), sy(16.4f))
                path.cubicTo(sx(13.8f), sy(15.2f), sx(12.5f), sy(13.6f), sx(11.3f), sy(14.8f))
                path.cubicTo(sx(10.3f), sy(15.8f), sx(12.7f), sy(18.6f), sx(16.1f), sy(18f))
                path.cubicTo(sx(17.5f), sy(17.8f), sx(18.3f), sy(17f), sx(18.7f), sy(16f))
                canvas.drawPath(path, strokePaint)
            }
            "ে" -> {
                canvas.drawCircle(sx(12f), sy(8.5f), 1.8f * s, strokePaint)
                path.moveTo(sx(11.5f), sy(6.8f))
                path.cubicTo(sx(9.4f), sy(8.4f), sx(8f), sy(12.5f), sx(9f), sy(16f))
                path.cubicTo(sx(9.7f), sy(18.2f), sx(11.8f), sy(18.8f), sx(14.2f), sy(18f))
                canvas.drawPath(path, strokePaint)
            }
            "ৈ" -> {
                canvas.drawCircle(sx(12f), sy(10.5f), 1.6f * s, strokePaint)
                path.moveTo(sx(11.7f), sy(9f))
                path.cubicTo(sx(9.7f), sy(10.5f), sx(8.5f), sy(14f), sx(9.4f), sy(17f))
                path.cubicTo(sx(10.1f), sy(19f), sx(12.1f), sy(19.6f), sx(14.3f), sy(18.8f))
                path.moveTo(sx(11.8f), sy(9f))
                path.cubicTo(sx(11.8f), sy(5.5f), sx(14.8f), sy(3.8f), sx(17.2f), sy(5.7f))
                canvas.drawPath(path, strokePaint)
            }
            "ো" -> {
                canvas.drawCircle(sx(8.5f), sy(8.8f), 1.5f * s, strokePaint)
                path.moveTo(sx(8.2f), sy(7.4f))
                path.cubicTo(sx(6.5f), sy(8.8f), sx(5.6f), sy(12.5f), sx(6.3f), sy(15.8f))
                path.cubicTo(sx(6.9f), sy(17.8f), sx(8.6f), sy(18.4f), sx(10.5f), sy(17.7f))
                path.moveTo(sx(12.5f), sy(6.5f)); path.lineTo(sx(18.5f), sy(6.5f))
                path.moveTo(sx(16f), sy(6.5f)); path.lineTo(sx(16f), sy(19.3f))
                canvas.drawPath(path, strokePaint)
            }
            "ৌ" -> {
                canvas.drawCircle(sx(8.3f), sy(10.2f), 1.4f * s, strokePaint)
                path.moveTo(sx(8f), sy(8.9f))
                path.cubicTo(sx(6.5f), sy(10.2f), sx(5.6f), sy(13.5f), sx(6.3f), sy(16.4f))
                path.cubicTo(sx(6.8f), sy(18.2f), sx(8.3f), sy(18.8f), sx(10.1f), sy(18.1f))
                path.moveTo(sx(12.5f), sy(8.5f)); path.lineTo(sx(18.5f), sy(8.5f))
                path.moveTo(sx(16f), sy(8.5f)); path.lineTo(sx(16f), sy(19.3f))
                path.moveTo(sx(16f), sy(8.5f))
                path.cubicTo(sx(16f), sy(5.1f), sx(18.3f), sy(3.9f), sx(19.5f), sy(5.9f))
                canvas.drawPath(path, strokePaint)
            }
            "ঃ" -> {
                canvas.drawCircle(sx(12f), sy(8.2f), 2.3f * s, strokePaint)
                canvas.drawCircle(sx(12f), sy(15.8f), 2.3f * s, strokePaint)
            }
            "ং" -> {
                canvas.drawCircle(sx(10f), sy(8.2f), 2.3f * s, strokePaint)
                path.moveTo(sx(10.2f), sy(11.8f))
                path.cubicTo(sx(10.6f), sy(15.6f), sx(13.4f), sy(18f), sx(17.5f), sy(18f))
                canvas.drawPath(path, strokePaint)
            }
            "্" -> {
                path.moveTo(sx(8.5f), sy(13.5f)); path.lineTo(sx(15.5f), sy(18.5f))
                canvas.drawPath(path, strokePaint)
            }
            "ৃ" -> {
                path.moveTo(sx(14.5f), sy(12.5f))
                path.cubicTo(sx(11.5f), sy(12.5f), sx(9.5f), sy(14.5f), sx(10f), sy(16.7f))
                path.cubicTo(sx(10.5f), sy(18.7f), sx(13f), sy(19.1f), sx(15.5f), sy(17.3f))
                canvas.drawPath(path, strokePaint)
            }
            "ঁ" -> {
                path.moveTo(sx(7f), sy(11f))
                path.cubicTo(sx(8.8f), sy(14.5f), sx(15.2f), sy(14.5f), sx(17f), sy(11f))
                canvas.drawPath(path, strokePaint)
                canvas.drawCircle(sx(12f), sy(7.5f), 1.5f * s, fillPaint)
            }
        }
    }
}
