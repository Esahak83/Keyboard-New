package com.ridmikstudio.keyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipEntry(
    val id: String,
    val text: String,
    val pinned: Boolean,
    val createdAt: Long
)

class ClipboardStore(context: Context) {
    private val prefs = context.getSharedPreferences("ridmik_clipboard_v1", Context.MODE_PRIVATE)

    companion object {
        const val MAX_PINNED = 40
        const val MAX_TEMP = 40
        const val EXPIRY_MS = 12L * 60L * 60L * 1000L
        private const val KEY_ITEMS = "items_json"
    }

    fun getAll(): List<ClipEntry> {
        val raw = prefs.getString(KEY_ITEMS, null)
        val list = if (raw == null) {
            listOf(
                ClipEntry("c1", "আসসালামু আলাইকুম, কেমন আছেন?", true, System.currentTimeMillis() - 60_000L),
                ClipEntry("c2", "বাংলাদেশ আমার প্রিয় জন্মভূমি 🇧🇩", false, System.currentTimeMillis() - 120_000L)
            )
        } else {
            parse(raw)
        }
        val pruned = prune(list)
        if (pruned.size != list.size || raw == null) save(pruned)
        return pruned
    }

    fun addClip(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        val current = getAll()
        if (current.any { it.pinned && it.text == clean }) return
        val filtered = current.filterNot { it.text == clean }
        val next = listOf(ClipEntry("clip_$now", clean, false, now)) + filtered
        save(prune(next))
    }

    fun togglePin(id: String): String {
        val current = getAll()
        val target = current.firstOrNull { it.id == id } ?: return ""
        if (!target.pinned) {
            if (current.count { it.pinned } >= MAX_PINNED) {
                return "পিন কমেন্টের সর্বোচ্চ ৪০টি জায়গা পূর্ণ হয়েছে"
            }
            save(prune(current.map { if (it.id == id) it.copy(pinned = true) else it }))
            return "পিন কমেন্টে সেভ হয়েছে"
        } else {
            save(prune(current.map {
                if (it.id == id) it.copy(pinned = false, createdAt = System.currentTimeMillis()) else it
            }))
            return "অস্থায়ী কমেন্টে সরানো হয়েছে (১২ ঘন্টা)"
        }
    }

    fun deleteItem(id: String) {
        save(getAll().filterNot { it.id == id })
    }

    fun clearScope(pinned: Boolean) {
        val next = if (pinned) getAll().filterNot { it.pinned } else getAll().filter { it.pinned }
        save(next)
    }

    fun formatRemaining(createdAt: Long): String {
        val leftMs = maxOf(0L, EXPIRY_MS - (System.currentTimeMillis() - createdAt))
        val mins = ((leftMs + 59_999L) / 60_000L).toInt()
        val hrs = mins / 60
        val remMins = mins % 60
        return if (hrs > 0) "${hrs}ঘ ${remMins}মি বাকি" else "${remMins}মি বাকি"
    }

    private fun prune(items: List<ClipEntry>): List<ClipEntry> {
        val now = System.currentTimeMillis()
        val pinned = items.filter { it.pinned }.take(MAX_PINNED)
        val temp = items.filter { !it.pinned && (now - it.createdAt) < EXPIRY_MS }.take(MAX_TEMP)
        return pinned + temp
    }

    private fun parse(raw: String): List<ClipEntry> {
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<ClipEntry>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                out.add(
                    ClipEntry(
                        id = obj.optString("id"),
                        text = obj.optString("text"),
                        pinned = obj.optBoolean("pinned", false),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(items: List<ClipEntry>) {
        val arr = JSONArray()
        for (it in items) {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("text", it.text)
                put("pinned", it.pinned)
                put("createdAt", it.createdAt)
            })
        }
        prefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }
}
