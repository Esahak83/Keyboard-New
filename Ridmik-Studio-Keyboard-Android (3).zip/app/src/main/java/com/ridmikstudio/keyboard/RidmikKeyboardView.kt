package com.ridmikstudio.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

class RidmikKeyboardView(
    context: Context,
    private val callbacks: Callbacks
) : LinearLayout(context) {

    interface Callbacks {
        fun onCommitText(text: String)
        fun onBackspace()
        fun onDeleteWord()
        fun onEnter()
        fun onMoveCursor(action: String)
        fun onSelectAll()
        fun onCopy()
        fun onCut()
        fun onPasteSystem()
        fun onVoiceInput()
        fun onApplySuggestion(candidate: SpellCandidate)
        fun getTextBeforeCursor(): String
        fun onPreferencesChanged()
    }

    enum class Panel { KEYS, EMOJI, CURSOR, CLIPBOARD, THEMES, SETTINGS }

    private val prefs = context.getSharedPreferences("ridmik_prefs", Context.MODE_PRIVATE)
    private val clipStore = ClipboardStore(context)
    private val mainHandler = Handler(Looper.getMainLooper())

    var language: KeyboardLanguage = KeyboardLanguage.ENGLISH
        private set
    private var layer: KeyLayer = KeyLayer.ALPHA
    private var shift: Boolean = false
    private var capsLock: Boolean = false
    private var lastShiftTap: Long = 0L
    private var activePanel: Panel = Panel.KEYS
    private var emojiCatId: String = EmojiData.CATEGORIES.first().id
    private var clipPinnedTab: Boolean = true

    private var theme: KeyboardTheme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
    private var keyHeightMode: String = prefs.getString("key_height", "standard") ?: "standard"
    private var showNumberRow: Boolean = prefs.getBoolean("show_num_row", false)
    private var showPopup: Boolean = prefs.getBoolean("show_popup", true)
    private var spellCheckEnabled: Boolean = prefs.getBoolean("spell_check", true)

    private var currentSuggestions: List<SpellCandidate> = emptyList()
    private var aiSuggestions: List<SpellCandidate> = emptyList()
    private var aiDebounceRunnable: Runnable? = null

    private val toolbarContainer = LinearLayout(context)
    private val suggestionStripScroll = HorizontalScrollView(context)
    private val suggestionStrip = LinearLayout(context)
    private val bodyContainer = FrameLayout(context)

    private var keyPopupWindow: PopupWindow? = null
    private var keyPopupText: TextView? = null
    private var keyPopupMark: BanglaMarkView? = null

    private var bsHoldRunnable: Runnable? = null
    private var bsRepeatRunnable: Runnable? = null
    private var bsDidRepeat = false
    private var bsDidSwipe = false
    private var bsStartX = 0f

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        rebuildAll()
    }

    fun reloadFromPrefs() {
        theme = KeyboardThemes.byId(prefs.getString("theme_id", "red-tech-hex"))
        keyHeightMode = prefs.getString("key_height", "standard") ?: "standard"
        showNumberRow = prefs.getBoolean("show_num_row", false)
        showPopup = prefs.getBoolean("show_popup", true)
        spellCheckEnabled = prefs.getBoolean("spell_check", true)
        rebuildAll()
    }

    fun refreshSuggestions() {
        if (!spellCheckEnabled || activePanel != Panel.KEYS) {
            suggestionStripScroll.visibility = if (activePanel == Panel.KEYS && spellCheckEnabled) View.VISIBLE else View.GONE
            return
        }
        suggestionStripScroll.visibility = View.VISIBLE
        val before = callbacks.getTextBeforeCursor()
        val local = SpellDetector.suggestLocal(before, language)
        currentSuggestions = if (aiSuggestions.isNotEmpty()) {
            (aiSuggestions + local).distinctBy { it.word }.take(5)
        } else local
        renderSuggestions()
        scheduleAiCheck(before)
    }

    private fun scheduleAiCheck(before: String) {
        aiDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        val apiKey = prefs.getString("gemini_api_key", "") ?: ""
        if (apiKey.isBlank()) return

        val trimmedEnd = before.trimEnd()
        val word = if (before.endsWith(" ")) trimmedEnd.split(Regex("\\s+")).lastOrNull().orEmpty()
        else before.substringAfterLast(' ').substringAfterLast('\n')
        if (word.length < 3 || SpellDetector.isKnownWord(word, language)) {
            aiSuggestions = emptyList()
            return
        }
        val r = Runnable {
            Thread {
                val res = SpellDetector.fetchAiCorrection(apiKey, word, before.dropLast(word.length), language)
                if (res.isNotEmpty()) {
                    val isLast = before.endsWith(" ")
                    aiSuggestions = res.map { SpellCandidate(it, isCorrection = true, isAi = true, replaceLastWord = isLast) }
                    mainHandler.post {
                        val local = SpellDetector.suggestLocal(callbacks.getTextBeforeCursor(), language)
                        currentSuggestions = (aiSuggestions + local).distinctBy { it.word }.take(5)
                        renderSuggestions()
                    }
                }
            }.start()
        }
        aiDebounceRunnable = r
        mainHandler.postDelayed(r, 900L)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBox(bg: Int, border: Int, radiusDp: Int = 8, strokeDp: Int = 1): GradientDrawable {
        return GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(strokeDp), border)
        }
    }

    fun rebuildAll() {
        setBackgroundColor(theme.boardBg)
        removeAllViews()
        buildToolbar()
        buildSuggestionStrip()
        addView(toolbarContainer)
        addView(suggestionStripScroll)
        addView(bodyContainer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        renderBody()
        refreshSuggestions()
    }

    private fun buildToolbar() {
        toolbarContainer.removeAllViews()
        toolbarContainer.orientation = HORIZONTAL
        toolbarContainer.gravity = Gravity.CENTER_VERTICAL
        toolbarContainer.setBackgroundColor(theme.toolbarBg)
        toolbarContainer.setPadding(dp(8), dp(6), dp(8), dp(6))
        toolbarContainer.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)

        // 1. ব / En
        toolbarContainer.addView(makeToolBtn(if (language == KeyboardLanguage.ENGLISH) "ব" else "En", language == KeyboardLanguage.PROVAT) {
            language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
            layer = KeyLayer.ALPHA
            shift = false
            capsLock = false
            activePanel = Panel.KEYS
            aiSuggestions = emptyList()
            rebuildAll()
        })

        // 2. Emoji
        toolbarContainer.addView(makeToolBtn("☺", activePanel == Panel.EMOJI) {
            activePanel = if (activePanel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI
            rebuildAll()
        })

        // 3. Cursor ◄|►
        toolbarContainer.addView(makeToolBtn("◄|►", activePanel == Panel.CURSOR) {
            activePanel = if (activePanel == Panel.CURSOR) Panel.KEYS else Panel.CURSOR
            rebuildAll()
        })

        // 4. Clipboard (Moved into 1234 spot)
        toolbarContainer.addView(makeToolBtn("📋", activePanel == Panel.CLIPBOARD) {
            activePanel = if (activePanel == Panel.CLIPBOARD) Panel.KEYS else Panel.CLIPBOARD
            rebuildAll()
        })

        // 5. Theme (Moved into Clipboard spot)
        toolbarContainer.addView(makeToolBtn("🎨", activePanel == Panel.THEMES) {
            activePanel = if (activePanel == Panel.THEMES) Panel.KEYS else Panel.THEMES
            rebuildAll()
        })

        // 6. Settings Gear (Moved into Theme spot)
        toolbarContainer.addView(makeToolBtn("⚙", activePanel == Panel.SETTINGS) {
            activePanel = if (activePanel == Panel.SETTINGS) Panel.KEYS else Panel.SETTINGS
            rebuildAll()
        })

        // 7. Voice Mic
        toolbarContainer.addView(makeToolBtn("🎤", false) {
            callbacks.onVoiceInput()
        })
    }

    private fun makeToolBtn(label: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(theme.accentText)
            background = roundedBox(
                if (active) Color.argb(45, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent)) else Color.TRANSPARENT,
                if (active) theme.accent else Color.TRANSPARENT,
                8
            )
            layoutParams = LayoutParams(0, dp(36), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildSuggestionStrip() {
        suggestionStripScroll.isHorizontalScrollBarEnabled = false
        suggestionStripScroll.setBackgroundColor(theme.suggestionBg)
        suggestionStripScroll.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40))
        suggestionStrip.orientation = HORIZONTAL
        suggestionStrip.gravity = Gravity.CENTER_VERTICAL
        suggestionStrip.setPadding(dp(8), dp(4), dp(8), dp(4))
        suggestionStripScroll.removeAllViews()
        suggestionStripScroll.addView(suggestionStrip)
    }

    private fun renderSuggestions() {
        suggestionStrip.removeAllViews()
        if (!spellCheckEnabled) return

        val hasCorr = currentSuggestions.any { it.isCorrection }
        val tag = TextView(context).apply {
            text = if (hasCorr) "শুদ্ধ:" else "শব্দ:"
            textSize = 11f
            setTextColor(if (hasCorr) theme.accentText else theme.subText)
            setPadding(dp(2), 0, dp(8), 0)
        }
        suggestionStrip.addView(tag)

        for ((idx, cand) in currentSuggestions.withIndex()) {
            val chip = TextView(context).apply {
                text = if (cand.isAi) "✦ ${cand.word}" else if (cand.isCorrection) "✓ ${cand.word}" else cand.word
                textSize = 13.5f
                typeface = if (cand.isCorrection || idx == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(if (cand.isCorrection && idx == 0) Color.WHITE else theme.keyText)
                setPadding(dp(12), dp(5), dp(12), dp(5))
                background = roundedBox(
                    when {
                        cand.isCorrection && idx == 0 -> theme.accent
                        cand.isCorrection -> Color.argb(50, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        idx == 0 -> theme.keyBg
                        else -> Color.TRANSPARENT
                    },
                    if (cand.isCorrection || idx == 0) theme.accent else Color.TRANSPARENT,
                    7
                )
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, 0, dp(6), 0)
                }
                setOnClickListener {
                    aiSuggestions = emptyList()
                    callbacks.onApplySuggestion(cand)
                    refreshSuggestions()
                }
            }
            suggestionStrip.addView(chip)
        }
    }

    private fun renderBody() {
        bodyContainer.removeAllViews()
        when (activePanel) {
            Panel.KEYS -> renderKeysPanel()
            Panel.EMOJI -> renderEmojiPanel()
            Panel.CURSOR -> renderCursorPanel()
            Panel.CLIPBOARD -> renderClipboardPanel()
            Panel.THEMES -> renderThemesPanel()
            Panel.SETTINGS -> renderSettingsPanel()
        }
    }

    private fun keyHeightDp(): Int = when (keyHeightMode) {
        "compact" -> 46
        "tall" -> 60
        else -> 54
    }

    private fun renderKeysPanel() {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val keyH = dp(keyHeightDp())

        if (showNumberRow && layer == KeyLayer.ALPHA) {
            val numRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { bottomMargin = dp(5) }
            }
            val nums = if (language == KeyboardLanguage.ENGLISH) KeyboardLayouts.NUMBER_ROW_EN else KeyboardLayouts.NUMBER_ROW_BN
            for (k in nums) numRow.addView(createKeyView(k, dp(36)))
            root.addView(numRow)
        }

        val rows = when (layer) {
            KeyLayer.SYMBOLS1 -> KeyboardLayouts.SYMBOL_ROWS_1
            KeyLayer.SYMBOLS2 -> KeyboardLayouts.SYMBOL_ROWS_2
            KeyLayer.ALPHA -> if (language == KeyboardLanguage.PROVAT) KeyboardLayouts.PROVAT_ROWS else KeyboardLayouts.QWERTY_ROWS
        }

        for ((rIdx, row) in rows.withIndex()) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH).apply { bottomMargin = dp(5) }
                if (rIdx == 1 && row.size == 9) setPadding(dp(12), 0, dp(12), 0)
            }
            for (k in row) rowLayout.addView(createKeyView(k, keyH))
            root.addView(rowLayout)
        }

        // Bottom Row
        val bottomRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, keyH)
        }

        bottomRow.addView(makeActionKey(if (layer == KeyLayer.ALPHA) "?123" else "ABC", 1.25f, theme.fnKeyBg, theme.fnKeyBorder, theme.accentText, 24) {
            layer = if (layer == KeyLayer.ALPHA) KeyLayer.SYMBOLS1 else KeyLayer.ALPHA
            rebuildAll()
        })
        bottomRow.addView(makeActionKey(",", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, 8) {
            callbacks.onCommitText(",")
            refreshSuggestions()
        })
        bottomRow.addView(makeActionKey("☺", 0.95f, theme.fnKeyBg, theme.fnKeyBorder, theme.accentText, 8) {
            activePanel = Panel.EMOJI
            rebuildAll()
        })
        bottomRow.addView(createSpacebar(keyH))
        bottomRow.addView(makeActionKey(if (language == KeyboardLanguage.ENGLISH) "." else "।", 0.85f, theme.keyBg, theme.keyBorder, theme.keyText, 8) {
            callbacks.onCommitText(if (language == KeyboardLanguage.ENGLISH) "." else "।")
            refreshSuggestions()
        })
        bottomRow.addView(makeActionKey("↵", 1.4f, theme.enterBg, theme.enterBg, Color.WHITE, 12) {
            aiSuggestions = emptyList()
            callbacks.onEnter()
            refreshSuggestions()
        })

        root.addView(bottomRow)
        bodyContainer.addView(root)
    }

    private fun createKeyView(k: KeyDef, keyH: Int): View {
        val isFn = k.kind != KeyKind.CHAR
        val bg = when {
            k.kind == KeyKind.SHIFT && (shift || capsLock) -> theme.accent
            isFn -> theme.fnKeyBg
            else -> theme.keyBg
        }
        val border = when {
            k.kind == KeyKind.SHIFT && (shift || capsLock) -> theme.accent
            isFn -> theme.fnKeyBorder
            else -> theme.keyBorder
        }

        val frame = FrameLayout(context).apply {
            background = roundedBox(bg, border, 8)
            layoutParams = LayoutParams(0, keyH, k.flex).apply {
                val gap = if (language == KeyboardLanguage.PROVAT && layer == KeyLayer.ALPHA) dp(1) else dp(2)
                setMargins(gap, 0, gap, 0)
            }
        }

        val displayChar = when {
            k.kind == KeyKind.SHIFT -> if (capsLock) "⇪" else "⇧"
            k.kind == KeyKind.BACKSPACE -> "⌫"
            shift && k.shiftLabel != null -> k.shiftLabel
            language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA ->
                if (shift) k.label.uppercase() else k.label.lowercase()
            else -> k.label
        }

        if (k.subLabel != null && k.kind == KeyKind.CHAR) {
            if (BanglaMarkView.isMark(k.subLabel)) {
                val subMark = BanglaMarkView(context).apply {
                    setMark(k.subLabel, theme.subText)
                    layoutParams = FrameLayout.LayoutParams(dp(12), dp(12), Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(2); rightMargin = dp(3)
                    }
                }
                frame.addView(subMark)
            } else {
                val subTv = TextView(context).apply {
                    text = k.subLabel
                    textSize = 9.5f
                    setTextColor(theme.subText)
                    layoutParams = FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                        topMargin = dp(2); rightMargin = dp(4)
                    }
                }
                frame.addView(subTv)
            }
        }

        if (k.kind == KeyKind.CHAR && BanglaMarkView.isMark(displayChar)) {
            val markView = BanglaMarkView(context).apply {
                setMark(displayChar, theme.keyText)
                layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER).apply {
                    if (language == KeyboardLanguage.PROVAT) topMargin = dp(3)
                }
            }
            frame.addView(markView)
        } else {
            val mainTv = TextView(context).apply {
                text = displayChar
                textSize = if (k.kind == KeyKind.LAYER) 12f else if (isFn) 18f else 18.5f
                setTextColor(when {
                    k.kind == KeyKind.SHIFT && (shift || capsLock) -> Color.WHITE
                    k.kind == KeyKind.SHIFT || k.kind == KeyKind.BACKSPACE || k.kind == KeyKind.LAYER -> theme.accentText
                    else -> theme.keyText
                })
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
                    if (language == KeyboardLanguage.PROVAT && k.kind == KeyKind.CHAR) topMargin = dp(4)
                }
            }
            frame.addView(mainTv)
        }

        if (k.kind == KeyKind.BACKSPACE) {
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        bsStartX = event.x
                        bsDidRepeat = false
                        bsDidSwipe = false
                        frame.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                        bsHoldRunnable = Runnable {
                            bsDidRepeat = true
                            callbacks.onBackspace()
                            val rep = object : Runnable {
                                override fun run() {
                                    callbacks.onBackspace()
                                    mainHandler.postDelayed(this, 52L)
                                }
                            }
                            bsRepeatRunnable = rep
                            mainHandler.postDelayed(rep, 52L)
                        }
                        mainHandler.postDelayed(bsHoldRunnable!!, 320L)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (event.x - bsStartX <= -dp(26)) {
                            clearBsTimers()
                            bsDidSwipe = true
                            bsStartX = event.x
                            callbacks.onDeleteWord()
                            refreshSuggestions()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        clearBsTimers()
                        frame.background = roundedBox(bg, border, 8)
                        if (!bsDidRepeat && !bsDidSwipe && event.action == MotionEvent.ACTION_UP) {
                            callbacks.onBackspace()
                            refreshSuggestions()
                        } else {
                            refreshSuggestions()
                        }
                        true
                    }
                    else -> false
                }
            }
        } else {
            var longPressTriggered = false
            val lpRunnable = Runnable {
                if (k.kind == KeyKind.CHAR && k.subLabel != null) {
                    longPressTriggered = true
                    callbacks.onCommitText(k.subLabel)
                    refreshSuggestions()
                }
            }
            frame.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        longPressTriggered = false
                        frame.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                        if (showPopup && k.kind == KeyKind.CHAR) showKeyPopupBubble(frame, displayChar)
                        if (k.kind == KeyKind.CHAR && k.subLabel != null) mainHandler.postDelayed(lpRunnable, 380L)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        frame.background = roundedBox(bg, border, 8)
                        if (!longPressTriggered) handleKeyTap(k)
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        mainHandler.removeCallbacks(lpRunnable)
                        hideKeyPopupBubble()
                        frame.background = roundedBox(bg, border, 8)
                        true
                    }
                    else -> false
                }
            }
        }
        return frame
    }

    private fun clearBsTimers() {
        bsHoldRunnable?.let { mainHandler.removeCallbacks(it) }
        bsRepeatRunnable?.let { mainHandler.removeCallbacks(it) }
        bsHoldRunnable = null
        bsRepeatRunnable = null
    }

    private fun handleKeyTap(k: KeyDef) {
        when (k.kind) {
            KeyKind.SHIFT -> {
                val now = System.currentTimeMillis()
                if (now - lastShiftTap < 280L) {
                    capsLock = !capsLock
                    shift = capsLock
                } else if (capsLock) {
                    capsLock = false
                    shift = false
                } else {
                    shift = !shift
                }
                lastShiftTap = now
                renderBody()
            }
            KeyKind.LAYER -> {
                layer = if (k.id == "layer2") KeyLayer.SYMBOLS2 else KeyLayer.SYMBOLS1
                renderBody()
            }
            else -> {
                val out = when {
                    shift && k.shiftValue != null -> k.shiftValue
                    language == KeyboardLanguage.ENGLISH && layer == KeyLayer.ALPHA && !shift ->
                        (k.value ?: k.label).lowercase()
                    else -> k.value ?: k.label
                }
                callbacks.onCommitText(out)
                if (shift && !capsLock) {
                    shift = false
                    renderBody()
                }
                refreshSuggestions()
            }
        }
    }

    private fun createSpacebar(keyH: Int): View {
        val btn = TextView(context).apply {
            text = if (language == KeyboardLanguage.ENGLISH) "‹  English  ›" else "‹  প্রভাত  ›"
            textSize = 13f
            setTextColor(theme.keyText)
            gravity = Gravity.CENTER
            background = roundedBox(theme.keyBg, theme.keyBorder, 8)
            layoutParams = LayoutParams(0, keyH, 3.2f).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        var startX = 0f
        var swiped = false
        btn.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x
                    swiped = false
                    btn.background = roundedBox(theme.keyPressedBg, theme.accent, 8)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!swiped && kotlin.math.abs(event.x - startX) >= dp(24)) {
                        swiped = true
                        language = if (language == KeyboardLanguage.ENGLISH) KeyboardLanguage.PROVAT else KeyboardLanguage.ENGLISH
                        layer = KeyLayer.ALPHA
                        shift = false
                        capsLock = false
                        aiSuggestions = emptyList()
                        rebuildAll()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    btn.background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    if (!swiped) {
                        callbacks.onCommitText(" ")
                        refreshSuggestions()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    btn.background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    true
                }
                else -> false
            }
        }
        return btn
    }

    private fun makeActionKey(label: String, weight: Float, bg: Int, border: Int, fg: Int, radiusDp: Int, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(fg)
            gravity = Gravity.CENTER
            background = roundedBox(bg, border, radiusDp)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply { setMargins(dp(2), 0, dp(2), 0) }
            setOnClickListener { onClick() }
        }
    }

    private fun showKeyPopupBubble(anchor: View, ch: String) {
        try {
            if (keyPopupWindow == null) {
                val box = FrameLayout(context).apply {
                    background = roundedBox(theme.keyPressedBg, theme.accent, 10, 2)
                }
                keyPopupText = TextView(context).apply {
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setTextColor(theme.keyText)
                }
                keyPopupMark = BanglaMarkView(context)
                box.addView(keyPopupText, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
                box.addView(keyPopupMark, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
                keyPopupWindow = PopupWindow(box, dp(48), dp(52), false).apply {
                    isTouchable = false
                }
            }
            (keyPopupWindow?.contentView as? FrameLayout)?.background = roundedBox(theme.keyPressedBg, theme.accent, 10, 2)
            if (BanglaMarkView.isMark(ch)) {
                keyPopupText?.visibility = View.GONE
                keyPopupMark?.visibility = View.VISIBLE
                keyPopupMark?.setMark(ch, theme.keyText)
            } else {
                keyPopupMark?.visibility = View.GONE
                keyPopupText?.visibility = View.VISIBLE
                keyPopupText?.text = ch
                keyPopupText?.setTextColor(theme.keyText)
            }
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            keyPopupWindow?.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0] + (anchor.width - dp(48)) / 2, loc[1] - dp(56))
        } catch (_: Exception) {}
    }

    private fun hideKeyPopupBubble() {
        try { keyPopupWindow?.dismiss() } catch (_: Exception) {}
    }

    private fun renderEmojiPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val tabScroll = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        for (cat in EmojiData.CATEGORIES) {
            val active = cat.id == emojiCatId
            tabRow.addView(TextView(context).apply {
                text = cat.label
                textSize = 12f
                setTextColor(if (active) Color.WHITE else theme.keyText)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = roundedBox(if (active) theme.accent else theme.keyBg, theme.keyBorder, 8)
                layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }
                setOnClickListener { emojiCatId = cat.id; renderBody() }
            })
        }
        tabScroll.addView(tabRow)
        wrap.addView(tabScroll)

        val emojis = EmojiData.CATEGORIES.firstOrNull { it.id == emojiCatId }?.emojis ?: emptyList()
        val gridScroll = ScrollView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(195)).apply { topMargin = dp(8) }
        }
        val grid = LinearLayout(context).apply { orientation = VERTICAL }
        for (chunk in emojis.chunked(8)) {
            val row = LinearLayout(context).apply { orientation = HORIZONTAL }
            for (em in chunk) {
                row.addView(TextView(context).apply {
                    text = em
                    textSize = 22f
                    gravity = Gravity.CENTER
                    background = roundedBox(theme.keyBg, Color.TRANSPARENT, 6)
                    layoutParams = LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                    setOnClickListener { callbacks.onCommitText(em) }
                })
            }
            repeat(8 - chunk.size) { row.addView(View(context), LayoutParams(0, dp(42), 1f)) }
            grid.addView(row)
        }
        gridScroll.addView(grid)
        wrap.addView(gridScroll)

        val footer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38)).apply { topMargin = dp(6) }
        }
        footer.addView(makeActionKey("কিবোর্ডে ফিরুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        footer.addView(makeActionKey("⌫ মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            callbacks.onBackspace()
        })
        wrap.addView(footer)
        bodyContainer.addView(wrap)
    }

    private fun renderCursorPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val row1 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(8) }
        }
        row1.addView(makeActionKey("Select All", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onSelectAll() })
        row1.addView(makeActionKey("Copy", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCopy() })
        row1.addView(makeActionKey("Cut", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onCut() })
        row1.addView(makeActionKey("Paste", 1f, theme.accent, theme.accent, Color.WHITE, 8) { callbacks.onPasteSystem() })
        wrap.addView(row1)

        val row2 = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(8) }
        }
        row2.addView(makeActionKey("|◄ শুরু", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("start") })
        row2.addView(makeActionKey("◄ বামে", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("left") })
        row2.addView(makeActionKey("ডানে ►", 1f, theme.keyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("right") })
        row2.addView(makeActionKey("শেষ ►|", 1f, theme.fnKeyBg, theme.keyBorder, theme.keyText, 8) { callbacks.onMoveCursor("end") })
        wrap.addView(row2)

        wrap.addView(makeActionKey("কিবোর্ডে ফিরুন (ABC)", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        }.apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)) })

        bodyContainer.addView(wrap)
    }

    private fun renderClipboardPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val all = clipStore.getAll()
        val pinned = all.filter { it.pinned }
        val temp = all.filter { !it.pinned }

        // Tabs: পিন কমেন্ট (LEFT) & অস্থায়ী কমেন্ট (RIGHT)
        val tabRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(38)).apply { bottomMargin = dp(8) }
        }
        tabRow.addView(makeActionKey("📌 পিন কমেন্ট (${pinned.size}/40)", 1f,
            if (clipPinnedTab) theme.accent else theme.keyBg, theme.accent,
            if (clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = true; renderBody()
        })
        tabRow.addView(makeActionKey("⏱ অস্থায়ী কমেন্ট (${temp.size})", 1f,
            if (!clipPinnedTab) theme.accent else theme.keyBg, theme.keyBorder,
            if (!clipPinnedTab) Color.WHITE else theme.keyText, 8) {
            clipPinnedTab = false; renderBody()
        })
        wrap.addView(tabRow)

        val items = if (clipPinnedTab) pinned else temp
        val scroll = ScrollView(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(170)) }
        val listCol = LinearLayout(context).apply { orientation = VERTICAL }

        if (items.isEmpty()) {
            listCol.addView(TextView(context).apply {
                text = if (clipPinnedTab) "কোনো পিন কমেন্ট নেই (সর্বোচ্চ ৪০টি স্থায়ী থাকবে)"
                else "অস্থায়ী কমেন্ট খালি (১২ ঘন্টা পর অটো-ডিলিট হবে)"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(theme.subText)
                setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        } else {
            for (item in items) {
                val card = LinearLayout(context).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBox(theme.keyBg, theme.keyBorder, 8)
                    setPadding(dp(10), dp(8), dp(6), dp(8))
                    layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
                }
                val txtCol = LinearLayout(context).apply {
                    orientation = VERTICAL
                    layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener { callbacks.onCommitText(item.text) }
                }
                txtCol.addView(TextView(context).apply {
                    text = item.text
                    textSize = 13f
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(theme.keyText)
                })
                if (!item.pinned) {
                    txtCol.addView(TextView(context).apply {
                        text = clipStore.formatRemaining(item.createdAt)
                        textSize = 10f
                        setTextColor(theme.subText)
                    })
                }
                card.addView(txtCol)

                card.addView(TextView(context).apply {
                    text = if (item.pinned) "✕📌" else "📌"
                    textSize = 14f
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    setOnClickListener { clipStore.togglePin(item.id); renderBody() }
                })
                card.addView(TextView(context).apply {
                    text = "🗑"
                    textSize = 14f
                    setPadding(dp(6), dp(4), dp(6), dp(4))
                    setOnClickListener { clipStore.deleteItem(item.id); renderBody() }
                })
                listCol.addView(card)
            }
        }
        scroll.addView(listCol)
        wrap.addView(scroll)

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(36)).apply { topMargin = dp(6) }
        }
        bottom.addView(makeActionKey("সব মুছুন", 1f, theme.fnKeyBg, theme.keyBorder, theme.accentText, 8) {
            clipStore.clearScope(clipPinnedTab); renderBody()
        })
        bottom.addView(makeActionKey("কিবোর্ড", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        wrap.addView(bottom)
        bodyContainer.addView(wrap)
    }

    private fun renderThemesPanel() {
        val scroll = ScrollView(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(260)) }
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        for (t in KeyboardThemes.ALL) {
            val active = t.id == theme.id
            wrap.addView(TextView(context).apply {
                text = (if (active) "✓ " else "") + "${t.name} — ${t.nameBn}"
                textSize = 13.5f
                setTextColor(t.keyText)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = roundedBox(t.boardBg, if (active) t.accent else t.keyBorder, 8, if (active) 2 else 1)
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
                setOnClickListener {
                    prefs.edit().putString("theme_id", t.id).apply()
                    theme = t
                    callbacks.onPreferencesChanged()
                    rebuildAll()
                }
            })
        }
        scroll.addView(wrap)
        bodyContainer.addView(scroll)
    }

    private fun renderSettingsPanel() {
        val wrap = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val hRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(40)).apply { bottomMargin = dp(8) }
        }
        for ((id, label) in listOf("compact" to "উচ্চতা: ছোট", "standard" to "সাধারণ", "tall" to "বড়")) {
            val active = keyHeightMode == id
            hRow.addView(makeActionKey(label, 1f, if (active) theme.accent else theme.keyBg, theme.keyBorder, if (active) Color.WHITE else theme.keyText, 8) {
                keyHeightMode = id
                prefs.edit().putString("key_height", id).apply()
                callbacks.onPreferencesChanged()
                rebuildAll()
            })
        }
        wrap.addView(hRow)

        val tRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(8) }
        }
        tRow.addView(makeActionKey("বানান ডিকেক্টর: ${if (spellCheckEnabled) "চালু" else "বন্ধ"}", 1f,
            if (spellCheckEnabled) theme.accent else theme.keyBg, theme.keyBorder, if (spellCheckEnabled) Color.WHITE else theme.keyText, 8) {
            spellCheckEnabled = !spellCheckEnabled
            prefs.edit().putBoolean("spell_check", spellCheckEnabled).apply()
            rebuildAll()
        })
        tRow.addView(makeActionKey("পপ-আপ: ${if (showPopup) "চালু" else "বন্ধ"}", 1f,
            if (showPopup) theme.accent else theme.keyBg, theme.keyBorder, if (showPopup) Color.WHITE else theme.keyText, 8) {
            showPopup = !showPopup
            prefs.edit().putBoolean("show_popup", showPopup).apply()
            renderBody()
        })
        wrap.addView(tRow)

        val bRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(42))
        }
        bRow.addView(makeActionKey("নাম্বার সারি: ${if (showNumberRow) "চালু" else "বন্ধ"}", 1f,
            if (showNumberRow) theme.accent else theme.keyBg, theme.keyBorder, if (showNumberRow) Color.WHITE else theme.keyText, 8) {
            showNumberRow = !showNumberRow
            prefs.edit().putBoolean("show_num_row", showNumberRow).apply()
            rebuildAll()
        })
        bRow.addView(makeActionKey("সম্পন্ন", 1f, theme.accent, theme.accent, Color.WHITE, 8) {
            activePanel = Panel.KEYS; rebuildAll()
        })
        wrap.addView(bRow)

        bodyContainer.addView(wrap)
    }
}
