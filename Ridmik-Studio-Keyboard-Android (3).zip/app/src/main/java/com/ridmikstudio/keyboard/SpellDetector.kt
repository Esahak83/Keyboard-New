package com.ridmikstudio.keyboard

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.min

data class SpellCandidate(
    val word: String,
    val isCorrection: Boolean = false,
    val isAi: Boolean = false,
    val replaceLastWord: Boolean = false
)

object SpellDetector {
    private val EN_VOCAB = listOf(
        "about", "after", "again", "always", "amazing", "awesome", "bangla", "bangladesh",
        "beautiful", "because", "before", "better", "birthday", "brother", "business", "busy",
        "called", "camera", "check", "checking", "close", "coming", "comment", "complete",
        "computer", "confirm", "congratulations", "continue", "copy", "correct", "could",
        "custom", "daily", "dark", "decide", "definitely", "delete", "design", "different",
        "doing", "done", "download", "dreams", "early", "easy", "email", "emoji", "english",
        "enough", "evening", "everyone", "everything", "exactly", "example", "excellent",
        "family", "fast", "father", "favorite", "feeling", "final", "finish", "first",
        "follow", "food", "forget", "free", "friend", "friends", "from", "future", "getting",
        "give", "going", "good", "great", "happy", "have", "having", "hello", "help", "helping",
        "here", "home", "hope", "hour", "house", "important", "information", "instead",
        "internet", "just", "keep", "keyboard", "know", "language", "later", "learn",
        "learning", "like", "link", "little", "looking", "love", "lovely", "make", "many",
        "market", "maybe", "meet", "meeting", "message", "minutes", "mobile", "moment",
        "morning", "mother", "much", "music", "name", "need", "never", "next", "nice",
        "night", "nothing", "number", "office", "okay", "online", "only", "open", "other",
        "paste", "people", "perfect", "person", "phone", "photo", "picture", "place", "plan",
        "please", "possible", "pretty", "problem", "project", "question", "quick", "ready",
        "really", "receive", "remember", "reply", "ridmik", "right", "same", "save", "school",
        "screen", "search", "second", "send", "sending", "settings", "share", "should",
        "show", "sister", "smile", "some", "something", "soon", "sorry", "sounds", "special",
        "spelling", "start", "still", "story", "strong", "student", "study", "success",
        "support", "sure", "system", "take", "taking", "talk", "teacher", "thank", "thanks",
        "that", "their", "them", "theme", "there", "these", "they", "thing", "think", "this",
        "those", "though", "thought", "time", "today", "together", "tomorrow", "tonight",
        "touch", "typing", "under", "understand", "update", "using", "usually", "very",
        "video", "waiting", "want", "watch", "water", "weather", "weekend", "welcome", "well",
        "what", "when", "where", "which", "while", "will", "with", "without", "wonderful",
        "word", "work", "working", "world", "would", "write", "writing", "year", "yesterday",
        "your", "yours", "the", "and", "you", "are", "for", "not", "but", "can", "how", "why"
    )

    private val EN_TYPOS = mapOf(
        "teh" to "the", "adn" to "and", "taht" to "that", "tihs" to "this",
        "waht" to "what", "jsut" to "just", "konw" to "know", "yuo" to "you",
        "yuor" to "your", "recieve" to "receive", "becuase" to "because",
        "beacuse" to "because", "langauge" to "language", "keybaord" to "keyboard",
        "kyeboard" to "keyboard", "tomorow" to "tomorrow", "tommorow" to "tomorrow",
        "hlleo" to "hello", "helo" to "hello", "thnaks" to "thanks", "thanx" to "thanks",
        "plese" to "please", "improtant" to "important", "freind" to "friend",
        "definately" to "definitely", "seperate" to "separate", "untill" to "until",
        "wich" to "which", "gud" to "good", "mrng" to "morning", "srry" to "sorry",
        "mssg" to "message", "mesage" to "message", "bangldesh" to "bangladesh",
        "englsh" to "english", "thme" to "theme", "welcom" to "welcome",
        "realy" to "really", "alwyas" to "always", "todya" to "today"
    )

    private val BN_VOCAB = listOf(
        "আমি", "আমার", "আমরা", "আমাদের", "আমাকে", "আপনি", "আপনার", "আপনাকে",
        "আছি", "আছো", "আছেন", "আছে", "আজকে", "আজ", "আসছি", "আসবো", "আসবে",
        "আসসালামু", "আলাইকুম", "ওয়ালাইকুম", "আলহামদুলিল্লাহ", "ইনশাআল্লাহ", "মাশাআল্লাহ",
        "আল্লাহ", "হাফেজ", "অনেক", "অবশ্যই", "অবস্থা", "অপেক্ষা", "অন্য", "আবহাওয়া",
        "আবার", "আগে", "আসলে", "ইংরেজি", "ইমোজি", "উত্তর", "উচিত", "একটু", "একসাথে",
        "একদম", "এখন", "এখানে", "এটা", "এবং", "ওকে", "কথা", "কোথায়", "কখন", "কেন",
        "কেমন", "কী", "কীভাবে", "কিছু", "কিন্তু", "করছি", "করছো", "করছেন", "করছে",
        "করবো", "করবে", "করো", "করে", "করেছি", "করেছে", "কাজ", "কারণ", "কাছে",
        "কিবোর্ড", "ক্লিপবোর্ড", "কপি", "কমেন্ট", "খবর", "খুব", "খারাপ", "খুশি",
        "গেছে", "গেছি", "গেলো", "ঘুরতে", "চলো", "চাই", "ছবি", "জন্য", "জানি",
        "জন্মদিন", "জন্মভূমি", "জরুরি", "ঠিক", "ঠিকঠাক", "তখন", "তাহলে", "তাই",
        "তাড়াতাড়ি", "তুমি", "তোমার", "তোমায়", "তোমাকে", "থাকো", "থেকো", "থেকে",
        "দারুণ", "দরকার", "দাও", "দিন", "দিয়েছি", "দুঃখিত", "দেখা", "দেখো", "দেরি",
        "দেশ", "দোয়া", "ধন্যবাদ", "নাম", "না", "নাকি", "নতুন", "নেই", "নিয়ে",
        "পছন্দ", "পরে", "পরীক্ষা", "পাঠিয়ে", "পাঠাও", "পারি", "পারো", "প্রভাত",
        "প্রিয়", "প্রশ্ন", "প্রায়", "প্রয়োজন", "পেস্ট", "ফটো", "ফোন", "ফিরবে",
        "ফ্রি", "বন্ধু", "বলে", "বলো", "বলছি", "বাংলা", "বাংলাদেশ", "বাড়ি", "বাসায়",
        "বিকেলে", "বিশ্বাস", "বুঝতে", "বুঝেছি", "ব্যস্ত", "ভাই", "ভালো", "ভালোবাসা",
        "ভালোবাসি", "ভুল", "মতো", "মন", "মনে", "মানুষ", "মেসেজ", "মোবাইল", "যদি",
        "যাচ্ছি", "যাবো", "যাবে", "রাত", "রাত্রি", "রিদ্মিক", "লাগলো", "লাগে",
        "লিখতে", "লিখেছি", "লেখা", "শব্দ", "শুদ্ধ", "শুধু", "শুভ", "শুভেচ্ছা",
        "শেষ", "সব", "সবাই", "সবাইকে", "সময়", "সমস্যা", "সহজ", "সাহায্য", "সাথে",
        "সাবধানে", "সুন্দর", "সুস্থ", "সকাল", "সন্ধ্যা", "সরি", "সেটিংস", "সোনার",
        "স্বাগতম", "হয়েছে", "হয়ে", "হবে", "হলো", "হ্যালো", "হ্যাঁ", "হঠাৎ"
    )

    private val BN_TYPOS = mapOf(
        "ভাল" to "ভালো", "ভালবাসি" to "ভালোবাসি", "ভালবাসা" to "ভালোবাসা",
        "কিভাবে" to "কীভাবে", "বাংলদেশ" to "বাংলাদেশ", "বাঙলাদেশ" to "বাংলাদেশ",
        "বাংলাদশ" to "বাংলাদেশ", "ধন্যবাধ" to "ধন্যবাদ", "ধন্নবাদ" to "ধন্যবাদ",
        "ধন্যবা" to "ধন্যবাদ", "আসসালাম" to "আসসালামু", "আলাইকম" to "আলাইকুম",
        "হয়েচে" to "হয়েছে", "হইছে" to "হয়েছে", "করচে" to "করছে",
        "যাচছি" to "যাচ্ছি", "আসচি" to "আসছি", "আচি" to "আছি",
        "কোথয়" to "কোথায়", "সবাইক" to "সবাইকে", "ইনশাল্লাহ" to "ইনশাআল্লাহ",
        "সুন্দোর" to "সুন্দর", "কিবোড" to "কিবোর্ড", "অপেখা" to "অপেক্ষা",
        "সমসা" to "সমস্যা", "শুদ্ধু" to "শুদ্ধ", "ইংরেজী" to "ইংরেজি",
        "আমিি" to "আমি", "তুুমি" to "তুমি", "তোমাার" to "তোমার",
        "বুজতে" to "বুঝতে", "জন্যে" to "জন্য", "পরিক্ষা" to "পরীক্ষা",
        "দুখিত" to "দুঃখিত", "ভুল্ল" to "ভুল", "ভূল" to "ভুল",
        "জন্মভুমি" to "জন্মভূমি", "সাহাজ্য" to "সাহায্য", "ভবিষ্যত" to "ভবিষ্যৎ",
        "হঠাত" to "হঠাৎ", "শুভেচা" to "শুভেচ্ছা"
    )

    private val aiCache = HashMap<String, List<String>>()

    private fun normalizeBangla(input: String): String {
        return input
            .replace("ী", "ি").replace("ূ", "ু")
            .replace("ষ", "শ").replace("স", "শ")
            .replace("য", "জ").replace("ণ", "ন")
            .replace("ড়", "র").replace("ঢ়", "র")
            .replace("ৎ", "ত").replace("ৌ", "ো").replace("ৈ", "ে")
    }

    private fun damerau(a: String, b: String, maxDist: Int = 2): Int {
        if (abs(a.length - b.length) > maxDist) return maxDist + 1
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = min(dp[i - 1][j] + 1, min(dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost))
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = min(v, dp[i - 2][j - 2] + 1)
                }
                dp[i][j] = v
            }
        }
        return dp[a.length][b.length]
    }

    fun isKnownWord(word: String, language: KeyboardLanguage): Boolean {
        val clean = if (language == KeyboardLanguage.ENGLISH) word.trim().lowercase() else word.trim()
        return if (language == KeyboardLanguage.ENGLISH) EN_VOCAB.contains(clean) else BN_VOCAB.contains(clean)
    }

    fun suggestLocal(textBefore: String, language: KeyboardLanguage): List<SpellCandidate> {
        val trimmedEnd = textBefore.trimEnd()
        val endsWithSpace = textBefore.isEmpty() || textBefore.last().isWhitespace()

        if (endsWithSpace) {
            // Check if just-committed word has a typo
            val lastWord = trimmedEnd.split(Regex("\\s+")).lastOrNull().orEmpty()
            if (lastWord.length >= 2 && !isKnownWord(lastWord, language)) {
                val fixes = findFixes(lastWord, language)
                if (fixes.isNotEmpty()) {
                    val defaults = if (language == KeyboardLanguage.ENGLISH) listOf("is", "are", "you", "the") else listOf("আছি", "কেমন", "ভালো", "এখন")
                    return (fixes.take(2).map { SpellCandidate(it, isCorrection = true, replaceLastWord = true) } +
                        defaults.map { SpellCandidate(it) }).take(5)
                }
            }
            val starters = if (language == KeyboardLanguage.ENGLISH) {
                listOf("I", "How", "Hello", "Thank", "Please")
            } else {
                listOf("আমি", "তুমি", "কেমন", "ভালো", "ধন্যবাদ")
            }
            return starters.map { SpellCandidate(it) }
        }

        val current = textBefore.substringAfterLast(' ').substringAfterLast('\n')
        if (current.isEmpty()) return emptyList()

        val vocab = if (language == KeyboardLanguage.ENGLISH) EN_VOCAB else BN_VOCAB
        val q = if (language == KeyboardLanguage.ENGLISH) current.lowercase() else current
        val exactStarts = vocab.filter { it.startsWith(q) }.take(4).map {
            val out = if (language == KeyboardLanguage.ENGLISH && current[0].isUpperCase()) {
                it.replaceFirstChar { c -> c.uppercase() }
            } else it
            SpellCandidate(out)
        }

        if (isKnownWord(current, language)) {
            return exactStarts.ifEmpty { listOf(SpellCandidate(current)) }
        }

        val fixes = findFixes(current, language).map {
            val out = if (language == KeyboardLanguage.ENGLISH && current[0].isUpperCase()) {
                it.replaceFirstChar { c -> c.uppercase() }
            } else it
            SpellCandidate(out, isCorrection = true)
        }
        val merged = (fixes + exactStarts).distinctBy { it.word }.take(5)
        return merged.ifEmpty { listOf(SpellCandidate(current)) }
    }

    private fun findFixes(word: String, language: KeyboardLanguage): List<String> {
        val clean = if (language == KeyboardLanguage.ENGLISH) word.lowercase() else word
        val direct = if (language == KeyboardLanguage.ENGLISH) EN_TYPOS[clean] else BN_TYPOS[clean]
        val vocab = if (language == KeyboardLanguage.ENGLISH) EN_VOCAB else BN_VOCAB
        val maxDist = if (clean.length <= 4) 1 else 2
        val normClean = if (language == KeyboardLanguage.PROVAT) normalizeBangla(clean) else clean

        val scored = vocab.mapNotNull { cand ->
            if (cand == clean) return@mapNotNull null
            var d = damerau(clean, cand, maxDist)
            if (language == KeyboardLanguage.PROVAT && d > 1) {
                val nd = damerau(normClean, normalizeBangla(cand), 1)
                if (nd == 0) d = 0 else if (nd == 1) d = min(d, 1)
            }
            if (d <= maxDist) cand to d else null
        }.sortedBy { it.second }.map { it.first }

        return if (direct != null) (listOf(direct) + scored).distinct().take(3) else scored.take(3)
    }

    fun fetchAiCorrection(apiKey: String, word: String, contextBefore: String, language: KeyboardLanguage): List<String> {
        if (apiKey.isBlank() || word.length < 3 || isKnownWord(word, language)) return emptyList()
        val key = "${language.name}:$word:${contextBefore.takeLast(40)}"
        aiCache[key]?.let { return it }

        return try {
            val langName = if (language == KeyboardLanguage.PROVAT) "Bangla" else "English"
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=$apiKey")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4500
                readTimeout = 4500
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val prompt = "You are a $langName spell checker. Preceding text: '${contextBefore.takeLast(80)}'. Token: '$word'. If misspelled, reply JSON {\"corrections\":[\"word1\",\"word2\"]} with corrected spellings. If already spelled right, reply {\"corrections\":[]}."
            val textPart = JSONObject()
            textPart.put("text", prompt)
            val partsArr = JSONArray()
            partsArr.put(textPart)
            val contentObj = JSONObject()
            contentObj.put("parts", partsArr)
            val contentsArr = JSONArray()
            contentsArr.put(contentObj)
            val genCfg = JSONObject()
            genCfg.put("responseMimeType", "application/json")
            val body = JSONObject()
            body.put("contents", contentsArr)
            body.put("generationConfig", genCfg)
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            if (conn.responseCode !in 200..299) return emptyList()
            val resp = conn.inputStream.bufferedReader().readText()
            val text = JSONObject(resp)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
            val arr = JSONObject(text).optJSONArray("corrections") ?: JSONArray()
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i).trim()
                if (s.isNotEmpty() && s != word) out.add(s)
            }
            val finalOut = out.take(3)
            aiCache[key] = finalOut
            finalOut
        } catch (_: Exception) {
            emptyList()
        }
    }
}
