# Keep Ridmik Studio IME classes
-keep class com.ridmikstudio.keyboard.** { *; }
